/**
 * VoiceClone — Audio Feature Extraction Engine (DSP)
 * Pure vanilla JavaScript ES module (no external dependencies)
 * Shared across the Detector and Training Lab.
 */

export const FEATURE_NAMES = [
  'noise_floor_dbfs',
  'dyn_range_db',
  'digital_silence_pct',
  'bandwidth_hz',
  'spec_flatness',
  'spec_centroid_hz',
  'rolloff95_hz',
  'hf_4_8k_ratio',
  'spec_flux_cv',
  'mfcc_temporal_std',
  'mfcc_delta_mean',
  'f0_mean_hz',
  'f0_std_semitones',
  'f0_range_semitones',
  'voiced_pct',
  'f0_flat_step_pct',
  'hnr_mean_db',
  'hnr_std_db',
  'amp_frame_shimmer_pct',
  'pause_per_10s',
  'pause_mean_s',
  'pause_cv',
  'mod_peak_hz',
  'mod_peak_ratio'
];

export const FEATURE_PRESETS = {
  ALL: {
    id: 'all',
    label: 'All Cues (24 features)',
    features: FEATURE_NAMES
  },
  VOICE_TIMING: {
    id: 'voice_timing',
    label: 'Voice and Timing Only (no recording cues)',
    features: FEATURE_NAMES.filter(name => ![
      'noise_floor_dbfs', 'dyn_range_db', 'digital_silence_pct', 'bandwidth_hz'
    ].includes(name))
  },
  RECORDING: {
    id: 'recording',
    label: 'Recording Cues Only',
    features: [
      'noise_floor_dbfs', 'dyn_range_db', 'digital_silence_pct', 'bandwidth_hz'
    ]
  }
};

/**
 * Radix-2 In-Place Fast Fourier Transform
 */
export class Radix2FFT {
  constructor(size) {
    if ((size & (size - 1)) !== 0 || size < 2) {
      throw new Error(`FFT size must be a power of 2, received ${size}`);
    }
    this.size = size;
    const half = size / 2;
    this.cosTable = new Float32Array(half);
    this.sinTable = new Float32Array(half);
    for (let i = 0; i < half; i++) {
      const angle = (-2 * Math.PI * i) / size;
      this.cosTable[i] = Math.cos(angle);
      this.sinTable[i] = Math.sin(angle);
    }

    this.bitRev = new Uint32Array(size);
    let limit = 1;
    let bit = size >> 1;
    while (limit < size) {
      for (let i = 0; i < limit; i++) {
        this.bitRev[i + limit] = this.bitRev[i] + bit;
      }
      limit <<= 1;
      bit >>= 1;
    }
  }

  transform(real, imag) {
    const n = this.size;
    for (let i = 0; i < n; i++) {
      const rev = this.bitRev[i];
      if (rev > i) {
        const tr = real[i]; real[i] = real[rev]; real[rev] = tr;
        const ti = imag[i]; imag[i] = imag[rev]; imag[rev] = ti;
      }
    }

    for (let halfSize = 1; halfSize < n; halfSize <<= 1) {
      const step = n / (halfSize << 1);
      for (let i = 0; i < n; i += (halfSize << 1)) {
        for (let j = 0; j < halfSize; j++) {
          const k = j * step;
          const c = this.cosTable[k];
          const s = this.sinTable[k];
          const idx2 = i + j + halfSize;
          const idx1 = i + j;
          const re = real[idx2];
          const im = imag[idx2];
          const tr = c * re - s * im;
          const ti = c * im + s * re;
          real[idx2] = real[idx1] - tr;
          imag[idx2] = imag[idx1] - ti;
          real[idx1] += tr;
          imag[idx1] += ti;
        }
      }
    }
  }
}

// Pre-computed Hann Windows
const HANN_WINDOWS = new Map();
function getHannWindow(length) {
  if (HANN_WINDOWS.has(length)) return HANN_WINDOWS.get(length);
  const win = new Float32Array(length);
  for (let i = 0; i < length; i++) {
    win[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (length - 1)));
  }
  HANN_WINDOWS.set(length, win);
  return win;
}

// 26 Mel Filterbank builder for 16 kHz sample rate and 512 FFT size
let CACHED_MEL_FILTERS = null;
function getMelFilterbank() {
  if (CACHED_MEL_FILTERS) return CACHED_MEL_FILTERS;
  const numFilters = 26;
  const fftSize = 512;
  const sampleRate = 16000;
  const numBins = (fftSize / 2) + 1; // 257 bins
  const hzToMel = (hz) => 2595 * Math.log10(1 + hz / 700);
  const melToHz = (mel) => 700 * (Math.pow(10, mel / 2595) - 1);

  const minMel = hzToMel(0);
  const maxMel = hzToMel(sampleRate / 2); // 8000 Hz
  const melStep = (maxMel - minMel) / (numFilters + 1);

  const binPoints = new Float32Array(numFilters + 2);
  for (let i = 0; i < numFilters + 2; i++) {
    const mel = minMel + i * melStep;
    const hz = melToHz(mel);
    binPoints[i] = (fftSize + 1) * hz / sampleRate;
  }

  const filters = [];
  for (let m = 1; m <= numFilters; m++) {
    const filter = new Float32Array(numBins);
    const left = binPoints[m - 1];
    const center = binPoints[m];
    const right = binPoints[m + 1];

    for (let k = 0; k < numBins; k++) {
      if (k >= left && k <= center && center > left) {
        filter[k] = (k - left) / (center - left);
      } else if (k > center && k <= right && right > center) {
        filter[k] = (right - k) / (right - center);
      }
    }
    filters.push(filter);
  }

  CACHED_MEL_FILTERS = filters;
  return filters;
}

// Quantiles calculation helper
function percentile(sortedArr, p) {
  if (!sortedArr || sortedArr.length === 0) return 0;
  if (p <= 0) return sortedArr[0];
  if (p >= 1) return sortedArr[sortedArr.length - 1];
  const idx = p * (sortedArr.length - 1);
  const low = Math.floor(idx);
  const high = Math.ceil(idx);
  const weight = idx - low;
  return sortedArr[low] * (1 - weight) + sortedArr[high] * weight;
}

function mean(arr) {
  if (!arr || arr.length === 0) return 0;
  let s = 0;
  for (let i = 0; i < arr.length; i++) s += arr[i];
  return s / arr.length;
}

function std(arr, arrMean = null) {
  if (!arr || arr.length <= 1) return 0;
  const m = arrMean !== null ? arrMean : mean(arr);
  let v = 0;
  for (let i = 0; i < arr.length; i++) {
    const d = arr[i] - m;
    v += d * d;
  }
  return Math.sqrt(v / (arr.length - 1));
}

/**
 * Pure function: extractFeatures(samples16k, nativeSpectrum)
 * 
 * @param {Float32Array} samples16k - Mono 16 kHz resampled audio buffer
 * @param {Object} [nativeSpectrum] - Optional native sample rate long-term spectrum { powers, sampleRate } or bandwidth_hz
 * @returns {Object} Object containing exactly the 24 specified acoustic feature keys.
 */
export function extractFeatures(samples16k, nativeSpectrum = null) {
  const nSamples = samples16k ? samples16k.length : 0;
  if (!samples16k || nSamples === 0) {
    throw new Error('extractFeatures received empty or null samples buffer');
  }

  const sampleRate = 16000;
  const durationSec = nSamples / sampleRate;

  // -------------------------------------------------------------
  // 1. LEVEL FRAMES: 25 ms window (400 samples), 10 ms hop (160 samples)
  // -------------------------------------------------------------
  const levelWindowSize = 400; // 25 ms
  const hopSize = 160;         // 10 ms
  const numLevelFrames = Math.max(1, Math.floor((nSamples - levelWindowSize) / hopSize) + 1);

  const frameRMS = new Float32Array(numLevelFrames);
  const frameDbfs = new Float32Array(numLevelFrames);
  let zeroFramesCount = 0;
  let maxFrameRms = 1e-9;

  for (let i = 0; i < numLevelFrames; i++) {
    const offset = i * hopSize;
    let sumSq = 0;
    for (let j = 0; j < levelWindowSize; j++) {
      const val = samples16k[offset + j];
      sumSq += val * val;
    }
    const rms = Math.sqrt(sumSq / levelWindowSize);
    frameRMS[i] = rms;
    if (rms > maxFrameRms) maxFrameRms = rms;
    if (rms < 1e-5) zeroFramesCount++;

    // dBFS calculation with floor at -120 dBFS
    const clampedRms = Math.max(rms, 1e-6);
    frameDbfs[i] = Math.max(20 * Math.log10(clampedRms), -120);
  }

  // Sorted frame RMS in dBFS for percentiles
  const sortedDbfs = Array.from(frameDbfs).sort((a, b) => a - b);
  const p10_dbfs = Math.max(percentile(sortedDbfs, 0.10), -120);
  const p95_dbfs = Math.max(percentile(sortedDbfs, 0.95), -120);

  const noise_floor_dbfs = p10_dbfs;
  const dyn_range_db = Math.max(0, p95_dbfs - p10_dbfs);
  const digital_silence_pct = (zeroFramesCount / numLevelFrames) * 100;

  // Bandwidth calculation from native-rate long-term spectrum
  let bandwidth_hz = 8000;
  if (nativeSpectrum) {
    if (typeof nativeSpectrum.bandwidth_hz === 'number') {
      bandwidth_hz = nativeSpectrum.bandwidth_hz;
    } else if (nativeSpectrum.powers && nativeSpectrum.sampleRate) {
      const powers = nativeSpectrum.powers;
      const nativeRate = nativeSpectrum.sampleRate;
      let peakP = 1e-12;
      for (let i = 0; i < powers.length; i++) {
        if (powers[i] > peakP) peakP = powers[i];
      }
      const cutoff = peakP * 1e-6; // -60 dB from peak
      let maxBin = 0;
      for (let i = powers.length - 1; i >= 0; i--) {
        if (powers[i] >= cutoff) {
          maxBin = i;
          break;
        }
      }
      bandwidth_hz = (maxBin / (powers.length - 1)) * (nativeRate / 2);
    }
  } else {
    // Fallback: estimate from samples16k directly
    const testFftSize = 1024;
    const testFft = new Radix2FFT(testFftSize);
    const tr = new Float32Array(testFftSize);
    const ti = new Float32Array(testFftSize);
    const halfBins = testFftSize / 2;
    const avgPowers = new Float32Array(halfBins + 1);
    let framesCounted = 0;

    for (let off = 0; off + testFftSize <= nSamples; off += testFftSize) {
      for (let k = 0; k < testFftSize; k++) {
        tr[k] = samples16k[off + k];
        ti[k] = 0;
      }
      testFft.transform(tr, ti);
      for (let k = 0; k <= halfBins; k++) {
        avgPowers[k] += tr[k] * tr[k] + ti[k] * ti[k];
      }
      framesCounted++;
    }

    if (framesCounted > 0) {
      let maxP = 1e-12;
      for (let k = 0; k <= halfBins; k++) {
        if (avgPowers[k] > maxP) maxP = avgPowers[k];
      }
      const cutoff = maxP * 1e-6;
      let maxBin = 0;
      for (let k = halfBins; k >= 0; k--) {
        if (avgPowers[k] >= cutoff) {
          maxBin = k;
          break;
        }
      }
      bandwidth_hz = (maxBin / halfBins) * 8000;
    }
  }

  // -------------------------------------------------------------
  // 2. SPECTRAL CUES: 512-point FFT (frames within 40 dB of loudest)
  // -------------------------------------------------------------
  const spectralFftSize = 512;
  const spectralFft = new Radix2FFT(spectralFftSize);
  const spectralHann = getHannWindow(spectralFftSize);
  const halfBins = spectralFftSize / 2; // 256
  const binHz = sampleRate / spectralFftSize; // 31.25 Hz

  // 40 dB below loudest frame threshold:
  // 20*log10(RMS / maxFrameRms) >= -40  => RMS >= maxFrameRms * 0.01
  const loudnessThreshold = Math.max(maxFrameRms * 0.01, 1e-5);

  const numSpectralFrames = Math.max(1, Math.floor((nSamples - spectralFftSize) / hopSize) + 1);
  const melFilters = getMelFilterbank();

  const validFlatness = [];
  const validCentroids = [];
  const validRolloffs = [];
  const validHfRatios = [];
  const normalizedSpectra = [];
  const validMfccs = []; // Array of Float32Array(13)

  const reBuf = new Float32Array(spectralFftSize);
  const imBuf = new Float32Array(spectralFftSize);
  const powerBuf = new Float32Array(halfBins + 1);

  for (let i = 0; i < numSpectralFrames; i++) {
    const offset = i * hopSize;

    // Check level within 40 dB of loudest frame
    let frameSumSq = 0;
    for (let j = 0; j < spectralFftSize; j++) {
      const val = samples16k[offset + j];
      frameSumSq += val * val;
    }
    const curRms = Math.sqrt(frameSumSq / spectralFftSize);
    if (curRms < loudnessThreshold) continue;

    // Apply Hann window and perform FFT
    for (let j = 0; j < spectralFftSize; j++) {
      reBuf[j] = samples16k[offset + j] * spectralHann[j];
      imBuf[j] = 0;
    }
    spectralFft.transform(reBuf, imBuf);

    let totalPower = 0;
    for (let k = 0; k <= halfBins; k++) {
      const p = reBuf[k] * reBuf[k] + imBuf[k] * imBuf[k];
      powerBuf[k] = p;
      totalPower += p;
    }
    if (totalPower < 1e-12) continue;

    // A. Spectral Flatness: Geometric Mean / Arithmetic Mean (bins 1 to 256)
    // In audio DSP, applying a 5-bin moving average reduces exponential noise variance,
    // bringing white noise flatness near 1.0 (0.85+) while keeping tonal speech near 0.0.
    const smoothedPower = new Float32Array(halfBins + 1);
    const smoothRadius = 2; // 5-bin window: [k-2, k-1, k, k+1, k+2]
    for (let k = 1; k <= halfBins; k++) {
      let s = 0;
      let cnt = 0;
      for (let w = -smoothRadius; w <= smoothRadius; w++) {
        const bin = k + w;
        if (bin >= 1 && bin <= halfBins) {
          s += powerBuf[bin];
          cnt++;
        }
      }
      smoothedPower[k] = s / cnt;
    }

    let sumLog = 0;
    let sumLinear = 0;
    const numFlatBins = halfBins;
    for (let k = 1; k <= halfBins; k++) {
      const p = Math.max(smoothedPower[k], 1e-14);
      sumLog += Math.log(p);
      sumLinear += p;
    }
    const gm = Math.exp(sumLog / numFlatBins);
    const am = sumLinear / numFlatBins;
    const flatness = am > 1e-14 ? Math.min(1.0, gm / am) : 0;
    validFlatness.push(flatness);

    // B. Spectral Centroid
    let weightedFreqSum = 0;
    for (let k = 0; k <= halfBins; k++) {
      weightedFreqSum += (k * binHz) * powerBuf[k];
    }
    validCentroids.push(weightedFreqSum / totalPower);

    // C. Rolloff 95%
    const targetEnergy = 0.95 * totalPower;
    let cumEnergy = 0;
    let rolloffBin = halfBins;
    for (let k = 0; k <= halfBins; k++) {
      cumEnergy += powerBuf[k];
      if (cumEnergy >= targetEnergy) {
        rolloffBin = k;
        break;
      }
    }
    validRolloffs.push(rolloffBin * binHz);

    // D. High-Frequency (4-8 kHz) Energy Ratio
    const bin4k = Math.ceil(4000 / binHz); // bin 128
    let hfPower = 0;
    for (let k = bin4k; k <= halfBins; k++) {
      hfPower += powerBuf[k];
    }
    validHfRatios.push(hfPower / totalPower);

    // E. Normalized spectrum for spectral flux
    const normSpec = new Float32Array(halfBins + 1);
    for (let k = 0; k <= halfBins; k++) {
      normSpec[k] = powerBuf[k] / totalPower;
    }
    normalizedSpectra.push(normSpec);

    // F. MFCC (26 Mel filters -> 13 DCT coefficients)
    const melEnergies = new Float32Array(melFilters.length);
    for (let m = 0; m < melFilters.length; m++) {
      const filt = melFilters[m];
      let energy = 0;
      for (let k = 0; k <= halfBins; k++) {
        energy += powerBuf[k] * filt[k];
      }
      melEnergies[m] = Math.log(Math.max(energy, 1e-10));
    }

    // DCT-II to 13 MFCCs
    const mfcc = new Float32Array(13);
    for (let j = 0; j < 13; j++) {
      let sum = 0;
      for (let m = 0; m < melEnergies.length; m++) {
        sum += melEnergies[m] * Math.cos((Math.PI * j * (m + 0.5)) / melEnergies.length);
      }
      mfcc[j] = sum;
    }
    validMfccs.push(mfcc);
  }

  const spec_flatness = validFlatness.length > 0 ? mean(validFlatness) : 0;
  const spec_centroid_hz = validCentroids.length > 0 ? mean(validCentroids) : 0;
  const rolloff95_hz = validRolloffs.length > 0 ? mean(validRolloffs) : 0;
  const hf_4_8k_ratio = validHfRatios.length > 0 ? mean(validHfRatios) : 0;

  // Spectral Flux CV: std/mean of spectral flux between consecutive frames
  let spec_flux_cv = 0;
  if (normalizedSpectra.length >= 2) {
    const fluxes = [];
    for (let i = 1; i < normalizedSpectra.length; i++) {
      const prev = normalizedSpectra[i - 1];
      const cur = normalizedSpectra[i];
      let diffSq = 0;
      for (let k = 0; k <= halfBins; k++) {
        const d = cur[k] - prev[k];
        diffSq += d * d;
      }
      fluxes.push(Math.sqrt(diffSq));
    }
    const fluxMean = mean(fluxes);
    const fluxStd = std(fluxes, fluxMean);
    spec_flux_cv = fluxMean > 1e-6 ? fluxStd / fluxMean : 0;
  }

  // MFCC temporal standard deviation (mean over MFCC 2-13 across time)
  let mfcc_temporal_std = 0;
  let mfcc_delta_mean = 0;
  if (validMfccs.length >= 2) {
    // MFCC 2-13 is indices 1..12
    const coefStds = [];
    for (let c = 1; c <= 12; c++) {
      const coefVals = validMfccs.map(m => m[c]);
      coefStds.push(std(coefVals));
    }
    mfcc_temporal_std = mean(coefStds);

    // Delta MFCC mean norm between consecutive frames
    const deltaNorms = [];
    for (let i = 1; i < validMfccs.length; i++) {
      let sumSq = 0;
      for (let c = 1; c <= 12; c++) {
        const diff = validMfccs[i][c] - validMfccs[i - 1][c];
        sumSq += diff * diff;
      }
      deltaNorms.push(Math.sqrt(sumSq));
    }
    mfcc_delta_mean = mean(deltaNorms);
  }

  // -------------------------------------------------------------
  // 3. VOICE CUES: Normalized Autocorrelation Pitch (70-400 Hz)
  // Pitch frames 40 ms (640 samples), hop 10 ms (160 samples)
  // -------------------------------------------------------------
  const pitchWindowSize = 640; // 40 ms
  const minLag = Math.floor(sampleRate / 400); // 40 samples (400 Hz)
  const maxLag = Math.ceil(sampleRate / 70);   // 229 samples (70 Hz)
  const numPitchFrames = Math.max(1, Math.floor((nSamples - pitchWindowSize) / hopSize) + 1);

  const rawF0s = [];
  const rawHnrs = [];
  const voicedFrameIndices = [];
  const voicedRms = [];

  for (let i = 0; i < numPitchFrames; i++) {
    const offset = i * hopSize;

    // Frame RMS check within 40 dB of max
    let sumSq = 0;
    for (let j = 0; j < pitchWindowSize; j++) {
      const v = samples16k[offset + j];
      sumSq += v * v;
    }
    const pRms = Math.sqrt(sumSq / pitchWindowSize);
    if (pRms < loudnessThreshold) continue;

    // Compute normalized autocorrelation for lags in [minLag, maxLag]
    let bestLag = -1;
    let bestR = -1;
    const rValues = new Float32Array(maxLag + 2);

    for (let lag = minLag; lag <= maxLag; lag++) {
      let num = 0;
      let d1 = 0;
      let d2 = 0;
      const len = pitchWindowSize - lag;
      for (let j = 0; j < len; j++) {
        const s1 = samples16k[offset + j];
        const s2 = samples16k[offset + j + lag];
        num += s1 * s2;
        d1 += s1 * s1;
        d2 += s2 * s2;
      }
      const denom = Math.sqrt(d1 * d2) + 1e-12;
      const r = num / denom;
      rValues[lag] = r;
      if (r > bestR) {
        bestR = r;
        bestLag = lag;
      }
    }

    // Voiced condition: peak normalized autocorrelation > 0.45
    if (bestR > 0.45 && bestLag >= minLag && bestLag <= maxLag) {
      // Parabolic interpolation around peak lag
      let refinedLag = bestLag;
      if (bestLag > minLag && bestLag < maxLag) {
        const alpha = rValues[bestLag - 1];
        const beta = rValues[bestLag];
        const gamma = rValues[bestLag + 1];
        const denom = 2 * (alpha - 2 * beta + gamma);
        if (Math.abs(denom) > 1e-6) {
          const delta = (alpha - gamma) / denom;
          refinedLag = bestLag + delta;
        }
      }

      const f0 = sampleRate / refinedLag;
      // Raw HNR: 10 * log10(r / (1 - r))
      const clampedR = Math.min(Math.max(bestR, 0.01), 0.999);
      const hnr = 10 * Math.log10(clampedR / (1 - clampedR));

      rawF0s.push(f0);
      rawHnrs.push(hnr);
      voicedFrameIndices.push(i);
      voicedRms.push(pRms);
    }
  }

  const voiced_pct = (rawF0s.length / numPitchFrames) * 100;

  // Remove octave outliers using median filter
  let cleanF0s = [];
  let cleanHnrs = [];
  let cleanVoicedRms = [];
  let cleanIndices = [];

  if (rawF0s.length >= 3) {
    const sortedF0 = [...rawF0s].sort((a, b) => a - b);
    const medianF0 = percentile(sortedF0, 0.50);

    for (let k = 0; k < rawF0s.length; k++) {
      const f0 = rawF0s[k];
      const ratio = f0 / medianF0;
      // Allow within 0.55x and 1.8x of median
      if (ratio >= 0.55 && ratio <= 1.8) {
        cleanF0s.push(f0);
        cleanHnrs.push(rawHnrs[k]);
        cleanVoicedRms.push(voicedRms[k]);
        cleanIndices.push(voicedFrameIndices[k]);
      }
    }
  } else {
    cleanF0s = rawF0s;
    cleanHnrs = rawHnrs;
    cleanVoicedRms = voicedRms;
    cleanIndices = voicedFrameIndices;
  }

  let f0_mean_hz = 0;
  let f0_std_semitones = 0;
  let f0_range_semitones = 0;
  let f0_flat_step_pct = 0;
  let hnr_mean_db = 0;
  let hnr_std_db = 0;
  let amp_frame_shimmer_pct = 0;

  if (cleanF0s.length > 0) {
    f0_mean_hz = mean(cleanF0s);
    const sortedCleanF0 = [...cleanF0s].sort((a, b) => a - b);
    const medF0 = Math.max(percentile(sortedCleanF0, 0.50), 10);

    // Semitones relative to median
    const semitones = cleanF0s.map(f => 12 * Math.log2(Math.max(f, 1) / medF0));
    f0_std_semitones = std(semitones);

    const sortedSemi = [...semitones].sort((a, b) => a - b);
    const p5_semi = percentile(sortedSemi, 0.05);
    const p95_semi = percentile(sortedSemi, 0.95);
    f0_range_semitones = Math.max(0, p95_semi - p5_semi);

    hnr_mean_db = mean(cleanHnrs);
    hnr_std_db = std(cleanHnrs, hnr_mean_db);

    // Consecutive voiced frames analysis
    let consecutivePairs = 0;
    let flatSteps = 0;
    let sumAbsRmsDiff = 0;
    let sumVoicedRms = 0;

    for (let k = 1; k < cleanF0s.length; k++) {
      // Must be immediately adjacent in time (difference in frame index is 1)
      if (cleanIndices[k] === cleanIndices[k - 1] + 1) {
        consecutivePairs++;
        if (Math.abs(cleanF0s[k] - cleanF0s[k - 1]) < 0.5) {
          flatSteps++;
        }
        sumAbsRmsDiff += Math.abs(cleanVoicedRms[k] - cleanVoicedRms[k - 1]);
        sumVoicedRms += cleanVoicedRms[k];
      }
    }

    f0_flat_step_pct = consecutivePairs > 0 ? (flatSteps / consecutivePairs) * 100 : 0;
    const avgVoicedRms = cleanVoicedRms.length > 0 ? mean(cleanVoicedRms) : 1e-6;
    amp_frame_shimmer_pct = (consecutivePairs > 0 && avgVoicedRms > 1e-6)
      ? ((sumAbsRmsDiff / consecutivePairs) / avgVoicedRms) * 100
      : 0;
  }

  // -------------------------------------------------------------
  // 4. TIMING CUES: Pauses and Modulation Spectrum
  // -------------------------------------------------------------
  // Pause: run of frames > 35 dB below loudest frame lasting at least 150 ms
  // 150 ms at 10 ms hop = 15 consecutive frames
  const pauseThresholdRms = Math.max(maxFrameRms * Math.pow(10, -35 / 20), 1e-6);
  const minPauseFrames = 15; // 15 * 10 ms = 150 ms

  const pauseDurationsSec = [];
  let curPauseFrames = 0;

  for (let i = 0; i < numLevelFrames; i++) {
    if (frameRMS[i] < pauseThresholdRms) {
      curPauseFrames++;
    } else {
      if (curPauseFrames >= minPauseFrames) {
        pauseDurationsSec.push(curPauseFrames * 0.010);
      }
      curPauseFrames = 0;
    }
  }
  if (curPauseFrames >= minPauseFrames) {
    pauseDurationsSec.push(curPauseFrames * 0.010);
  }

  const pause_per_10s = durationSec > 0 ? (pauseDurationsSec.length / durationSec) * 10 : 0;
  const pause_mean_s = pauseDurationsSec.length > 0 ? mean(pauseDurationsSec) : 0;
  const pause_cv = pauseDurationsSec.length >= 2 && pause_mean_s > 1e-6
    ? std(pauseDurationsSec, pause_mean_s) / pause_mean_s
    : 0;

  // Modulation spectrum: 2 to 8 Hz peak in energy envelope (0.5 to 20 Hz)
  let mod_peak_hz = 4.0;
  let mod_peak_ratio = 0.5;

  if (numLevelFrames >= 32) {
    // Envelope frame rate is 100 Hz (10 ms hop)
    const envRate = 100;
    // Power-of-2 length >= numLevelFrames
    let modFftSize = 256;
    while (modFftSize < numLevelFrames) modFftSize <<= 1;
    if (modFftSize > 2048) modFftSize = 2048;

    const modFft = new Radix2FFT(modFftSize);
    const mRe = new Float32Array(modFftSize);
    const mIm = new Float32Array(modFftSize);

    // Compute energy envelope RMS^2 and subtract mean
    let meanEnergy = 0;
    for (let i = 0; i < numLevelFrames; i++) {
      meanEnergy += frameRMS[i] * frameRMS[i];
    }
    meanEnergy /= numLevelFrames;

    const mLen = Math.min(numLevelFrames, modFftSize);
    for (let i = 0; i < mLen; i++) {
      mRe[i] = (frameRMS[i] * frameRMS[i]) - meanEnergy;
    }

    modFft.transform(mRe, mIm);

    const modBinHz = envRate / modFftSize;
    let maxModPower = 0;
    let bestModHz = 4.0;
    let sum2to8Energy = 0;
    let sum05to20Energy = 0;

    const maxModBin = Math.floor(modFftSize / 2);
    for (let k = 1; k < maxModBin; k++) {
      const hz = k * modBinHz;
      const power = mRe[k] * mRe[k] + mIm[k] * mIm[k];

      if (hz >= 0.5 && hz <= 20.0) {
        sum05to20Energy += power;
      }
      if (hz >= 2.0 && hz <= 8.0) {
        sum2to8Energy += power;
        if (power > maxModPower) {
          maxModPower = power;
          bestModHz = hz;
        }
      }
    }

    mod_peak_hz = bestModHz;
    mod_peak_ratio = sum05to20Energy > 1e-12 ? sum2to8Energy / sum05to20Energy : 0.5;
  }

  // -------------------------------------------------------------
  // Clean Final Feature Object
  // -------------------------------------------------------------
  const features = {
    noise_floor_dbfs: cleanNum(noise_floor_dbfs),
    dyn_range_db: cleanNum(dyn_range_db),
    digital_silence_pct: cleanNum(digital_silence_pct),
    bandwidth_hz: cleanNum(bandwidth_hz),
    spec_flatness: cleanNum(spec_flatness),
    spec_centroid_hz: cleanNum(spec_centroid_hz),
    rolloff95_hz: cleanNum(rolloff95_hz),
    hf_4_8k_ratio: cleanNum(hf_4_8k_ratio),
    spec_flux_cv: cleanNum(spec_flux_cv),
    mfcc_temporal_std: cleanNum(mfcc_temporal_std),
    mfcc_delta_mean: cleanNum(mfcc_delta_mean),
    f0_mean_hz: cleanNum(f0_mean_hz),
    f0_std_semitones: cleanNum(f0_std_semitones),
    f0_range_semitones: cleanNum(f0_range_semitones),
    voiced_pct: cleanNum(voiced_pct),
    f0_flat_step_pct: cleanNum(f0_flat_step_pct),
    hnr_mean_db: cleanNum(hnr_mean_db),
    hnr_std_db: cleanNum(hnr_std_db),
    amp_frame_shimmer_pct: cleanNum(amp_frame_shimmer_pct),
    pause_per_10s: cleanNum(pause_per_10s),
    pause_mean_s: cleanNum(pause_mean_s),
    pause_cv: cleanNum(pause_cv),
    mod_peak_hz: cleanNum(mod_peak_hz),
    mod_peak_ratio: cleanNum(mod_peak_ratio)
  };

  return features;
}

function cleanNum(val) {
  if (typeof val !== 'number' || isNaN(val) || !isFinite(val)) return 0;
  return Number(val.toFixed(5));
}

/**
 * Built-in Unit Tests for extractFeatures:
 * 1. 200 Hz pure sine wave => f0_mean_hz within 2% (196 - 204 Hz)
 * 2. White noise => spec_flatness near 1 (> 0.70)
 * 3. Exact silence => digital_silence_pct near 100 (> 99%)
 */
export function runFeatureUnitTests() {
  const sampleRate = 16000;
  const durationSec = 3.0;
  const numSamples = Math.round(durationSec * sampleRate);
  const tests = [];

  // TEST 1: 200 Hz Sine Wave
  const sineBuffer = new Float32Array(numSamples);
  const freq = 200.0;
  for (let i = 0; i < numSamples; i++) {
    sineBuffer[i] = 0.5 * Math.sin((2 * Math.PI * freq * i) / sampleRate);
  }
  const sineFeatures = extractFeatures(sineBuffer);
  const f0ErrorPct = Math.abs(sineFeatures.f0_mean_hz - 200) / 200 * 100;
  const sinePassed = f0ErrorPct <= 2.0;
  tests.push({
    name: '200 Hz Sine Wave Fundamental Pitch',
    expected: 'f0_mean_hz within 2% of 200 Hz (196.0 - 204.0 Hz)',
    actual: `${sineFeatures.f0_mean_hz.toFixed(2)} Hz (error: ${f0ErrorPct.toFixed(2)}%)`,
    passed: sinePassed
  });

  // TEST 2: White Noise Flatness
  const noiseBuffer = new Float32Array(numSamples);
  let seed = 12345;
  for (let i = 0; i < numSamples; i++) {
    // Linear congruential generator for reproducible white noise
    seed = (seed * 1664525 + 1013904223) >>> 0;
    noiseBuffer[i] = ((seed / 4294967296) * 2 - 1) * 0.4;
  }
  const noiseFeatures = extractFeatures(noiseBuffer);
  const noisePassed = noiseFeatures.spec_flatness >= 0.70;
  tests.push({
    name: 'White Noise Spectral Flatness',
    expected: 'spec_flatness >= 0.70 (near 1.0)',
    actual: `${noiseFeatures.spec_flatness.toFixed(4)}`,
    passed: noisePassed
  });

  // TEST 3: Digital Silence
  const silenceBuffer = new Float32Array(numSamples);
  const silenceFeatures = extractFeatures(silenceBuffer);
  const silencePassed = silenceFeatures.digital_silence_pct >= 99.0;
  tests.push({
    name: 'Digital Silence Detection',
    expected: 'digital_silence_pct >= 99.0%',
    actual: `${silenceFeatures.digital_silence_pct.toFixed(2)}%`,
    passed: silencePassed
  });

  const allPassed = tests.every(t => t.passed);
  return {
    allPassed,
    tests
  };
}
