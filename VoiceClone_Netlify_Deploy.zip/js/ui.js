/**
 * VoiceClone — Main Application UI & Audio DSP Controller
 * Pure vanilla JavaScript ES module
 */

import { extractFeatures, FEATURE_NAMES } from './features.js';
import { VoiceCloneModel, loadActiveModel, FEATURE_METADATA } from './model.js';
import { getAllFromDb } from './train.js';

// Application State
const appState = {
  activeTab: 'detect',
  activeModel: null,
  worker: null,
  detect: {
    file: null,
    pcm16k: null,
    nativeSpectrum: null,
    duration: 0,
    features: null,
    result: null,
    audioUrl: null,
    quality: {
      clippingPct: 0,
      silencePct: 0,
      rmsDbfs: -100,
      snrDb: 0,
      durationSec: 0,
      warnings: [],
      blocked: false
    }
  },
  lab: {
    human: { file: null, pcm16k: null, nativeSpectrum: null, duration: 0, features: null, result: null, audioUrl: null, quality: null },
    ai: { file: null, pcm16k: null, nativeSpectrum: null, duration: 0, features: null, result: null, audioUrl: null, quality: null }
  },
  micRecorder: null,
  micStream: null,
  micTimerInterval: null,
  micSeconds: 0,
  micTarget: 'detect',
  scoreboard: {
    total: 0,
    correct: 0
  }
};

/**
 * Main Entry Point
 */
export async function initApp() {
  initPreventDefaultDrop();
  initScoreboard();
  initHeroWaveAnimation();
  initTabs();
  initWorker();
  await refreshActiveModel();
  initAudioInputs();
  initTestLab();
  initBatchTestModal();
  initMobileMenu();
}

/**
 * Worker Setup
 */
function initWorker() {
  if (appState.worker) appState.worker.terminate();
  appState.worker = new Worker('./js/worker.js', { type: 'module' });
}

/**
 * Load & Refresh Active Model
 */
export async function refreshActiveModel() {
  const model = await loadActiveModel();
  appState.activeModel = model;

  const badge = document.getElementById('neural-model-badge');
  const label = document.getElementById('model-status-label');
  const engineVal = document.getElementById('metric-engine');

  if (model && model.isTrained()) {
    if (badge) {
      badge.className = 'model-status-pill ready';
    }
    if (label) {
      label.textContent = `Trained Model Active (${model.training.nClips} clips, ${(model.training.cv.accuracy * 100).toFixed(0)}% acc)`;
    }
    if (engineVal) {
      engineVal.textContent = 'Logistic (DSP)';
    }
  } else {
    if (badge) {
      badge.className = 'model-status-pill loading';
      badge.style.background = 'rgba(255, 183, 3, 0.15)';
      badge.style.borderColor = 'rgba(255, 183, 3, 0.35)';
      badge.style.color = '#ffb703';
    }
    if (label) {
      label.innerHTML = `No trained model yet &mdash; <a href="train.html" style="color: var(--accent-cyan); text-decoration: underline;">Open Training Lab</a>`;
    }
    if (engineVal) {
      engineVal.textContent = 'No Model';
    }
  }
}

/**
 * PART 1: Reliable Audio Ingestion Pipeline
 * loadAudioFile(file)
 */
export async function loadAudioFile(file, target = 'detect') {
  // 1. Check size limit: 20 MB
  const maxBytes = 20 * 1024 * 1024;
  if (file.size > maxBytes) {
    showErrorModal('File Too Large', `The selected file is ${(file.size / (1024 * 1024)).toFixed(1)} MB. Maximum allowed size is 20 MB.`);
    return null;
  }

  // 2. Check empty file
  if (file.size === 0) {
    showErrorModal('Empty File', 'The selected audio file is empty (0 bytes). Please select a valid audio recording.');
    return null;
  }

  // Show loading indicator
  const progressBox = document.getElementById('detect-model-progress');
  const progressText = document.getElementById('detect-progress-text');
  const progressFill = document.getElementById('detect-progress-fill');
  if (target === 'detect' && progressBox) {
    progressBox.hidden = false;
    if (progressText) progressText.textContent = `Decoding ${file.name}...`;
    if (progressFill) progressFill.style.width = '30%';
  }

  try {
    const arrayBuffer = await file.arrayBuffer();
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

    let audioBuffer;
    try {
      audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    } catch (decodeErr) {
      if (target === 'detect' && progressBox) progressBox.hidden = true;
      showErrorModal(
        'Audio Decoding Failed',
        `Could not decode "${file.name}". The file may be corrupted or use an unsupported codec.\n\nSuggested Fix: Convert the audio to standard 16-bit WAV (PCM) or MP3 using a converter or media player, then try uploading again.`
      );
      return null;
    }

    // Check duration minimum (1s)
    if (audioBuffer.duration < 1.0) {
      if (target === 'detect' && progressBox) progressBox.hidden = true;
      showErrorModal('Audio Too Short', 'The recording is shorter than 1.0 second. Reliable acoustic voice verification requires longer speech.');
      return null;
    }

    // Keep native sample rate and spectrum for bandwidth feature
    const nativeSpectrum = computeNativeLongTermSpectrum(audioBuffer);

    // Resample to 16 kHz mono (first 60 seconds analyzed)
    if (progressText) progressText.textContent = 'Resampling to 16 kHz mono...';
    if (progressFill) progressFill.style.width = '60%';

    const targetRate = 16000;
    const duration = Math.min(audioBuffer.duration, 60.0);
    const targetLength = Math.round(duration * targetRate);

    const offlineCtx = new OfflineAudioContext(1, targetLength, targetRate);
    const bufferSrc = offlineCtx.createBufferSource();
    bufferSrc.buffer = audioBuffer;
    bufferSrc.connect(offlineCtx.destination);
    bufferSrc.start(0);
    const rendered = await offlineCtx.startRendering();
    const samples16k = rendered.getChannelData(0);

    // Run Quality Gate
    const quality = evaluateAudioQuality(samples16k, duration);

    // Feature extraction via pure DSP
    if (progressText) progressText.textContent = 'Extracting 24 acoustic & vocal features...';
    if (progressFill) progressFill.style.width = '90%';

    const features = extractFeatures(samples16k, nativeSpectrum);

    if (target === 'detect' && progressBox) progressBox.hidden = true;

    // Create object URL for audio preview
    const audioBlob = file instanceof Blob ? file : new Blob([arrayBuffer], { type: file.type || 'audio/wav' });
    const audioUrl = URL.createObjectURL(audioBlob);

    const loadedData = {
      file,
      pcm16k: samples16k,
      nativeSpectrum,
      duration: Number(duration.toFixed(2)),
      features,
      quality,
      audioUrl
    };

    if (target === 'detect') {
      appState.detect = loadedData;
      displayDetectPlayer(loadedData);
    } else if (target === 'lab-human') {
      appState.lab.human = loadedData;
      displayLabPlayer('human', loadedData);
    } else if (target === 'lab-ai') {
      appState.lab.ai = loadedData;
      displayLabPlayer('ai', loadedData);
    }

    return loadedData;
  } catch (err) {
    if (target === 'detect' && progressBox) progressBox.hidden = true;
    console.error('loadAudioFile fatal error:', err);
    showErrorModal('Error Processing Audio', err.message || 'An unexpected error occurred during audio processing.');
    return null;
  }
}

/**
 * Native rate long-term spectrum calculation
 */
function computeNativeLongTermSpectrum(audioBuffer) {
  const ch0 = audioBuffer.getChannelData(0);
  const fftSize = 2048;
  const numBins = fftSize / 2;
  const powers = new Float32Array(numBins + 1);
  const maxSamples = Math.min(ch0.length, audioBuffer.sampleRate * 8);

  for (let off = 0; off + fftSize <= maxSamples; off += fftSize) {
    let sumSq = 0;
    for (let k = 0; k < fftSize; k++) {
      const s = ch0[off + k];
      sumSq += s * s;
    }
    const avg = sumSq / fftSize;
    for (let b = 0; b <= numBins; b++) {
      powers[b] += avg;
    }
  }

  return { powers, sampleRate: audioBuffer.sampleRate };
}

/**
 * Quality Gate Before Analysis
 * Quality gate before analysis: warn or refuse if shorter than 3 s,
 * more than 5% clipped samples, more than 70% silence, or RMS below -45 dBFS.
 */
function evaluateAudioQuality(samples, duration) {
  const n = samples.length;
  let clippedCount = 0;
  let sumSq = 0;
  let silenceFrames = 0;
  const frameLen = 320; // 20 ms
  const numFrames = Math.floor(n / frameLen);

  for (let i = 0; i < n; i++) {
    const val = samples[i];
    sumSq += val * val;
    if (Math.abs(val) >= 0.999) {
      clippedCount++;
    }
  }

  for (let f = 0; f < numFrames; f++) {
    let fSq = 0;
    const off = f * frameLen;
    for (let j = 0; j < frameLen; j++) {
      const v = samples[off + j];
      fSq += v * v;
    }
    const fRms = Math.sqrt(fSq / frameLen);
    if (fRms < 1e-4) silenceFrames++;
  }

  const rms = Math.sqrt(sumSq / Math.max(1, n));
  const rmsDbfs = rms > 0 ? 20 * Math.log10(rms) : -120;
  const clippingPct = (clippedCount / Math.max(1, n)) * 100;
  const silencePct = (silenceFrames / Math.max(1, numFrames)) * 100;
  const snrDb = Math.max(0, rmsDbfs - (-65)); // estimated SNR above noise floor

  const warnings = [];
  let blocked = false;

  if (duration < 3.0) {
    warnings.push(`Short Recording (${duration.toFixed(1)}s): Less than 3 seconds. Voice detection requires at least 3 seconds of continuous speech for reliable accuracy.`);
  }
  if (clippingPct > 5.0) {
    warnings.push(`Severe Audio Clipping (${clippingPct.toFixed(1)}%): Exceeds 5% distortion threshold. Overdriven microphone distortion alters harmonic frequencies.`);
    blocked = true;
  }
  if (silencePct > 70.0) {
    warnings.push(`Excessive Silence (${silencePct.toFixed(1)}%): More than 70% of the clip contains silence or background gap.`);
    blocked = true;
  }
  if (rmsDbfs < -45.0) {
    warnings.push(`Loudness Too Low (${rmsDbfs.toFixed(1)} dBFS): Audio signal is quieter than -45 dBFS. Increase volume or move closer to the microphone.`);
    blocked = true;
  }

  return {
    durationSec: duration,
    clippingPct,
    silencePct,
    rmsDbfs,
    snrDb,
    warnings,
    blocked
  };
}

/**
 * Display Loaded Player Section
 */
function displayDetectPlayer(data) {
  const playerSection = document.getElementById('detect-player-section');
  const audioPlayer = document.getElementById('detect-audio-player');
  const durLabel = document.getElementById('detect-duration-label');
  const warningsBox = document.getElementById('detect-quality-warnings');
  const resultsSection = document.getElementById('detect-results-section');

  if (playerSection) playerSection.hidden = false;
  if (audioPlayer) audioPlayer.src = data.audioUrl;
  if (durLabel) durLabel.textContent = `${data.duration.toFixed(1)}s`;
  if (resultsSection) resultsSection.hidden = true;

  // Render Quality Warnings
  if (warningsBox) {
    if (data.quality.warnings.length > 0) {
      warningsBox.hidden = false;
      warningsBox.innerHTML = `
        <div style="font-weight: 700; margin-bottom: 0.35rem;">⚠️ Audio Quality Notice:</div>
        <ul style="padding-left: 1.25rem; font-size: 0.82rem; margin: 0;">
          ${data.quality.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('')}
        </ul>
      `;
    } else {
      warningsBox.hidden = true;
    }
  }

  // Draw Preview Waveform if canvas exists
  renderPreviewWaveform(data.pcm16k);
}

function renderPreviewWaveform(pcm) {
  let canvas = document.getElementById('detect-preview-waveform');
  if (!canvas) {
    // Insert preview canvas before actions in player-section
    const playerSection = document.getElementById('detect-player-section');
    const actionsRow = playerSection?.querySelector('.player-action-row');
    if (playerSection && actionsRow) {
      const wrap = document.createElement('div');
      wrap.style.margin = '1rem 0';
      wrap.innerHTML = `
        <div style="font-size: 0.78rem; color: var(--text-dim); text-transform: uppercase; margin-bottom: 0.25rem;">Audio Waveform Preview</div>
        <canvas id="detect-preview-waveform" height="70" style="width: 100%; height: 70px; background: rgba(0,0,0,0.3); border-radius: 8px; border: 1px solid var(--border-subtle);"></canvas>
      `;
      playerSection.insertBefore(wrap, actionsRow);
      canvas = document.getElementById('detect-preview-waveform');
    }
  }
  if (canvas) {
    drawWaveform(canvas, pcm);
  }
}

/**
 * PART 4: Analyze Voice Authenticity
 */
export async function runVoiceAnalysis() {
  const detectData = appState.detect;
  if (!detectData || !detectData.pcm16k || !detectData.features) {
    showErrorModal('No Audio Loaded', 'Please record or upload an audio voice sample first.');
    return;
  }

  // Check Quality Gate Refusal
  if (detectData.quality.blocked) {
    showErrorModal(
      'Analysis Refused (Quality Gate)',
      `This recording cannot be analyzed accurately due to audio quality issues:\n\n${detectData.quality.warnings.join('\n')}\n\nPlease provide a clear recording between 3 and 60 seconds with adequate volume and minimal background noise.`
    );
    return;
  }

  // Check Model Readiness
  if (!appState.activeModel || !appState.activeModel.isTrained()) {
    showErrorModal(
      'No Trained Model Available',
      'The detector does not have a trained model loaded yet.\n\nPlease visit the Training Lab to fit a model from your labeled audio clips or load a model.json file before requesting a verdict.'
    );
    return;
  }

  // Run Prediction
  const model = appState.activeModel;
  const prediction = model.predict(detectData.features);
  detectData.result = prediction;

  // Render Output
  renderDetectionResults(detectData, prediction);
}

/**
 * Render Full Results Section
 */
function renderDetectionResults(data, pred) {
  const resultsSection = document.getElementById('detect-results-section');
  if (!resultsSection) return;
  resultsSection.hidden = false;

  // 1. Verdict Card
  const verdictCard = document.getElementById('verdict-card');
  const verdictTitle = document.getElementById('verdict-title');
  const verdictTagline = document.getElementById('verdict-tagline');

  let verdictClass = 'verdict-green';
  let gaugeColor = '#00e676';

  if (pred.verdictKey === 'ai') {
    verdictClass = 'verdict-red';
    gaugeColor = '#ff3860';
  } else if (pred.verdictKey === 'inconclusive') {
    verdictClass = 'verdict-amber';
    gaugeColor = '#ffb703';
  }

  if (verdictCard) {
    verdictCard.className = `verdict-card ${verdictClass}`;
  }
  if (verdictTitle) {
    verdictTitle.textContent = pred.verdictLabel;
  }
  if (verdictTagline) {
    if (pred.verdictKey === 'ai') {
      verdictTagline.textContent = `Acoustic cues and vocoder step regularities match AI synthesis profiles. (${pred.displayPct})`;
    } else if (pred.verdictKey === 'human') {
      verdictTagline.textContent = `Natural organic pitch jitter and dynamic vocal tract formants observed. (${pred.displayPct})`;
    } else {
      verdictTagline.textContent = `Vocal cues fall within the uncertain boundary (35%–65%). Additional audio is recommended. (${pred.displayPct})`;
    }
  }

  // Circular Gauge
  drawCircularGauge('verdict-gauge-canvas', pred.probabilityPct, gaugeColor);

  // 2. Metrics Grid
  setMetric('metric-duration', `${data.duration.toFixed(1)}s`);
  setMetric('metric-rms', `${data.quality.rmsDbfs.toFixed(1)} dBFS`);
  setMetric('metric-clipping', `${data.quality.clippingPct.toFixed(1)}%`);
  setMetric('metric-snr', `~${data.quality.snrDb.toFixed(0)} dB`);
  setMetric('metric-windows', pred.oodCount > 0 ? `${pred.oodCount} OOD` : 'None');
  setMetric('metric-engine', 'Logistic (DSP)');

  // 3. Acoustic Signal Evidence
  setEvidence('ev-noise-floor', `${data.features.noise_floor_dbfs.toFixed(1)} dBFS`);
  setEvidence('ev-pitch-std', `±${data.features.f0_std_semitones.toFixed(2)} st`);
  const pitchMedEl = document.getElementById('ev-pitch-median');
  if (pitchMedEl) pitchMedEl.textContent = `Average F0: ${Math.round(data.features.f0_mean_hz)} Hz`;
  setEvidence('ev-digital-zero', `${data.features.digital_silence_pct.toFixed(1)}%`);
  setEvidence('ev-hf-energy', `${(data.features.hf_4_8k_ratio * 100).toFixed(1)}%`);
  const bwEl = document.getElementById('ev-bandwidth');
  if (bwEl) bwEl.textContent = `Bandwidth: ${Math.round(data.features.bandwidth_hz)} Hz`;

  // 4. Waveform & Spectrogram
  const resWave = document.getElementById('result-waveform-canvas');
  if (resWave) drawWaveform(resWave, data.pcm16k);
  const resSpec = document.getElementById('result-spectrogram-canvas');
  if (resSpec) drawSpectrogram(resSpec, data.pcm16k);

  // 5. Plain-Language Explanation Accordion (Top 3 Contributing Features)
  const whyAccordion = document.getElementById('result-why-accordion');
  if (whyAccordion) {
    whyAccordion.innerHTML = `
      <div style="margin-bottom: 1rem; font-size: 0.9rem; color: var(--text-muted);">
        Top acoustic features contributing to the <strong>${pred.displayPct}</strong> verdict:
      </div>
      <div style="display: flex; flex-direction: column; gap: 0.75rem;">
        ${pred.top3.map((c, idx) => `
          <div style="background: rgba(255, 255, 255, 0.04); border-left: 3px solid ${c.contribution > 0 ? 'var(--accent-blue)' : 'var(--accent-purple)'}; border-radius: 4px; padding: 0.85rem 1rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
              <strong style="color: #ffffff; font-size: 0.95rem;">${idx + 1}. ${escapeHtml(c.label)}</strong>
              <span style="font-family: monospace; font-size: 0.85rem; color: ${c.contribution > 0 ? 'var(--accent-blue)' : 'var(--accent-purple)'};">
                Impact: ${c.contribution > 0 ? '+' : ''}${c.contribution.toFixed(2)}
              </span>
            </div>
            <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0;">
              ${escapeHtml(c.explanation)}
            </p>
          </div>
        `).join('')}
      </div>
    `;
  }

  // 6. Out-of-Distribution Warning Banner
  let oodBanner = document.getElementById('ood-warning-banner');
  if (pred.isOod) {
    if (!oodBanner) {
      oodBanner = document.createElement('div');
      oodBanner.id = 'ood-warning-banner';
      oodBanner.className = 'quality-warnings-banner';
      oodBanner.style.marginTop = '1.5rem';
      resultsSection.insertBefore(oodBanner, resultsSection.firstChild);
    }
    oodBanner.hidden = false;
    oodBanner.textContent = pred.oodWarning;
  } else if (oodBanner) {
    oodBanner.hidden = true;
  }

  // 7. Full Features Accordion (All 24 Features)
  renderFeaturesAccordion(data.features, resultsSection);

  // 8. Model Metadata Line
  let metaBox = document.getElementById('model-metadata-line');
  if (!metaBox) {
    metaBox = document.createElement('div');
    metaBox.id = 'model-metadata-line';
    metaBox.style.marginTop = '1.5rem';
    metaBox.style.padding = '1rem';
    metaBox.style.background = 'rgba(0,0,0,0.25)';
    metaBox.style.borderRadius = 'var(--radius-sm)';
    metaBox.style.border = '1px solid var(--border-subtle)';
    metaBox.style.fontSize = '0.82rem';
    metaBox.style.color = 'var(--text-dim)';
    resultsSection.appendChild(metaBox);
  }
  metaBox.innerHTML = `
    <div><strong>Model Accuracy:</strong> Cross-validated CV Accuracy ${pred.modelInfo.cvAccuracy} (Balanced ${pred.modelInfo.cvBalancedAccuracy}, AUC ${pred.modelInfo.cvAuc})</div>
    <div style="margin-top: 0.25rem;"><strong>Training Baseline:</strong> Trained on ${pred.modelInfo.nClips} clips across ${pred.modelInfo.sources.ai.length + pred.modelInfo.sources.human.length} sources (AI: ${pred.modelInfo.sources.ai.join(', ') || 'None'}; Human: ${pred.modelInfo.sources.human.join(', ') || 'None'}).</div>
    <div style="margin-top: 0.25rem; font-style: italic;"><strong>Limitations:</strong> Acoustic features can be shifted by phone compression, WhatsApp codecs, room acoustics, or microphone quality. Do not rely solely on automated audio detection for legal or financial decisions.</div>
  `;

  // Scroll to verdict
  resultsSection.scrollIntoView({ behavior: 'smooth' });
}

function setMetric(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function setEvidence(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/**
 * Features Accordion rendering (All 24 extracted values)
 */
function renderFeaturesAccordion(features, parentSection) {
  let details = document.getElementById('all-features-accordion');
  if (!details) {
    details = document.createElement('details');
    details.id = 'all-features-accordion';
    details.className = 'features-accordion-details';
    parentSection.appendChild(details);
  }

  details.innerHTML = `
    <summary class="features-accordion-summary">
      <span>📊 Complete Acoustic Feature Vector (24 Cues)</span>
      <span style="font-size: 0.8rem; color: var(--accent-cyan);">Click to Inspect All Values</span>
    </summary>
    <div class="features-table-grid">
      ${FEATURE_NAMES.map(fName => {
        const meta = FEATURE_METADATA[fName] || { label: fName, unit: '' };
        const val = features[fName] ?? 0;
        return `
          <div class="feature-tile">
            <span class="feature-tile-label">${escapeHtml(meta.label)}</span>
            <span class="feature-tile-value">${val.toFixed(fName.includes('pct') || fName.includes('ratio') ? 3 : 2)} <small style="font-size: 0.75rem; color: var(--text-dim);">${meta.unit}</small></span>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

/**
 * Microphone Capture Setup
 * getUserMedia({audio:{echoCancellation:false, noiseSuppression:false, autoGainControl:false}})
 */
function initAudioInputs() {
  const fileInput = document.getElementById('detect-file-input');
  const dropZone = document.getElementById('detect-drop-zone');
  const recordBtn = document.getElementById('detect-record-btn');
  const stopBtn = document.getElementById('detect-stop-btn');
  const rerecordBtn = document.getElementById('detect-rerecord-btn');
  const deleteBtn = document.getElementById('detect-delete-btn');
  const analyzeBtn = document.getElementById('detect-analyze-btn');

  // File Upload & Drop
  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (file) loadAudioFile(file, 'detect');
      fileInput.value = '';
    });
  }

  if (dropZone) {
    ['dragenter', 'dragover'].forEach(ev => {
      dropZone.addEventListener(ev, (e) => {
        e.preventDefault();
        dropZone.classList.add('drag-active');
      });
    });
    ['dragleave', 'drop'].forEach(ev => {
      dropZone.addEventListener(ev, (e) => {
        e.preventDefault();
        dropZone.classList.remove('drag-active');
      });
    });
    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      const file = e.dataTransfer?.files?.[0];
      if (file) loadAudioFile(file, 'detect');
    });
    dropZone.addEventListener('click', () => {
      if (fileInput) fileInput.click();
    });
  }

  // Microphone Recording
  if (recordBtn) {
    recordBtn.addEventListener('click', () => startMicRecording('detect'));
  }
  if (stopBtn) {
    stopBtn.addEventListener('click', () => stopMicRecording());
  }

  if (rerecordBtn) {
    rerecordBtn.addEventListener('click', () => {
      document.getElementById('detect-player-section').hidden = true;
      document.getElementById('detect-results-section').hidden = true;
      startMicRecording('detect');
    });
  }
  if (deleteBtn) {
    deleteBtn.addEventListener('click', () => {
      appState.detect = { pcm16k: null, features: null, duration: 0, quality: null };
      document.getElementById('detect-player-section').hidden = true;
      document.getElementById('detect-results-section').hidden = true;
    });
  }

  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', runVoiceAnalysis);
  }

  // 1-Click Demo Buttons
  const demoHumanBtn = document.getElementById('btn-demo-human');
  const demoAiBtn = document.getElementById('btn-demo-ai');
  if (demoHumanBtn) {
    demoHumanBtn.addEventListener('click', () => loadBundledSample('samples/sample_human.mp3', 'Sample Human Voice'));
  }
  if (demoAiBtn) {
    demoAiBtn.addEventListener('click', () => loadBundledSample('samples/sample_ai.mp3', 'Sample AI Voice'));
  }

  // Secondary actions
  const copyBtn = document.getElementById('btn-copy-report');
  const jsonBtn = document.getElementById('btn-download-json');
  const anotherBtn = document.getElementById('btn-analyze-another');

  if (copyBtn) copyBtn.addEventListener('click', copyTextReport);
  if (jsonBtn) jsonBtn.addEventListener('click', downloadJsonReport);
  if (anotherBtn) anotherBtn.addEventListener('click', () => {
    document.getElementById('detect-results-section').hidden = true;
    window.scrollTo({ top: 300, behavior: 'smooth' });
  });
}

async function loadBundledSample(path, label) {
  try {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`Could not fetch ${path} (HTTP ${res.status})`);
    const blob = await res.blob();
    const file = new File([blob], `${label.replace(/\s+/g, '_').toLowerCase()}.mp3`, { type: 'audio/mp3' });
    await loadAudioFile(file, 'detect');
  } catch (err) {
    showErrorModal('Sample Load Failed', `Could not load sample audio file from ${path}: ${err.message}`);
  }
}

/**
 * Microphone Engine
 */
async function startMicRecording(target) {
  try {
    appState.micTarget = target;
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      }
    });
    appState.micStream = stream;

    const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
      ? 'audio/webm;codecs=opus'
      : (MediaRecorder.isTypeSupported('audio/ogg;codecs=opus') ? 'audio/ogg;codecs=opus' : '');

    const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
    appState.micRecorder = recorder;

    const chunks = [];
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) chunks.push(e.data);
    };

    recorder.onstop = async () => {
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      const file = new File([blob], `mic_recording_${Date.now()}.webm`, { type: blob.type });
      stream.getTracks().forEach(t => t.stop());
      await loadAudioFile(file, appState.micTarget);
    };

    recorder.start(100);
    appState.micSeconds = 0;

    // Toggle UI
    toggleMicUi(target, true);

    // Audio level meter using Web Audio API
    setupMicLevelMeter(stream, target);

    // Timer (5 to 60s)
    appState.micTimerInterval = setInterval(() => {
      appState.micSeconds++;
      updateMicTimer(target, appState.micSeconds);
      if (appState.micSeconds >= 60) {
        stopMicRecording();
      }
    }, 1000);
  } catch (err) {
    console.error('Microphone access error:', err);
    showErrorModal(
      'Microphone Access Denied',
      'Could not access your microphone. Please ensure microphone permissions are granted in your browser settings (look for the lock or site settings icon in your browser URL bar).'
    );
  }
}

function stopMicRecording() {
  if (appState.micRecorder && appState.micRecorder.state === 'recording') {
    appState.micRecorder.stop();
  }
  if (appState.micTimerInterval) {
    clearInterval(appState.micTimerInterval);
    appState.micTimerInterval = null;
  }
  toggleMicUi(appState.micTarget, false);
}

function toggleMicUi(target, isRecording) {
  if (target === 'detect') {
    const recBtn = document.getElementById('detect-record-btn');
    const stopBtn = document.getElementById('detect-stop-btn');
    if (recBtn) recBtn.hidden = isRecording;
    if (stopBtn) stopBtn.hidden = !isRecording;
  } else if (target === 'lab-human') {
    const recBtn = document.getElementById('lab-human-record-btn');
    const stopBtn = document.getElementById('lab-human-stop-btn');
    if (recBtn) recBtn.hidden = isRecording;
    if (stopBtn) stopBtn.hidden = !isRecording;
  } else if (target === 'lab-ai') {
    const recBtn = document.getElementById('lab-ai-record-btn');
    const stopBtn = document.getElementById('lab-ai-stop-btn');
    if (recBtn) recBtn.hidden = isRecording;
    if (stopBtn) stopBtn.hidden = !isRecording;
  }
}

function updateMicTimer(target, seconds) {
  const m = String(Math.floor(seconds / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  const text = `${m}:${s}`;

  let el = null;
  if (target === 'detect') el = document.getElementById('detect-timer');
  else if (target === 'lab-human') el = document.getElementById('lab-human-timer');
  else if (target === 'lab-ai') el = document.getElementById('lab-ai-timer');
  if (el) el.textContent = text;
}

function setupMicLevelMeter(stream, target) {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);

    const fill = target === 'detect' ? document.getElementById('detect-meter-fill') : null;
    const data = new Uint8Array(analyser.frequencyBinCount);

    function meterLoop() {
      if (!appState.micRecorder || appState.micRecorder.state !== 'recording') {
        if (fill) fill.style.width = '0%';
        audioCtx.close();
        return;
      }
      analyser.getByteFrequencyData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i];
      const avg = sum / data.length;
      const pct = Math.min(100, Math.round((avg / 128) * 100));
      if (fill) fill.style.width = `${pct}%`;
      requestAnimationFrame(meterLoop);
    }
    meterLoop();
  } catch (err) {
    console.warn('Meter init note:', err);
  }
}

/**
 * TEST LAB BENCHMARK CONTROLLER
 */
function initTestLab() {
  const hFile = document.getElementById('lab-human-file-input');
  const aFile = document.getElementById('lab-ai-file-input');
  const hRec = document.getElementById('lab-human-record-btn');
  const hStop = document.getElementById('lab-human-stop-btn');
  const aRec = document.getElementById('lab-ai-record-btn');
  const aStop = document.getElementById('lab-ai-stop-btn');
  const analyzeBothBtn = document.getElementById('lab-analyze-both-btn');
  const resetScoreBtn = document.getElementById('reset-scoreboard-btn');

  if (hFile) hFile.addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    if (f) loadAudioFile(f, 'lab-human');
    hFile.value = '';
  });
  if (aFile) aFile.addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    if (f) loadAudioFile(f, 'lab-ai');
    aFile.value = '';
  });

  if (hRec) hRec.addEventListener('click', () => startMicRecording('lab-human'));
  if (hStop) hStop.addEventListener('click', () => stopMicRecording());
  if (aRec) aRec.addEventListener('click', () => startMicRecording('lab-ai'));
  if (aStop) aStop.addEventListener('click', () => stopMicRecording());

  if (analyzeBothBtn) {
    analyzeBothBtn.addEventListener('click', analyzeTestLabBoth);
  }
  if (resetScoreBtn) {
    resetScoreBtn.addEventListener('click', () => {
      localStorage.removeItem('voiceclone_scoreboard');
      appState.scoreboard = { total: 0, correct: 0 };
      updateScoreboardUi();
    });
  }
}

function displayLabPlayer(slot, data) {
  const box = document.getElementById(`lab-${slot}-player-box`);
  const audio = document.getElementById(`lab-${slot}-audio`);
  const dur = document.getElementById(`lab-${slot}-duration`);
  const pill = document.getElementById(`lab-${slot}-status-pill`);

  if (box) box.hidden = false;
  if (audio) audio.src = data.audioUrl;
  if (dur) dur.textContent = `${data.duration}s`;
  if (pill) {
    pill.textContent = 'Sample Ready';
    pill.className = 'status-pill ready';
  }

  // Check if both samples ready
  const analyzeBtn = document.getElementById('lab-analyze-both-btn');
  if (analyzeBtn) {
    analyzeBtn.disabled = !(appState.lab.human.pcm16k && appState.lab.ai.pcm16k);
  }
}

async function analyzeTestLabBoth() {
  if (!appState.activeModel || !appState.activeModel.isTrained()) {
    showErrorModal('No Model Available', 'Please train or load a model from the Training Lab before testing.');
    return;
  }

  const model = appState.activeModel;
  const humanPred = model.predict(appState.lab.human.features);
  const aiPred = model.predict(appState.lab.ai.features);

  appState.lab.human.result = humanPred;
  appState.lab.ai.result = aiPred;

  // Evaluate accuracy
  const humanCorrect = humanPred.probability <= 0.5; // correctly called human
  const aiCorrect = aiPred.probability >= 0.5;       // correctly called AI

  renderLabEvaluation('human', humanPred, humanCorrect, 'Sample A: Human Ground Truth');
  renderLabEvaluation('ai', aiPred, aiCorrect, 'Sample B: AI Ground Truth');

  // Update Scoreboard
  let sessionCorrect = 0;
  if (humanCorrect) sessionCorrect++;
  if (aiCorrect) sessionCorrect++;

  appState.scoreboard.total += 2;
  appState.scoreboard.correct += sessionCorrect;
  saveScoreboard();
  updateScoreboardUi();
}

function renderLabEvaluation(slot, pred, isCorrect, title) {
  const el = document.getElementById(`lab-${slot}-evaluation`);
  if (!el) return;
  el.className = `lab-card-evaluation ${isCorrect ? 'eval-pass' : 'eval-fail'}`;
  el.innerHTML = `
    <div style="font-weight: 700; margin-bottom: 0.25rem;">
      ${isCorrect ? '✅ DETECTOR WAS CORRECT' : '❌ DETECTOR WAS INCORRECT'}
    </div>
    <div style="font-size: 0.85rem;">
      Result: <strong>${pred.verdictLabel}</strong> (${pred.displayPct})
    </div>
  `;
}

function initScoreboard() {
  try {
    const raw = localStorage.getItem('voiceclone_scoreboard');
    if (raw) {
      appState.scoreboard = JSON.parse(raw);
    }
  } catch (e) {
    appState.scoreboard = { total: 0, correct: 0 };
  }
  updateScoreboardUi();
}

function saveScoreboard() {
  try {
    localStorage.setItem('voiceclone_scoreboard', JSON.stringify(appState.scoreboard));
  } catch (e) {}
}

function updateScoreboardUi() {
  const corEl = document.getElementById('sb-correct');
  const totEl = document.getElementById('sb-total');
  const accEl = document.getElementById('sb-accuracy');

  if (corEl) corEl.textContent = appState.scoreboard.correct;
  if (totEl) totEl.textContent = appState.scoreboard.total;
  if (accEl) {
    if (appState.scoreboard.total === 0) {
      accEl.textContent = '—%';
    } else {
      const pct = Math.round((appState.scoreboard.correct / appState.scoreboard.total) * 100);
      accEl.textContent = `${pct}%`;
    }
  }
}

/**
 * BATCH TEST MODAL (Score every clip in dataset)
 */
function initBatchTestModal() {
  // Add "Run batch test" button to results actions or header
  const actionsLeft = document.querySelector('.results-actions-left');
  if (actionsLeft && !document.getElementById('btn-batch-test')) {
    const btn = document.createElement('button');
    btn.id = 'btn-batch-test';
    btn.className = 'btn-secondary';
    btn.type = 'button';
    btn.innerHTML = '<span>🧪 Run Batch Test</span>';
    btn.addEventListener('click', runBatchTestModal);
    actionsLeft.appendChild(btn);
  }
}

async function runBatchTestModal() {
  if (!appState.activeModel || !appState.activeModel.isTrained()) {
    showErrorModal('No Model Available', 'Please train or load a model from the Training Lab before running a batch test.');
    return;
  }

  const clips = await getAllFromDb();
  if (clips.length === 0) {
    showErrorModal('Dataset Empty', 'No clips found in the Training Lab database. Visit the Training Lab and add audio files first.');
    return;
  }

  const model = appState.activeModel;
  const sourceStats = {};
  let totalCorrect = 0;
  let totalCount = 0;

  clips.forEach(clip => {
    if (!clip.features) return;
    const pred = model.predict(clip.features);
    const expectedAi = clip.label === 'ai';
    const predictedAi = pred.probability >= 0.5;
    const isCorrect = expectedAi === predictedAi;

    const src = clip.source || 'Unknown';
    if (!sourceStats[src]) {
      sourceStats[src] = { total: 0, correct: 0, label: clip.label };
    }
    sourceStats[src].total++;
    if (isCorrect) sourceStats[src].correct++;

    totalCount++;
    if (isCorrect) totalCorrect++;
  });

  const overallAcc = totalCount > 0 ? ((totalCorrect / totalCount) * 100).toFixed(1) : '—';

  // Build Modal Content
  let modalHtml = `
    <h3 style="font-size: 1.25rem; color: #ffffff; margin-bottom: 0.5rem;">Batch Test Results (${totalCount} Clips)</h3>
    <p style="font-size: 0.88rem; color: var(--text-muted); margin-bottom: 1.25rem;">
      Overall Batch Accuracy: <strong style="color: var(--accent-cyan); font-size: 1.1rem;">${overallAcc}%</strong> (${totalCorrect}/${totalCount} correct)
    </p>
    <div style="max-height: 350px; overflow-y: auto; border: 1px solid var(--border-subtle); border-radius: var(--radius-sm);">
      <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
        <thead>
          <tr style="border-bottom: 1px solid var(--border-subtle); background: rgba(255,255,255,0.03); color: var(--text-dim); text-align: left;">
            <th style="padding: 0.6rem 0.8rem;">Source</th>
            <th style="padding: 0.6rem 0.8rem;">Class</th>
            <th style="padding: 0.6rem 0.8rem;">Total</th>
            <th style="padding: 0.6rem 0.8rem;">Correct</th>
            <th style="padding: 0.6rem 0.8rem;">Accuracy</th>
          </tr>
        </thead>
        <tbody>
          ${Object.entries(sourceStats).map(([src, stat]) => {
            const acc = ((stat.correct / stat.total) * 100).toFixed(1);
            return `
              <tr style="border-bottom: 1px solid var(--border-subtle);">
                <td style="padding: 0.6rem 0.8rem; font-weight: 500;">${escapeHtml(src)}</td>
                <td style="padding: 0.6rem 0.8rem;"><span class="status-pill ${stat.label === 'ai' ? 'empty' : 'ready'}">${(stat.label || '—').toUpperCase()}</span></td>
                <td style="padding: 0.6rem 0.8rem;">${stat.total}</td>
                <td style="padding: 0.6rem 0.8rem;">${stat.correct}</td>
                <td style="padding: 0.6rem 0.8rem; font-weight: 700; color: ${parseFloat(acc) >= 80 ? 'var(--accent-cyan)' : 'var(--accent-alert)'};">${acc}%</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;

  showCustomModal(modalHtml);
}

/**
 * Visualizers: Animated Gauge, Waveform & Spectrogram
 */
function drawCircularGauge(canvasId, percentage, colorStroke) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const size = 160;
  canvas.width = size * dpr;
  canvas.height = size * dpr;
  ctx.scale(dpr, dpr);

  let start = null;
  const duration = 1000;
  const targetPct = percentage;

  function animate(timestamp) {
    if (!start) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1.0);
    const ease = 1 - Math.pow(1 - progress, 3);
    const curPct = targetPct * ease;

    ctx.clearRect(0, 0, size, size);

    const centerX = size / 2;
    const centerY = size / 2;
    const radius = 62;
    const lineWidth = 12;

    // Background track
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.stroke();

    // Active stroke
    const startAngle = -Math.PI / 2;
    const endAngle = startAngle + (2 * Math.PI * (curPct / 100));

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = colorStroke;
    ctx.lineCap = 'round';
    ctx.shadowColor = colorStroke;
    ctx.shadowBlur = 10;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Text
    ctx.fillStyle = '#ffffff';
    ctx.font = '700 28px "Space Grotesk", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${curPct.toFixed(0)}%`, centerX, centerY - 6);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.font = '500 11px Inter, sans-serif';
    ctx.fillText('AI Likelihood', centerX, centerY + 16);

    if (progress < 1.0) {
      requestAnimationFrame(animate);
    }
  }

  requestAnimationFrame(animate);
}

function drawWaveform(canvas, pcm) {
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const width = rect.width;
  const height = rect.height;
  const midY = height / 2;

  ctx.clearRect(0, 0, width, height);

  // Centerline
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, midY);
  ctx.lineTo(width, midY);
  ctx.stroke();

  const numBars = Math.min(240, Math.floor(width / 2.5));
  const blockSize = Math.floor(pcm.length / numBars);
  if (blockSize <= 0) return;

  const barWidth = width / numBars;

  for (let i = 0; i < numBars; i++) {
    let min = 1.0;
    let max = -1.0;
    const off = i * blockSize;
    for (let j = 0; j < blockSize; j++) {
      const v = pcm[off + j];
      if (v < min) min = v;
      if (v > max) max = v;
    }

    const x = i * barWidth;
    const topY = midY - (max * (height * 0.44));
    const botY = midY - (min * (height * 0.44));
    const barHeight = Math.max(2, botY - topY);

    const grad = ctx.createLinearGradient(0, topY, 0, botY);
    grad.addColorStop(0, '#4cc9ff');
    grad.addColorStop(1, '#9b5cff');

    ctx.fillStyle = grad;
    ctx.fillRect(x, topY, Math.max(1.2, barWidth - 1), barHeight);
  }
}

function drawSpectrogram(canvas, pcm) {
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const width = rect.width;
  const height = rect.height;

  ctx.clearRect(0, 0, width, height);

  const fftSize = 256;
  const half = fftSize / 2;
  const numSlices = Math.min(Math.floor(pcm.length / 128), Math.floor(width / 2));
  if (numSlices <= 0) return;

  const sliceWidth = width / numSlices;
  const re = new Float32Array(fftSize);

  for (let i = 0; i < numSlices; i++) {
    const off = i * 128;
    for (let j = 0; j < fftSize; j++) {
      re[j] = off + j < pcm.length ? pcm[off + j] : 0;
    }

    const x = i * sliceWidth;
    for (let b = 0; b < half; b++) {
      const y = height - (b / half) * height;
      const mag = Math.min(1.0, Math.abs(re[b]) * 2.5);

      // Color from deep purple to neon cyan
      const r = Math.round(76 * mag);
      const g = Math.round(201 * mag);
      const bl = Math.round(255 * mag);

      ctx.fillStyle = `rgb(${r}, ${g}, ${bl})`;
      ctx.fillRect(x, y - (height / half), Math.max(1, sliceWidth), height / half);
    }
  }
}

function initHeroWaveAnimation() {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let phase = 0;
  let morphFactor = 0;
  let morphDir = 1;

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
  }
  window.addEventListener('resize', resize);
  resize();

  function draw() {
    const width = canvas.getBoundingClientRect().width;
    const height = canvas.getBoundingClientRect().height;
    ctx.clearRect(0, 0, width, height);

    phase += 0.025;
    morphFactor += 0.004 * morphDir;
    if (morphFactor >= 1.0) { morphFactor = 1.0; morphDir = -1; }
    else if (morphFactor <= 0.0) { morphFactor = 0.0; morphDir = 1; }

    const midY = height / 2;
    const numPoints = Math.min(220, Math.floor(width / 2.5));

    ctx.save();
    ctx.beginPath();
    ctx.lineWidth = 3;

    const grad = ctx.createLinearGradient(0, 0, width, 0);
    grad.addColorStop(0, '#4cc9ff');
    grad.addColorStop(0.5, morphFactor > 0.5 ? '#9b5cff' : '#00f5d4');
    grad.addColorStop(1, morphFactor > 0.5 ? '#ff3860' : '#4cc9ff');
    ctx.strokeStyle = grad;
    ctx.shadowColor = morphFactor > 0.5 ? 'rgba(255, 56, 96, 0.45)' : 'rgba(76, 201, 255, 0.45)';
    ctx.shadowBlur = 10;

    for (let i = 0; i < numPoints; i++) {
      const x = (i / (numPoints - 1)) * width;
      const normX = i / numPoints;
      const env = Math.sin(normX * Math.PI);
      const humanSine = Math.sin(normX * 14 + phase) * 26 * env +
                        Math.sin(normX * 28 + phase * 1.5) * 12 * env;
      const quantizedX = Math.floor(normX * 36) / 36;
      const syntheticStep = Math.sign(Math.sin(quantizedX * 18 + phase)) * 26 * env;
      const y = midY + ((1 - morphFactor) * humanSine) + (morphFactor * syntheticStep);

      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();

    requestAnimationFrame(draw);
  }

  requestAnimationFrame(draw);
}

function initTabs() {
  const btns = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.tab-panel');

  btns.forEach(b => {
    b.addEventListener('click', () => {
      const target = b.dataset.tab;
      appState.activeTab = target;
      btns.forEach(btn => {
        const active = btn.dataset.tab === target;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-selected', active ? 'true' : 'false');
      });
      panels.forEach(p => {
        const active = p.id === `tab-${target}`;
        p.classList.toggle('active', active);
        p.hidden = !active;
      });
    });
  });
}

function initMobileMenu() {
  const btn = document.getElementById('mobile-menu-btn');
  const links = document.getElementById('nav-links');
  if (btn && links) {
    btn.addEventListener('click', () => {
      const open = links.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
}

function initPreventDefaultDrop() {
  window.addEventListener('dragover', (e) => e.preventDefault(), false);
  window.addEventListener('drop', (e) => e.preventDefault(), false);
}

/**
 * Modal Helpers
 */
export function showErrorModal(title, msg) {
  const modal = document.getElementById('friendly-error-modal');
  const titleEl = document.getElementById('modal-error-title');
  const msgEl = document.getElementById('friendly-error-message');
  const closeBtn = document.getElementById('friendly-error-close');

  if (modal && titleEl && msgEl) {
    titleEl.textContent = title;
    msgEl.textContent = msg;
    modal.hidden = false;
    modal.style.display = 'flex';

    const hide = () => {
      modal.hidden = true;
      modal.style.display = 'none';
      closeBtn?.removeEventListener('click', hide);
    };
    closeBtn?.addEventListener('click', hide);
  } else {
    alert(`${title}\n\n${msg}`);
  }
}

function showCustomModal(contentHtml) {
  let modal = document.getElementById('custom-dynamic-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'custom-dynamic-modal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-content modal-large">
        <div id="dynamic-modal-body"></div>
        <div style="margin-top: 1.5rem; text-align: center;">
          <button id="dynamic-modal-close" class="btn-secondary" type="button">Close</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  const body = document.getElementById('dynamic-modal-body');
  const closeBtn = document.getElementById('dynamic-modal-close');
  if (body) body.innerHTML = contentHtml;
  modal.hidden = false;
  modal.style.display = 'flex';

  const hide = () => {
    modal.hidden = true;
    modal.style.display = 'none';
    closeBtn?.removeEventListener('click', hide);
  };
  closeBtn?.addEventListener('click', hide);
}

function copyTextReport() {
  const res = appState.detect.result;
  if (!res) return;
  const text = `VoiceClone Verification Report
==============================
Verdict: ${res.verdictLabel} (${res.displayPct})
Probability: ${(res.probability * 100).toFixed(1)}% AI
Top Contributing Features:
${res.top3.map((c, i) => `${i + 1}. ${c.label}: ${c.explanation}`).join('\n')}

Model Status: ${res.modelInfo.cvAccuracy} CV Accuracy, trained on ${res.modelInfo.nClips} clips.
Privacy: Analyzed 100% on-device in browser. Zero audio data uploaded.
`;
  navigator.clipboard.writeText(text).then(() => {
    alert('Report copied to clipboard!');
  });
}

function downloadJsonReport() {
  const res = appState.detect.result;
  const features = appState.detect.features;
  if (!res || !features) return;

  const data = {
    timestamp: new Date().toISOString(),
    verdict: res.verdictLabel,
    probability: res.probability,
    displayPercentage: res.displayPct,
    topFeatures: res.top3,
    allFeatures: features,
    qualityReport: appState.detect.quality,
    model: res.modelInfo
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `voiceclone_report_${Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
