/**
 * VoiceClone — Model Representation, Inference & Explanations
 * Pure vanilla JavaScript ES module
 */

import { FEATURE_NAMES } from './features.js';

export const LOCAL_STORAGE_MODEL_KEY = 'voiceclone_model';

/**
 * Human-friendly names and explanation generators for the 24 features
 */
export const FEATURE_METADATA = {
  noise_floor_dbfs: {
    label: 'Background Noise Floor',
    unit: 'dBFS',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Quiet-pause noise floor is ${val.toFixed(1)} dBFS (training avg: Human ${refHuman?.toFixed(1) ?? '—'}, AI ${refAi?.toFixed(1) ?? '—'}).`
  },
  dyn_range_db: {
    label: 'Dynamic Range',
    unit: 'dB',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Speech volume dynamic range is ${val.toFixed(1)} dB (training avg: Human ${refHuman?.toFixed(1) ?? '—'}, AI ${refAi?.toFixed(1) ?? '—'}).`
  },
  digital_silence_pct: {
    label: 'Digital Silence Frames',
    unit: '%',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Zero-energy artificial silence occupies ${val.toFixed(1)}% of pauses (AI synthesizers often mute to absolute zero).`
  },
  bandwidth_hz: {
    label: 'Effective Audio Bandwidth',
    unit: 'Hz',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Acoustic frequency cutoff is ${Math.round(val)} Hz (training avg: Human ${Math.round(refHuman ?? 0)}, AI ${Math.round(refAi ?? 0)}).`
  },
  spec_flatness: {
    label: 'Spectral Flatness (Noise vs Tone)',
    unit: '',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Spectral tonality flatness is ${val.toFixed(4)} (natural speech exhibits distinct formant resonance bands).`
  },
  spec_centroid_hz: {
    label: 'Spectral Center of Mass',
    unit: 'Hz',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Frequency center of mass is ${Math.round(val)} Hz (training avg: Human ${Math.round(refHuman ?? 0)}, AI ${Math.round(refAi ?? 0)}).`
  },
  rolloff95_hz: {
    label: '95% Spectral Rolloff',
    unit: 'Hz',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `95% of speech energy lies below ${Math.round(val)} Hz.`
  },
  hf_4_8k_ratio: {
    label: 'High-Frequency (4-8 kHz) Energy',
    unit: '',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Share of energy above 4 kHz is ${(val * 100).toFixed(1)}% (training avg: Human ${((refHuman ?? 0) * 100).toFixed(1)}%, AI ${((refAi ?? 0) * 100).toFixed(1)}%).`
  },
  spec_flux_cv: {
    label: 'Spectral Flux Variability',
    unit: '',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Frame-to-frame timbre flux variation is ${val.toFixed(3)}.`
  },
  mfcc_temporal_std: {
    label: 'Phonetic Timbre Variance (MFCC Std)',
    unit: '',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Vocal tract timbre dispersion across time is ${val.toFixed(2)} (AI speech can exhibit unnatural phonetic stiffness).`
  },
  mfcc_delta_mean: {
    label: 'Speech Articulation Speed (MFCC Delta)',
    unit: '',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Mean phonetic transition velocity is ${val.toFixed(2)}.`
  },
  f0_mean_hz: {
    label: 'Average Pitch (F0)',
    unit: 'Hz',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Fundamental pitch average is ${val.toFixed(1)} Hz.`
  },
  f0_std_semitones: {
    label: 'Pitch Expressiveness (F0 Std)',
    unit: 'st',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Pitch standard deviation is ${val.toFixed(2)} semitones (training avg: Human ${refHuman?.toFixed(2) ?? '—'}, AI ${refAi?.toFixed(2) ?? '—'}).`
  },
  f0_range_semitones: {
    label: 'Pitch Range (5th to 95th Percentile)',
    unit: 'st',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Overall pitch span is ${val.toFixed(2)} semitones (natural human speech has dynamic pitch contours).`
  },
  voiced_pct: {
    label: 'Voiced Speech Percentage',
    unit: '%',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Voiced speech segments constitute ${val.toFixed(1)}% of the total recording.`
  },
  f0_flat_step_pct: {
    label: 'Quantized Monotone Pitch Steps',
    unit: '%',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Monotone pitch plateaus (<0.5 Hz change between frames) occur in ${val.toFixed(1)}% of speech (characteristic of synthetic pitch grids).`
  },
  hnr_mean_db: {
    label: 'Harmonics-to-Noise Ratio (HNR)',
    unit: 'dB',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Average harmonic clarity is ${val.toFixed(1)} dB (AI synthesizers produce exceptionally clean harmonic overtone tracks).`
  },
  hnr_std_db: {
    label: 'HNR Stability',
    unit: 'dB',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Variability in harmonic overtone purity is ${val.toFixed(2)} dB.`
  },
  amp_frame_shimmer_pct: {
    label: 'Vocal Amplitude Shimmer',
    unit: '%',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Frame-to-frame vocal shimmer is ${val.toFixed(2)}% (human vocal cord vibrations have natural involuntary micro-fluctuations).`
  },
  pause_per_10s: {
    label: 'Pauses per 10 Seconds',
    unit: '',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Cadence rate of ${val.toFixed(1)} pauses per 10 s (training avg: Human ${refHuman?.toFixed(1) ?? '—'}, AI ${refAi?.toFixed(1) ?? '—'}).`
  },
  pause_mean_s: {
    label: 'Average Pause Duration',
    unit: 's',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Average pause length is ${val.toFixed(2)} s (human pauses reflect natural breathing rhythms).`
  },
  pause_cv: {
    label: 'Pause Duration Irregularity (CV)',
    unit: '',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Pause timing regularity coefficient is ${val.toFixed(2)} (AI sentences frequently space words with uniform pauses).`
  },
  mod_peak_hz: {
    label: 'Syllabic Modulation Rate',
    unit: 'Hz',
    higherMeansAi: false,
    explain: (val, refHuman, refAi) => `Speech rhythm peak is ${val.toFixed(2)} Hz (typical human conversational pace is 3-6 Hz).`
  },
  mod_peak_ratio: {
    label: 'Rhythmic Envelope Dominance',
    unit: '',
    higherMeansAi: true,
    explain: (val, refHuman, refAi) => `Rhythmic cadence dominance in the 2-8 Hz syllable band is ${(val * 100).toFixed(1)}%.`
  }
};

/**
 * VoiceClone Trained Model Class
 */
export class VoiceCloneModel {
  constructor(data) {
    this.version = data.version || '1.0.0';
    this.trainedAt = data.trainedAt || null;
    this.featureNames = data.featureNames || [...FEATURE_NAMES];
    this.mean = data.mean || {};
    this.std = data.std || {};
    this.weights = data.weights || {};
    this.bias = typeof data.bias === 'number' ? data.bias : 0.0;
    this.threshold = typeof data.threshold === 'number' ? data.threshold : 0.50;
    this.uncertainBand = data.uncertainBand || [0.35, 0.65];
    this.ood = data.ood || { mean: {}, std: {} };
    this.training = data.training || {
      nClips: 0,
      sources: { ai: [], human: [] },
      cv: { accuracy: 0, balancedAccuracy: 0, auc: 0 }
    };
  }

  isTrained() {
    return (
      Boolean(this.trainedAt) &&
      Object.keys(this.weights).length > 0 &&
      this.featureNames.length > 0
    );
  }

  /**
   * Run inference on extracted feature vector
   * 
   * @param {Object} features - Object containing extracted feature keys
   * @returns {Object} Prediction details: probability, verdict, contributions, OOD status
   */
  predict(features) {
    if (!this.isTrained()) {
      throw new Error('Cannot predict: No trained model loaded');
    }

    let logit = this.bias;
    const standardized = {};
    const contributions = [];
    let oodCount = 0;

    for (const fName of this.featureNames) {
      const val = typeof features[fName] === 'number' ? features[fName] : 0;
      const m = typeof this.mean[fName] === 'number' ? this.mean[fName] : 0;
      const s = (typeof this.std[fName] === 'number' && this.std[fName] > 1e-8) ? this.std[fName] : 1.0;
      const z = (val - m) / s;
      standardized[fName] = z;

      // Check OOD (|z| > 4)
      if (Math.abs(z) > 4.0) {
        oodCount++;
      }

      const w = typeof this.weights[fName] === 'number' ? this.weights[fName] : 0;
      const contrib = w * z;
      logit += contrib;

      contributions.push({
        feature: fName,
        value: val,
        zScore: z,
        weight: w,
        contribution: contrib,
        label: FEATURE_METADATA[fName]?.label || fName,
        meta: FEATURE_METADATA[fName] || {}
      });
    }

    // Sigmoid function for P(AI)
    const probAi = 1 / (1 + Math.exp(-Math.max(-50, Math.min(50, logit))));
    const probPct = Math.round(probAi * 100);

    // Hard rule verdict boundaries:
    // >= 0.65 => Likely AI-generated
    // <= 0.35 => Likely human
    // Otherwise => Inconclusive
    let verdictKey = 'inconclusive';
    let verdictLabel = 'Inconclusive';
    if (probAi >= (this.uncertainBand[1] ?? 0.65)) {
      verdictKey = 'ai';
      verdictLabel = 'Likely AI-generated';
    } else if (probAi <= (this.uncertainBand[0] ?? 0.35)) {
      verdictKey = 'human';
      verdictLabel = 'Likely human';
    }

    // Sort contributions:
    // If prediction leans AI (prob >= 0.5), show top features pushing towards AI (largest positive contribution)
    // If prediction leans human (prob < 0.5), show top features pushing towards Human (most negative contribution)
    const sortedContribs = [...contributions].sort((a, b) => {
      if (probAi >= 0.5) {
        return b.contribution - a.contribution;
      } else {
        return a.contribution - b.contribution;
      }
    });

    const top3 = sortedContribs.slice(0, 3).map(c => {
      const refHuman = this.training?.featureAverages?.human?.[c.feature] ?? this.mean[c.feature];
      const refAi = this.training?.featureAverages?.ai?.[c.feature] ?? this.mean[c.feature];
      const explanation = c.meta.explain
        ? c.meta.explain(c.value, refHuman, refAi)
        : `${c.label}: value ${c.value.toFixed(2)} (contribution ${c.contribution > 0 ? '+' : ''}${c.contribution.toFixed(2)})`;
      return {
        ...c,
        explanation,
        refHuman,
        refAi
      };
    });

    const isOod = oodCount >= 3;

    return {
      probability: probAi,
      probabilityPct: probPct,
      displayPct: `AI-likelihood ${probPct}%`,
      verdictKey,
      verdictLabel,
      logit,
      contributions,
      top3,
      oodCount,
      isOod,
      oodWarning: isOod
        ? '⚠️ This recording looks unlike the data I was trained on (3+ features deviate significantly), so treat the result as unreliable.'
        : null,
      modelInfo: {
        nClips: this.training?.nClips || 0,
        sources: this.training?.sources || { ai: [], human: [] },
        cvAccuracy: this.training?.cv?.accuracy != null ? (this.training.cv.accuracy * 100).toFixed(1) + '%' : '—',
        cvBalancedAccuracy: this.training?.cv?.balancedAccuracy != null ? (this.training.cv.balancedAccuracy * 100).toFixed(1) + '%' : '—',
        cvAuc: this.training?.cv?.auc != null ? this.training.cv.auc.toFixed(2) : '—'
      }
    };
  }

  toJSON() {
    return {
      version: this.version,
      trainedAt: this.trainedAt,
      featureNames: this.featureNames,
      mean: this.mean,
      std: this.std,
      weights: this.weights,
      bias: this.bias,
      threshold: this.threshold,
      uncertainBand: this.uncertainBand,
      ood: this.ood,
      training: this.training
    };
  }
}

/**
 * Model Persistence Helpers
 */
export function saveModelToStorage(model) {
  try {
    const jsonStr = JSON.stringify(model.toJSON ? model.toJSON() : model);
    localStorage.setItem(LOCAL_STORAGE_MODEL_KEY, jsonStr);
    return true;
  } catch (err) {
    console.error('Failed to save model to localStorage:', err);
    return false;
  }
}

export function getModelFromStorage() {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MODEL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const model = new VoiceCloneModel(parsed);
    return model.isTrained() ? model : null;
  } catch (err) {
    console.warn('Error reading model from localStorage:', err);
    return null;
  }
}

export function clearModelStorage() {
  try {
    localStorage.removeItem(LOCAL_STORAGE_MODEL_KEY);
    return true;
  } catch (err) {
    return false;
  }
}

/**
 * Asynchronous model loader:
 * 1. Check localStorage first
 * 2. Fall back to fetching ./model.json
 * 3. Return VoiceCloneModel instance or null if untrained placeholder
 */
export async function loadActiveModel(forceFetch = false) {
  if (!forceFetch) {
    const stored = getModelFromStorage();
    if (stored && stored.isTrained()) {
      return stored;
    }
  }

  try {
    const res = await fetch('./model.json', { cache: 'no-cache' });
    if (!res.ok) {
      console.info('model.json not found on static server (HTTP ' + res.status + ')');
      return null;
    }
    const data = await res.json();
    const model = new VoiceCloneModel(data);
    if (model.isTrained()) {
      return model;
    }
    return null;
  } catch (err) {
    console.info('No external model.json available or network error:', err.message);
    return null;
  }
}
