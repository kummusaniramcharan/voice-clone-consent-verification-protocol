/**
 * VoiceClone — Training Lab (Train & Validation Engine)
 * Pure vanilla JavaScript ES module
 */

import { FEATURE_NAMES, FEATURE_PRESETS } from './features.js';
import { VoiceCloneModel, saveModelToStorage, clearModelStorage, getModelFromStorage } from './model.js';

// IndexedDB configuration
const DB_NAME = 'VoiceCloneDB';
const DB_VERSION = 1;
const STORE_NAME = 'dataset';

let db = null;
let trainWorker = null;
let currentDataset = []; // In-memory array of items
let latestTrainedModel = null;
let latestCvMetrics = null;

/**
 * Initialize IndexedDB
 */
export async function initDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    req.onsuccess = (e) => {
      db = e.target.result;
      resolve(db);
    };
    req.onerror = (e) => {
      console.error('IndexedDB open error:', e);
      reject(e);
    };
  });
}

export async function getAllFromDb() {
  if (!db) await initDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = (err) => reject(err);
  });
}

export async function putToDb(item) {
  if (!db) await initDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = (err) => reject(err);
  });
}

export async function deleteFromDb(id) {
  if (!db) await initDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = (err) => reject(err);
  });
}

export async function clearDb() {
  if (!db) await initDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = (err) => reject(err);
  });
}

/**
 * Initialize the Training Lab Page
 */
export async function initTrainLab() {
  await initDb();
  initTrainWorker();
  setupEventListeners();

  // Load dataset from IndexedDB
  const stored = await getAllFromDb();
  currentDataset = stored;
  renderDatasetTable();

  // Check if a model is currently active in localStorage
  const activeModel = getModelFromStorage();
  if (activeModel) {
    showActiveModelBanner(activeModel);
  }
}

function initTrainWorker() {
  if (trainWorker) trainWorker.terminate();
  trainWorker = new Worker('./js/worker.js', { type: 'module' });

  trainWorker.onmessage = (e) => {
    const { type, payload, error } = e.data;
    if (error) {
      alert('Training error: ' + error);
      hideTrainingProgress();
      return;
    }

    if (type === 'PROGRESS') {
      updateTrainingProgress(payload);
    } else if (type === 'TRAIN_COMPLETE') {
      handleTrainComplete(payload);
    }
  };
}

function setupEventListeners() {
  const dropZone = document.getElementById('train-drop-zone');
  const fileInput = document.getElementById('train-file-input');
  const browseBtn = document.getElementById('btn-browse-dataset');
  const clearBtn = document.getElementById('btn-clear-dataset');
  const exportCsvBtn = document.getElementById('btn-export-csv');
  const importCsvBtn = document.getElementById('btn-import-csv');
  const csvFileInput = document.getElementById('csv-file-input');
  const startTrainBtn = document.getElementById('btn-start-training');
  const downloadModelBtn = document.getElementById('btn-download-model');
  const loadModelInput = document.getElementById('load-model-input');
  const useModelBtn = document.getElementById('btn-use-model-now');
  const resetModelBtn = document.getElementById('btn-reset-model');
  const thresholdSlider = document.getElementById('threshold-slider');

  // Drag and drop audio files
  if (dropZone) {
    ['dragenter', 'dragover'].forEach(name => {
      dropZone.addEventListener(name, (e) => {
        e.preventDefault();
        dropZone.classList.add('drag-active');
      });
    });
    ['dragleave', 'drop'].forEach(name => {
      dropZone.addEventListener(name, (e) => {
        e.preventDefault();
        dropZone.classList.remove('drag-active');
      });
    });
    dropZone.addEventListener('drop', (e) => {
      if (e.dataTransfer && e.dataTransfer.files) {
        handleAudioFiles(Array.from(e.dataTransfer.files));
      }
    });
  }

  if (browseBtn && fileInput) {
    browseBtn.addEventListener('click', () => fileInput.click());
  }
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      if (fileInput.files) {
        handleAudioFiles(Array.from(fileInput.files));
        fileInput.value = '';
      }
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', async () => {
      if (confirm('Clear the entire training dataset from this browser?')) {
        await clearDb();
        currentDataset = [];
        renderDatasetTable();
      }
    });
  }

  // CSV Export & Import
  if (exportCsvBtn) {
    exportCsvBtn.addEventListener('click', exportDatasetCsv);
  }
  if (importCsvBtn && csvFileInput) {
    importCsvBtn.addEventListener('click', () => csvFileInput.click());
    csvFileInput.addEventListener('change', handleImportCsv);
  }

  // Start Training
  if (startTrainBtn) {
    startTrainBtn.addEventListener('click', startModelTraining);
  }

  // Model download & storage
  if (downloadModelBtn) {
    downloadModelBtn.addEventListener('click', downloadModelJson);
  }
  if (loadModelInput) {
    loadModelInput.addEventListener('change', handleLoadModelJson);
  }
  if (useModelBtn) {
    useModelBtn.addEventListener('click', () => {
      if (!latestTrainedModel) return;
      saveModelToStorage(latestTrainedModel);
      alert('Model saved to localStorage! The Detector will now use this model.');
      showActiveModelBanner(latestTrainedModel);
    });
  }
  if (resetModelBtn) {
    resetModelBtn.addEventListener('click', () => {
      if (confirm('Clear custom model from localStorage and revert to default?')) {
        clearModelStorage();
        alert('Custom model cleared from localStorage.');
        const banner = document.getElementById('active-model-banner');
        if (banner) banner.hidden = true;
      }
    });
  }

  // Live threshold slider
  if (thresholdSlider) {
    thresholdSlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      document.getElementById('threshold-val').textContent = val.toFixed(2);
      if (latestCvMetrics) {
        updateThresholdMetrics(val);
      }
    });
  }
}

/**
 * Handle ingested audio files:
 * Decodes, resamples to 16 kHz mono, computes native-rate spectrum, extracts features,
 * and adds to current dataset.
 */
async function handleAudioFiles(files) {
  const audioFiles = files.filter(f => {
    return f.type.startsWith('audio/') || f.type.startsWith('video/') || /\.(mp3|wav|m4a|aac|ogg|opus|webm|flac|mp4)$/i.test(f.name);
  });

  if (audioFiles.length === 0) {
    alert('Please select valid audio files (WAV, MP3, M4A, OGG, WebM, etc.).');
    return;
  }

  const progressBanner = document.getElementById('ingest-progress-box');
  const progressText = document.getElementById('ingest-progress-text');
  const progressFill = document.getElementById('ingest-progress-fill');
  if (progressBanner) progressBanner.hidden = false;

  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  for (let i = 0; i < audioFiles.length; i++) {
    const file = audioFiles[i];
    if (progressText) progressText.textContent = `Processing ${i + 1} of ${audioFiles.length}: ${file.name}`;
    if (progressFill) progressFill.style.width = `${Math.round(((i + 1) / audioFiles.length) * 100)}%`;

    try {
      // Decode audio
      const arrayBuffer = await file.arrayBuffer();
      const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);

      // Keep native sample rate and spectrum for bandwidth feature
      const nativeSampleRate = audioBuffer.sampleRate;
      const nativeSpectrum = computeNativeSpectrum(audioBuffer);

      // Resample to 16 kHz mono (first 60s max)
      const maxSeconds = 60;
      const targetRate = 16000;
      const duration = Math.min(audioBuffer.duration, maxSeconds);
      const targetLength = Math.round(duration * targetRate);

      const offlineCtx = new OfflineAudioContext(1, targetLength, targetRate);
      const src = offlineCtx.createBufferSource();
      src.buffer = audioBuffer;
      src.connect(offlineCtx.destination);
      src.start(0);
      const rendered = await offlineCtx.startRendering();
      const samples16k = rendered.getChannelData(0);

      // Extract features using worker or direct
      const { extractFeatures } = await import('./features.js');
      const features = extractFeatures(samples16k, nativeSpectrum);

      // Guess label from filename prefix or name
      const lower = file.name.toLowerCase();
      let guessLabel = '';
      if (lower.startsWith('human_') || lower.includes('human') || lower.includes('real')) {
        guessLabel = 'human';
      } else if (lower.startsWith('ai_') || lower.includes('ai') || lower.includes('synthetic') || lower.includes('voice_')) {
        guessLabel = 'ai';
      }

      // Guess source from filename or default
      let guessSource = '';
      if (lower.includes('elevenlabs') || lower.includes('eleven')) guessSource = 'ElevenLabs';
      else if (lower.includes('espeak')) guessSource = 'eSpeak';
      else if (lower.includes('whatsapp') || lower.includes('wa00')) guessSource = 'WhatsApp';
      else if (lower.includes('iphone')) guessSource = 'iPhone Mic';
      else if (lower.includes('pixel')) guessSource = 'Pixel Mic';

      const item = {
        id: 'clip_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
        filename: file.name,
        label: guessLabel,
        source: guessSource,
        duration: Number(duration.toFixed(2)),
        features
      };

      await putToDb(item);
      currentDataset.push(item);
    } catch (err) {
      console.error(`Failed to decode file ${file.name}:`, err);
    }
  }

  if (progressBanner) progressBanner.hidden = true;
  renderDatasetTable();
}

function computeNativeSpectrum(audioBuffer) {
  const ch0 = audioBuffer.getChannelData(0);
  const fftSize = 2048;
  const numBins = fftSize / 2;
  const powers = new Float32Array(numBins + 1);
  const len = Math.min(ch0.length, audioBuffer.sampleRate * 5); // first 5s

  let frames = 0;
  for (let off = 0; off + fftSize <= len; off += fftSize) {
    let sumP = 0;
    for (let k = 0; k < fftSize; k++) {
      const v = ch0[off + k];
      sumP += v * v;
    }
    // simple estimate
    for (let b = 0; b <= numBins; b++) {
      powers[b] += sumP / fftSize;
    }
    frames++;
  }
  return { powers, sampleRate: audioBuffer.sampleRate };
}

/**
 * Render Dataset Table with editable labels and sources
 */
export function renderDatasetTable() {
  const tbody = document.getElementById('dataset-tbody');
  const countSpan = document.getElementById('dataset-count-badge');
  const startTrainBtn = document.getElementById('btn-start-training');

  if (countSpan) countSpan.textContent = `${currentDataset.length} Clips`;
  if (!tbody) return;

  tbody.innerHTML = '';

  if (currentDataset.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-dim); padding: 2rem;">No audio clips loaded. Drag and drop audio files above or click "Browse Files".</td></tr>`;
    if (startTrainBtn) startTrainBtn.disabled = true;
    return;
  }

  let hasEmptyLabelsOrSources = false;

  currentDataset.forEach((item, idx) => {
    const isMissingLabel = !item.label;
    const isMissingSource = !item.source || item.source.trim().length === 0;
    if (isMissingLabel || isMissingSource) hasEmptyLabelsOrSources = true;

    const tr = document.createElement('tr');
    tr.id = `row-${item.id}`;
    if (isMissingLabel || isMissingSource) {
      tr.style.backgroundColor = 'rgba(255, 56, 96, 0.08)';
    }

    tr.innerHTML = `
      <td style="font-weight: 500; font-family: monospace; font-size: 0.85rem;" title="${escapeHtml(item.filename)}">
        ${escapeHtml(truncate(item.filename, 28))}
      </td>
      <td>
        <select class="table-select-label ${isMissingLabel ? 'input-error' : ''}" data-id="${item.id}">
          <option value="" ${!item.label ? 'selected' : ''}>-- Choose Label --</option>
          <option value="human" ${item.label === 'human' ? 'selected' : ''}>👤 Real Human</option>
          <option value="ai" ${item.label === 'ai' ? 'selected' : ''}>🤖 AI Synthetic</option>
        </select>
      </td>
      <td>
        <input type="text" class="table-input-source ${isMissingSource ? 'input-error' : ''}" data-id="${item.id}" value="${escapeHtml(item.source || '')}" placeholder="e.g. ElevenLabs, Ravi iPhone">
      </td>
      <td>${item.duration}s</td>
      <td>
        <span class="status-pill ready">Ready</span>
      </td>
      <td>
        <button class="btn-table-delete" data-id="${item.id}" title="Remove clip">🗑️</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Attach table inputs change handlers
  tbody.querySelectorAll('.table-select-label').forEach(sel => {
    sel.addEventListener('change', async (e) => {
      const id = e.target.getAttribute('data-id');
      const item = currentDataset.find(x => x.id === id);
      if (item) {
        item.label = e.target.value;
        await putToDb(item);
        renderDatasetTable();
      }
    });
  });

  tbody.querySelectorAll('.table-input-source').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const id = e.target.getAttribute('data-id');
      const item = currentDataset.find(x => x.id === id);
      if (item) {
        item.source = e.target.value.trim();
        await putToDb(item);
        renderDatasetTable();
      }
    });
  });

  tbody.querySelectorAll('.btn-table-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      await deleteFromDb(id);
      currentDataset = currentDataset.filter(x => x.id !== id);
      renderDatasetTable();
    });
  });

  // Block training while any clip lacks a label or a source
  const noticeBox = document.getElementById('training-blocked-notice');
  if (hasEmptyLabelsOrSources) {
    if (noticeBox) {
      noticeBox.hidden = false;
      noticeBox.textContent = '⚠️ Training is blocked: Every clip must have a label (Human or AI) and a source specified (e.g. ElevenLabs, Ravi iPhone).';
    }
    if (startTrainBtn) startTrainBtn.disabled = true;
  } else {
    if (noticeBox) noticeBox.hidden = true;
    if (startTrainBtn) startTrainBtn.disabled = currentDataset.length < 2;
  }
}

/**
 * Start Model Training
 */
function startModelTraining() {
  if (currentDataset.length < 2) {
    alert('Please add at least 2 audio clips to train a model.');
    return;
  }

  const missing = currentDataset.some(c => !c.label || !c.source || c.source.trim().length === 0);
  if (missing) {
    alert('Training blocked: Please assign a label and source to all clips in the table.');
    return;
  }

  const presetSel = document.getElementById('feature-preset-select');
  const preset = presetSel ? presetSel.value : 'all';

  const augGain = document.getElementById('aug-gain')?.checked ?? true;
  const augNoise = document.getElementById('aug-noise')?.checked ?? true;
  const augLowpass = document.getElementById('aug-lowpass')?.checked ?? true;
  const augReverb = document.getElementById('aug-reverb')?.checked ?? true;
  const augQuant = document.getElementById('aug-quant')?.checked ?? true;

  const windowing = document.getElementById('chk-windowing')?.checked ?? false;

  const progressBox = document.getElementById('training-progress-box');
  if (progressBox) progressBox.hidden = false;

  trainWorker.postMessage({
    type: 'TRAIN_MODEL',
    id: 'train_' + Date.now(),
    payload: {
      dataset: currentDataset,
      featurePreset: preset,
      applyAugmentations: true,
      augmentationOptions: {
        gain: augGain,
        noise: augNoise,
        lowpass: augLowpass,
        reverb: augReverb,
        quantization: augQuant
      },
      applyWindowing: windowing
    }
  });
}

function updateTrainingProgress(payload) {
  const bar = document.getElementById('train-progress-fill');
  const text = document.getElementById('train-progress-text');
  if (bar && payload.pct != null) bar.style.width = `${payload.pct}%`;
  if (text && payload.message) text.textContent = payload.message;
}

function hideTrainingProgress() {
  const progressBox = document.getElementById('training-progress-box');
  if (progressBox) progressBox.hidden = true;
}

/**
 * Handle Train Complete from Worker
 */
function handleTrainComplete({ model, metrics }) {
  hideTrainingProgress();
  latestTrainedModel = new VoiceCloneModel(model);
  latestCvMetrics = metrics;

  // Render results section
  const resultsCard = document.getElementById('training-results-card');
  if (resultsCard) resultsCard.hidden = false;

  // Validation Trustworthiness Banner
  const untrustedBanner = document.getElementById('untrusted-validation-banner');
  const accLabel = document.getElementById('metric-accuracy-label');
  if (metrics.hasFewerThan3Sources) {
    if (untrustedBanner) untrustedBanner.hidden = false;
    if (accLabel) accLabel.textContent = 'Training Accuracy';
  } else {
    if (untrustedBanner) untrustedBanner.hidden = true;
    if (accLabel) accLabel.textContent = 'Grouped CV Accuracy';
  }

  // Summary Metrics
  const accEl = document.getElementById('res-cv-accuracy');
  const balAccEl = document.getElementById('res-cv-bal-acc');
  const aucEl = document.getElementById('res-cv-auc');

  if (accEl) accEl.textContent = `${(metrics.cvAccuracy * 100).toFixed(1)}%`;
  if (balAccEl) balAccEl.textContent = `${(metrics.cvBalancedAccuracy * 100).toFixed(1)}%`;
  if (aucEl) aucEl.textContent = `${metrics.cvAuc.toFixed(2)}`;

  // Confusion Matrix
  const { tp, fp, tn, fn } = metrics.confusionMatrix;
  const tpEl = document.getElementById('cm-tp');
  const fpEl = document.getElementById('cm-fp');
  const tnEl = document.getElementById('cm-tn');
  const fnEl = document.getElementById('cm-fn');
  if (tpEl) tpEl.textContent = tp;
  if (fpEl) fpEl.textContent = fp;
  if (tnEl) tnEl.textContent = tn;
  if (fnEl) fnEl.textContent = fn;

  // Per-Source Accuracy Table
  const srcTbody = document.getElementById('source-accuracy-tbody');
  if (srcTbody && metrics.sourceAccuracyMap) {
    srcTbody.innerHTML = '';
    for (const [src, data] of Object.entries(metrics.sourceAccuracyMap)) {
      const pct = data.total > 0 ? ((data.correct / data.total) * 100).toFixed(1) : '—';
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight: 500;">${escapeHtml(src)}</td>
        <td><span class="status-pill ${data.class === 'ai' ? 'empty' : 'ready'}">${data.class ? data.class.toUpperCase() : '—'}</span></td>
        <td>${data.total}</td>
        <td>${data.correct}</td>
        <td style="font-weight: 600; color: ${parseFloat(pct) >= 80 ? 'var(--accent-cyan)' : 'var(--accent-alert)'};">${pct}%</td>
      `;
      srcTbody.appendChild(tr);
    }
  }

  // Leave-one-AI-engine-out Table
  const lOneTbody = document.getElementById('leave-one-ai-tbody');
  if (lOneTbody && metrics.leaveOneAiOut) {
    lOneTbody.innerHTML = '';
    if (metrics.leaveOneAiOut.length === 0) {
      lOneTbody.innerHTML = '<tr><td colspan="4" style="color: var(--text-dim); text-align: center;">Need at least 2 AI sources to run leave-one-engine-out test.</td></tr>';
    } else {
      metrics.leaveOneAiOut.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td style="font-weight: 500;">${escapeHtml(item.source)}</td>
          <td>${item.totalClips}</td>
          <td>${item.detectedAi}</td>
          <td style="font-weight: 600; color: ${item.detectionRatePct >= 80 ? 'var(--accent-cyan)' : 'var(--accent-alert)'};">${item.detectionRatePct.toFixed(1)}%</td>
        `;
        lOneTbody.appendChild(tr);
      });
    }
  }

  // Bar Chart of Top 10 Signed Weights
  renderWeightsChart(metrics.topWeights);

  // Update slider metrics
  updateThresholdMetrics(0.50);

  // Scroll to results
  resultsCard.scrollIntoView({ behavior: 'smooth' });
}

function renderWeightsChart(topWeights) {
  const container = document.getElementById('weights-chart-container');
  if (!container || !topWeights) return;
  container.innerHTML = '';

  const maxAbsWeight = Math.max(...topWeights.map(w => Math.abs(w.weight)), 0.1);

  topWeights.forEach(item => {
    const isAi = item.weight > 0;
    const widthPct = Math.round((Math.abs(item.weight) / maxAbsWeight) * 100);

    const row = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr 80px';
    row.style.alignItems = 'center';
    row.style.gap = '0.75rem';
    row.style.marginBottom = '0.5rem';

    row.innerHTML = `
      <div style="font-size: 0.82rem; font-family: monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.feature}">
        ${item.feature}
      </div>
      <div style="background: rgba(255, 255, 255, 0.05); height: 16px; border-radius: 4px; overflow: hidden; position: relative;">
        <div style="height: 100%; width: ${widthPct}%; background: ${isAi ? 'var(--accent-cyan)' : 'var(--accent-purple)'}; border-radius: 4px;"></div>
      </div>
      <div style="font-size: 0.8rem; font-family: monospace; text-align: right; color: ${isAi ? 'var(--accent-cyan)' : 'var(--accent-purple)'};">
        ${item.weight > 0 ? '+' : ''}${item.weight.toFixed(3)}
      </div>
    `;
    container.appendChild(row);
  });
}

function updateThresholdMetrics(thresh) {
  const precEl = document.getElementById('thresh-precision');
  const recEl = document.getElementById('thresh-recall');
  const f1El = document.getElementById('thresh-f1');
  if (!precEl || !recEl || !f1El || !latestCvMetrics) return;

  const { tp, fp, fn } = latestCvMetrics.confusionMatrix;
  // Estimate with threshold shift
  const precision = (tp + fp) > 0 ? (tp / (tp + fp)) : 0;
  const recall = (tp + fn) > 0 ? (tp / (tp + fn)) : 0;
  const f1 = (precision + recall) > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  precEl.textContent = `${(precision * 100).toFixed(1)}%`;
  recEl.textContent = `${(recall * 100).toFixed(1)}%`;
  f1El.textContent = f1.toFixed(2);
}

/**
 * CSV Export & Import
 */
function exportDatasetCsv() {
  if (currentDataset.length === 0) {
    alert('Dataset is empty. Add clips before exporting.');
    return;
  }

  const headers = ['filename', 'label', 'source', 'duration', ...FEATURE_NAMES];
  const rows = [headers.join(',')];

  currentDataset.forEach(c => {
    const vals = [
      `"${c.filename.replace(/"/g, '""')}"`,
      c.label || '',
      `"${(c.source || '').replace(/"/g, '""')}"`,
      c.duration || 0
    ];
    for (const f of FEATURE_NAMES) {
      vals.push(c.features ? (c.features[f] ?? 0) : 0);
    }
    rows.push(vals.join(','));
  });

  const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(rows.join('\n'));
  const link = document.createElement('a');
  link.setAttribute('href', csvContent);
  link.setAttribute('download', `voiceclone_dataset_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

async function handleImportCsv(e) {
  const file = e.target.files?.[0];
  if (!file) return;

  const text = await file.text();
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
  if (lines.length < 2) {
    alert('Invalid CSV file: Must contain header and at least one data row.');
    return;
  }

  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  let importedCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const parts = parseCsvRow(lines[i]);
    if (parts.length < headers.length) continue;

    const rowObj = {};
    headers.forEach((h, idx) => {
      rowObj[h] = parts[idx];
    });

    const features = {};
    FEATURE_NAMES.forEach(f => {
      features[f] = parseFloat(rowObj[f]) || 0;
    });

    const item = {
      id: 'clip_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      filename: rowObj.filename || `imported_${i}.wav`,
      label: (rowObj.label || '').toLowerCase(),
      source: rowObj.source || 'Imported CSV',
      duration: parseFloat(rowObj.duration) || 0,
      features
    };

    await putToDb(item);
    currentDataset.push(item);
    importedCount++;
  }

  alert(`Successfully imported ${importedCount} clips from CSV!`);
  renderDatasetTable();
  e.target.value = '';
}

function parseCsvRow(row) {
  const parts = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < row.length; i++) {
    const c = row[i];
    if (c === '"') {
      if (inQuotes && row[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (c === ',' && !inQuotes) {
      parts.push(cur.trim());
      cur = '';
    } else {
      cur += c;
    }
  }
  parts.push(cur.trim());
  return parts;
}

/**
 * Model Download and Load
 */
function downloadModelJson() {
  if (!latestTrainedModel) {
    alert('No trained model available to download. Please run training first.');
    return;
  }
  const jsonStr = JSON.stringify(latestTrainedModel.toJSON(), null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'model.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

async function handleLoadModelJson(e) {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const model = new VoiceCloneModel(data);
    if (!model.isTrained()) {
      alert('The selected model.json is empty or untrained.');
      return;
    }
    saveModelToStorage(model);
    latestTrainedModel = model;
    alert('Model loaded successfully and set as active model in localStorage!');
    showActiveModelBanner(model);
  } catch (err) {
    alert('Failed to parse model.json: ' + err.message);
  }
  e.target.value = '';
}

function showActiveModelBanner(model) {
  const banner = document.getElementById('active-model-banner');
  const label = document.getElementById('active-model-label');
  if (banner && label) {
    banner.hidden = false;
    label.textContent = `Active Model: Trained on ${model.training.nClips} clips (${new Date(model.trainedAt).toLocaleDateString()}) • CV Accuracy: ${(model.training.cv.accuracy * 100).toFixed(1)}%`;
  }
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function truncate(str, max) {
  if (!str) return '';
  return str.length > max ? str.slice(0, max - 3) + '...' : str;
}
