/**
 * VoiceClone — DSP & Machine Learning Web Worker
 * Performs audio feature extraction, data augmentation, and model training in background thread.
 */

import { extractFeatures, FEATURE_NAMES, FEATURE_PRESETS } from './features.js';

self.onmessage = async function(e) {
  const { type, id, payload } = e.data;

  try {
    switch (type) {
      case 'PING':
        self.postMessage({ type: 'PONG', id, time: Date.now() });
        break;

      case 'EXTRACT_FEATURES': {
        const { samples, nativeSpectrum } = payload;
        const samples16k = new Float32Array(samples);
        const features = extractFeatures(samples16k, nativeSpectrum);
        self.postMessage({
          type: 'FEATURE_RESULT',
          id,
          payload: { features }
        });
        break;
      }

      case 'EXTRACT_BATCH': {
        const { items } = payload; // Array of { id, samples, nativeSpectrum, label, source, filename, duration }
        const total = items.length;
        const results = [];

        for (let i = 0; i < total; i++) {
          const item = items[i];
          self.postMessage({
            type: 'PROGRESS',
            id,
            payload: {
              phase: 'extracting',
              current: i + 1,
              total,
              filename: item.filename,
              pct: Math.round(((i + 1) / total) * 100)
            }
          });

          const samples16k = new Float32Array(item.samples);
          const features = extractFeatures(samples16k, item.nativeSpectrum);
          results.push({
            id: item.id,
            filename: item.filename,
            label: item.label,
            source: item.source,
            duration: item.duration,
            features
          });
        }

        self.postMessage({
          type: 'EXTRACT_BATCH_COMPLETE',
          id,
          payload: { results }
        });
        break;
      }

      case 'TRAIN_MODEL': {
        const {
          dataset,
          featurePreset = 'all',
          applyAugmentations = true,
          augmentationOptions = {},
          applyWindowing = false
        } = payload;

        const trainedResult = runTrainingPipeline({
          dataset,
          featurePreset,
          applyAugmentations,
          augmentationOptions,
          applyWindowing,
          onProgress: (p) => {
            self.postMessage({
              type: 'PROGRESS',
              id,
              payload: p
            });
          }
        });

        self.postMessage({
          type: 'TRAIN_COMPLETE',
          id,
          payload: trainedResult
        });
        break;
      }

      default:
        console.warn('Unknown worker message type:', type);
    }
  } catch (err) {
    self.postMessage({
      type: 'ERROR',
      id,
      error: err.message,
      stack: err.stack
    });
  }
};

/**
 * Audio Augmentation Engine
 */
function applyAudioAugmentations(samples16k, options = {}) {
  let out = new Float32Array(samples16k);
  const n = out.length;

  // 1. Random Gain: +-6 dB
  if (options.gain !== false) {
    const gainDb = (Math.random() * 12) - 6; // -6 to +6 dB
    const factor = Math.pow(10, gainDb / 20);
    for (let i = 0; i < n; i++) {
      out[i] = Math.max(-1.0, Math.min(1.0, out[i] * factor));
    }
  }

  // 2. Pink Noise (10 to 30 dB SNR)
  if (options.noise !== false) {
    let sumSq = 0;
    for (let i = 0; i < n; i++) sumSq += out[i] * out[i];
    const sigRms = Math.sqrt(sumSq / Math.max(1, n));

    if (sigRms > 1e-4) {
      const snrDb = 10 + Math.random() * 20; // 10-30 dB
      const noiseRms = sigRms * Math.pow(10, -snrDb / 20);

      // Paul Kellet's filtered pink noise filter
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < n; i++) {
        const white = (Math.random() * 2 - 1);
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        const pink = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
        b6 = white * 0.115926;

        out[i] = Math.max(-1.0, Math.min(1.0, out[i] + pink * (noiseRms / 0.3)));
      }
    }
  }

  // 3. Random Low-Pass Filter (4 to 8 kHz)
  if (options.lowpass !== false) {
    const fc = 4000 + Math.random() * 3800; // 4000 - 7800 Hz
    const dt = 1 / 16000;
    const rc = 1 / (2 * Math.PI * fc);
    const alpha = dt / (rc + dt);
    let prev = out[0];
    for (let i = 1; i < n; i++) {
      prev = prev + alpha * (out[i] - prev);
      out[i] = prev;
    }
  }

  // 4. Synthetic Room Reverb (RT60 0.1 to 0.5 s)
  if (options.reverb !== false) {
    const rt60 = 0.1 + Math.random() * 0.35; // 0.1 - 0.45 s
    const irLen = Math.min(Math.round(rt60 * 16000), 4000);
    const decay = -6.908 / irLen; // -60 dB at irLen
    const ir = new Float32Array(irLen);
    for (let i = 0; i < irLen; i++) {
      ir[i] = (Math.random() * 2 - 1) * Math.exp(decay * i);
    }
    // Convolve with small early reflections (wet mix 25%)
    const wetMix = 0.22;
    const convolved = new Float32Array(n);
    const convLen = Math.min(irLen, 1200); // lightweight convolution
    for (let i = 0; i < n; i++) {
      let acc = 0;
      const kMax = Math.min(i, convLen - 1);
      for (let k = 0; k <= kMax; k += 2) { // step by 2 for speed
        acc += out[i - k] * ir[k];
      }
      convolved[i] = out[i] * (1 - wetMix) + acc * wetMix;
    }
    out = convolved;
  }

  // 5. 8 to 12 bit Quantization
  if (options.quantization !== false) {
    const bits = 8 + Math.floor(Math.random() * 5); // 8, 9, 10, 11, or 12
    const levels = Math.pow(2, bits - 1);
    for (let i = 0; i < n; i++) {
      out[i] = Math.round(out[i] * levels) / levels;
    }
  }

  return out;
}

/**
 * Training Pipeline
 */
function runTrainingPipeline({
  dataset,
  featurePreset,
  applyAugmentations,
  augmentationOptions,
  applyWindowing,
  onProgress
}) {
  onProgress({ phase: 'init', pct: 5, message: 'Validating dataset and sources...' });

  // 1. Select Features based on preset
  let activeFeatureNames = [...FEATURE_NAMES];
  if (featurePreset === 'voice_timing') {
    activeFeatureNames = FEATURE_PRESETS.VOICE_TIMING.features;
  } else if (featurePreset === 'recording') {
    activeFeatureNames = FEATURE_PRESETS.RECORDING.features;
  }

  // 2. Filter valid clips
  const validClips = dataset.filter(item => {
    return (
      item &&
      (item.label === 'human' || item.label === 'ai') &&
      item.source &&
      item.source.trim().length > 0 &&
      item.features
    );
  });

  if (validClips.length < 2) {
    throw new Error('Dataset must contain at least 2 valid labeled clips with sources.');
  }

  // Group by class and source
  const aiClips = validClips.filter(c => c.label === 'ai');
  const humanClips = validClips.filter(c => c.label === 'human');

  if (aiClips.length === 0 || humanClips.length === 0) {
    throw new Error('Dataset must contain at least one AI clip and at least one Human clip.');
  }

  const aiSources = Array.from(new Set(aiClips.map(c => c.source.trim())));
  const humanSources = Array.from(new Set(humanClips.map(c => c.source.trim())));

  const hasFewerThan3Sources = aiSources.length < 3 || humanSources.length < 3;

  onProgress({
    phase: 'data_prep',
    pct: 20,
    message: `Found ${validClips.length} clips (${humanClips.length} human, ${aiClips.length} AI) across ${aiSources.length + humanSources.length} sources.`
  });

  // Prepare samples list (each sample: { features, y: 0|1, source, filename })
  let samples = validClips.map(c => ({
    features: c.features,
    y: c.label === 'ai' ? 1 : 0,
    source: c.source.trim(),
    filename: c.filename
  }));

  // Optional: If raw audio is stored on items and augmentations are enabled,
  // we generate augmented training copies
  // Otherwise, features are already extracted and we use jittered feature representations for data augmentation
  if (applyAugmentations) {
    const augmentedSamples = [];
    for (const s of samples) {
      augmentedSamples.push(s); // original
      // Create an augmented variation with small acoustic variance
      const augFeats = { ...s.features };
      // Simulate gain and noise variations
      augFeats.noise_floor_dbfs = Math.min(-20, (augFeats.noise_floor_dbfs || -60) + (Math.random() * 8 - 4));
      augFeats.dyn_range_db = Math.max(5, (augFeats.dyn_range_db || 30) + (Math.random() * 6 - 3));
      augFeats.hf_4_8k_ratio = Math.max(0, Math.min(1, (augFeats.hf_4_8k_ratio || 0.1) * (0.8 + Math.random() * 0.4)));
      augFeats.amp_frame_shimmer_pct = Math.max(0, (augFeats.amp_frame_shimmer_pct || 5) * (0.9 + Math.random() * 0.2));

      augmentedSamples.push({
        features: augFeats,
        y: s.y,
        source: s.source,
        filename: `${s.filename}_aug`
      });
    }
    samples = augmentedSamples;
  }

  // -------------------------------------------------------------
  // Grouped K-Fold Cross Validation by Source
  // -------------------------------------------------------------
  onProgress({ phase: 'validation', pct: 40, message: 'Running grouped cross-validation...' });

  const allSources = Array.from(new Set(samples.map(s => s.source)));
  let cvAccuracy = 0;
  let cvBalancedAccuracy = 0;
  let cvAuc = 0;
  let tp = 0, fp = 0, tn = 0, fn = 0;
  const sourceAccuracyMap = {};

  for (const src of allSources) {
    sourceAccuracyMap[src] = { total: 0, correct: 0, class: null };
  }

  const cvPredictions = [];

  if (allSources.length >= 2) {
    // K-Fold over unique sources
    const kFolds = Math.min(5, allSources.length);
    const sourceFolds = Array.from({ length: kFolds }, () => []);
    allSources.forEach((src, idx) => {
      sourceFolds[idx % kFolds].push(src);
    });

    for (let fold = 0; fold < kFolds; fold++) {
      const testSources = new Set(sourceFolds[fold]);
      const trainSet = samples.filter(s => !testSources.has(s.source));
      const testSet = samples.filter(s => testSources.has(s.source));

      if (trainSet.length === 0 || testSet.length === 0) continue;

      // Fit normalization on trainSet only
      const { mean: trainMean, std: trainStd } = fitStandardizer(trainSet, activeFeatureNames);

      // Train fold model
      const { weights: foldW, bias: foldB } = trainLogisticRegression({
        trainSet,
        featureNames: activeFeatureNames,
        mean: trainMean,
        std: trainStd,
        lr: 0.1,
        lambda: 0.01,
        epochs: 500
      });

      // Evaluate on testSet
      for (const item of testSet) {
        const prob = predictLogistic(item.features, activeFeatureNames, foldW, foldB, trainMean, trainStd);
        const predY = prob >= 0.5 ? 1 : 0;
        const isCorrect = predY === item.y;

        cvPredictions.push({
          prob,
          predY,
          actualY: item.y,
          source: item.source,
          filename: item.filename
        });

        if (item.y === 1) {
          sourceAccuracyMap[item.source].class = 'ai';
          if (predY === 1) tp++; else fn++;
        } else {
          sourceAccuracyMap[item.source].class = 'human';
          if (predY === 0) tn++; else fp++;
        }

        sourceAccuracyMap[item.source].total++;
        if (isCorrect) sourceAccuracyMap[item.source].correct++;
      }
    }

    const totalEvals = tp + fp + tn + fn;
    if (totalEvals > 0) {
      cvAccuracy = (tp + tn) / totalEvals;
      const sensitivity = (tp + fn) > 0 ? tp / (tp + fn) : 0;
      const specificity = (tn + fp) > 0 ? tn / (tn + fp) : 0;
      cvBalancedAccuracy = (sensitivity + specificity) / 2;
      cvAuc = computeAuc(cvPredictions);
    }
  } else {
    // Only 1 source in dataset (fallback: evaluate training fit)
    const { mean: tMean, std: tStd } = fitStandardizer(samples, activeFeatureNames);
    const { weights: tW, bias: tB } = trainLogisticRegression({
      trainSet: samples,
      featureNames: activeFeatureNames,
      mean: tMean,
      std: tStd,
      lr: 0.1,
      lambda: 0.01,
      epochs: 500
    });
    for (const s of samples) {
      const prob = predictLogistic(s.features, activeFeatureNames, tW, tB, tMean, tStd);
      const predY = prob >= 0.5 ? 1 : 0;
      if (s.y === 1) {
        if (predY === 1) tp++; else fn++;
      } else {
        if (predY === 0) tn++; else fp++;
      }
      cvPredictions.push({ prob, predY, actualY: s.y, source: s.source });
    }
    cvAccuracy = (tp + tn) / Math.max(1, samples.length);
    cvBalancedAccuracy = cvAccuracy;
    cvAuc = computeAuc(cvPredictions);
  }

  // Leave-one-AI-engine-out table
  const leaveOneAiOut = [];
  for (const aiSrc of aiSources) {
    const trainSet = samples.filter(s => s.source !== aiSrc);
    const testSet = samples.filter(s => s.source === aiSrc);
    if (trainSet.length > 0 && testSet.length > 0) {
      const { mean: mTr, std: sTr } = fitStandardizer(trainSet, activeFeatureNames);
      const { weights: wTr, bias: bTr } = trainLogisticRegression({
        trainSet,
        featureNames: activeFeatureNames,
        mean: mTr,
        std: sTr,
        lr: 0.1,
        lambda: 0.01,
        epochs: 500
      });

      let detectedAi = 0;
      for (const t of testSet) {
        const p = predictLogistic(t.features, activeFeatureNames, wTr, bTr, mTr, sTr);
        if (p >= 0.5) detectedAi++;
      }
      leaveOneAiOut.push({
        source: aiSrc,
        totalClips: testSet.length,
        detectedAi,
        detectionRatePct: (detectedAi / testSet.length) * 100
      });
    }
  }

  // -------------------------------------------------------------
  // Final Model Training on Entire Dataset
  // -------------------------------------------------------------
  onProgress({ phase: 'final_fit', pct: 80, message: 'Fitting final model on complete dataset...' });

  const { mean: finalMean, std: finalStd } = fitStandardizer(samples, activeFeatureNames);
  const { weights: finalWeights, bias: finalBias } = trainLogisticRegression({
    trainSet: samples,
    featureNames: activeFeatureNames,
    mean: finalMean,
    std: finalStd,
    lr: 0.1,
    lambda: 0.01,
    epochs: 500
  });

  // Calculate reference averages for human vs AI (for plain English explanations)
  const humanAverages = {};
  const aiAverages = {};
  for (const name of activeFeatureNames) {
    const hVals = validClips.filter(c => c.label === 'human').map(c => c.features[name] ?? 0);
    const aiVals = validClips.filter(c => c.label === 'ai').map(c => c.features[name] ?? 0);
    humanAverages[name] = hVals.length > 0 ? hVals.reduce((a, b) => a + b, 0) / hVals.length : finalMean[name];
    aiAverages[name] = aiVals.length > 0 ? aiVals.reduce((a, b) => a + b, 0) / aiVals.length : finalMean[name];
  }

  // Build model.json compliant object
  const modelOutput = {
    version: '1.0.0',
    trainedAt: new Date().toISOString(),
    featureNames: activeFeatureNames,
    mean: finalMean,
    std: finalStd,
    weights: finalWeights,
    bias: finalBias,
    threshold: 0.50,
    uncertainBand: [0.35, 0.65],
    ood: {
      mean: finalMean,
      std: finalStd
    },
    training: {
      nClips: validClips.length,
      sources: {
        ai: aiSources,
        human: humanSources
      },
      cv: {
        accuracy: Number(cvAccuracy.toFixed(4)),
        balancedAccuracy: Number(cvBalancedAccuracy.toFixed(4)),
        auc: Number(cvAuc.toFixed(4)),
        isTrustworthy: !hasFewerThan3Sources,
        hasFewerThan3Sources
      },
      confusionMatrix: { tp, fp, tn, fn },
      featureAverages: {
        human: humanAverages,
        ai: aiAverages
      }
    }
  };

  // Top 10 signed weights
  const sortedWeights = activeFeatureNames
    .map(name => ({ feature: name, weight: finalWeights[name] || 0 }))
    .sort((a, b) => Math.abs(b.weight) - Math.abs(a.weight))
    .slice(0, 10);

  onProgress({ phase: 'done', pct: 100, message: 'Training complete!' });

  return {
    model: modelOutput,
    metrics: {
      cvAccuracy,
      cvBalancedAccuracy,
      cvAuc,
      confusionMatrix: { tp, fp, tn, fn },
      hasFewerThan3Sources,
      sourceAccuracyMap,
      leaveOneAiOut,
      topWeights: sortedWeights
    }
  };
}

/**
 * Normalization / Standardization Helpers
 */
function fitStandardizer(items, featureNames) {
  const mean = {};
  const std = {};
  const n = items.length;

  for (const name of featureNames) {
    let s = 0;
    for (let i = 0; i < n; i++) {
      s += (items[i].features[name] ?? 0);
    }
    const m = s / Math.max(1, n);
    mean[name] = m;

    let v = 0;
    for (let i = 0; i < n; i++) {
      const d = (items[i].features[name] ?? 0) - m;
      v += d * d;
    }
    const dev = Math.sqrt(v / Math.max(1, n - 1));
    std[name] = dev > 1e-6 ? dev : 1.0;
  }

  return { mean, std };
}

/**
 * L2-Regularized Logistic Regression by Gradient Descent
 * lr = 0.1, lambda = 0.01, 500 epochs, balanced class weights
 */
function trainLogisticRegression({
  trainSet,
  featureNames,
  mean,
  std,
  lr = 0.1,
  lambda = 0.01,
  epochs = 500
}) {
  const n = trainSet.length;
  const numFeatures = featureNames.length;

  // Balanced class weights
  let count0 = 0, count1 = 0;
  for (let i = 0; i < n; i++) {
    if (trainSet[i].y === 1) count1++; else count0++;
  }
  const w0 = count0 > 0 ? n / (2 * count0) : 1.0;
  const w1 = count1 > 0 ? n / (2 * count1) : 1.0;

  // Standardize inputs into compact matrix
  const X = new Float32Array(n * numFeatures);
  const Y = new Float32Array(n);
  const sampleWeights = new Float32Array(n);

  for (let i = 0; i < n; i++) {
    const item = trainSet[i];
    Y[i] = item.y;
    sampleWeights[i] = item.y === 1 ? w1 : w0;
    for (let j = 0; j < numFeatures; j++) {
      const fName = featureNames[j];
      const val = item.features[fName] ?? 0;
      X[i * numFeatures + j] = (val - mean[fName]) / std[fName];
    }
  }

  // Parameters
  const weightsArr = new Float32Array(numFeatures);
  let bias = 0.0;

  // Gradient Descent iterations
  for (let ep = 0; ep < epochs; ep++) {
    const gradW = new Float32Array(numFeatures);
    let gradB = 0;

    for (let i = 0; i < n; i++) {
      let logit = bias;
      const rowOffset = i * numFeatures;
      for (let j = 0; j < numFeatures; j++) {
        logit += weightsArr[j] * X[rowOffset + j];
      }

      // Sigmoid
      const p = 1 / (1 + Math.exp(-Math.max(-50, Math.min(50, logit))));
      const err = sampleWeights[i] * (p - Y[i]);

      gradB += err;
      for (let j = 0; j < numFeatures; j++) {
        gradW[j] += err * X[rowOffset + j];
      }
    }

    // Update with L2 regularization
    bias -= lr * (gradB / n);
    for (let j = 0; j < numFeatures; j++) {
      const reg = 2 * lambda * weightsArr[j];
      weightsArr[j] -= lr * ((gradW[j] / n) + reg);
    }
  }

  const weights = {};
  for (let j = 0; j < numFeatures; j++) {
    weights[featureNames[j]] = Number(weightsArr[j].toFixed(6));
  }

  return { weights, bias: Number(bias.toFixed(6)) };
}

function predictLogistic(features, featureNames, weights, bias, mean, std) {
  let logit = bias;
  for (const name of featureNames) {
    const val = features[name] ?? 0;
    const m = mean[name] ?? 0;
    const s = std[name] ?? 1.0;
    const z = (val - m) / (s > 1e-6 ? s : 1.0);
    logit += (weights[name] ?? 0) * z;
  }
  return 1 / (1 + Math.exp(-Math.max(-50, Math.min(50, logit))));
}

/**
 * Mann-Whitney U statistic for ROC AUC
 */
function computeAuc(predictions) {
  const pos = predictions.filter(p => p.actualY === 1).map(p => p.prob);
  const neg = predictions.filter(p => p.actualY === 0).map(p => p.prob);

  if (pos.length === 0 || neg.length === 0) return 1.0;

  let u = 0;
  for (let i = 0; i < pos.length; i++) {
    for (let j = 0; j < neg.length; j++) {
      if (pos[i] > neg[j]) {
        u += 1.0;
      } else if (pos[i] === neg[j]) {
        u += 0.5;
      }
    }
  }

  return u / (pos.length * neg.length);
}
