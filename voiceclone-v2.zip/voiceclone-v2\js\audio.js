/**
 * js/audio.js
 * Audio loading, decoding, resampling, waveform drawing, mic recording.
 * All audio stays on the device.
 */

'use strict';

export const MAX_FILE_BYTES = 20 * 1024 * 1024; // 20 MB
export const MAX_DURATION_S  = 60;
export const MIN_DURATION_S  = 3;

// ─── Quality gate ─────────────────────────────────────────────────────────────
export function qualityGate(samples) {
  const N = samples.length;
  if (N === 0) return { ok: false, reason: 'The file decoded to no audio samples.' };

  // Duration check
  const dur = N / 16000;
  if (dur < MIN_DURATION_S) return { ok: false, reason: `Audio is too short (${dur.toFixed(1)} s). Need at least ${MIN_DURATION_S} s.` };

  // Clipping check
  let clipped = 0;
  for (let i = 0; i < N; i++) if (Math.abs(samples[i]) >= 0.99) clipped++;
  if (clipped / N > 0.05) {
    return { ok: 'warn', reason: `Warning: ${(clipped/N*100).toFixed(1)}% of samples are clipped. Results may be unreliable.` };
  }

  // RMS / silence check
  let sumSq = 0;
  let silenceCount = 0;
  const FRAME = 160;
  let frames = 0;
  for (let i = 0; i + FRAME <= N; i += FRAME) {
    let fSq = 0;
    for (let j = i; j < i + FRAME; j++) fSq += samples[j] * samples[j];
    const fRMS = Math.sqrt(fSq / FRAME);
    sumSq += fSq;
    if (fRMS < 1e-4) silenceCount++;
    frames++;
  }
  const overallRMS = Math.sqrt(sumSq / N);
  const rmsDBFS = 20 * Math.log10(Math.max(overallRMS, 1e-12));
  if (rmsDBFS < -45) {
    return { ok: 'warn', reason: `Warning: Recording is very quiet (${rmsDBFS.toFixed(1)} dBFS). Results may be unreliable.` };
  }
  if (frames > 0 && silenceCount / frames > 0.70) {
    return { ok: 'warn', reason: `Warning: Over 70% of the recording is silence. Results may be unreliable.` };
  }

  return { ok: true };
}

// ─── Decode file → stereo/mono Float32 at native sample rate ─────────────────
export async function decodeAudioFile(file) {
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(`File too large (${(file.size/1024/1024).toFixed(1)} MB). Maximum is 20 MB.`);
  }

  const arrayBuf = await file.arrayBuffer();
  if (arrayBuf.byteLength === 0) throw new Error('File is empty.');

  let audioBuf;
  try {
    const ctx = new AudioContext();
    audioBuf = await ctx.decodeAudioData(arrayBuf);
    await ctx.close();
  } catch (e) {
    throw new Error(
      'Could not decode audio. The file format may be unsupported by your browser. ' +
      'Try converting to WAV or MP3 using Audacity or an online converter.'
    );
  }

  if (audioBuf.duration < 0.5) throw new Error('The decoded audio is less than 0.5 seconds. Is the file corrupted?');

  return audioBuf;
}

// ─── Mix to mono, resample to 16 kHz, trim to MAX_DURATION_S ──────────────────
export async function resampleToMono16k(audioBuf) {
  const nativeSR   = audioBuf.sampleRate;
  const nativeChan = audioBuf.numberOfChannels;
  const srcLen     = audioBuf.length;

  // Mix to mono (native rate)
  let nativeMono;
  if (nativeChan === 1) {
    nativeMono = audioBuf.getChannelData(0).slice();
  } else {
    nativeMono = new Float32Array(srcLen);
    for (let c = 0; c < nativeChan; c++) {
      const ch = audioBuf.getChannelData(c);
      for (let i = 0; i < srcLen; i++) nativeMono[i] += ch[i] / nativeChan;
    }
  }

  // Keep native-rate buffer (for bandwidth feature), trimmed to 60 s
  const maxNativeSamples = Math.min(nativeMono.length, MAX_DURATION_S * nativeSR);
  const nativeSlice = nativeMono.subarray(0, maxNativeSamples);

  // Resample to 16 kHz using OfflineAudioContext
  const outLen = Math.floor(maxNativeSamples / nativeSR * 16000);
  const offCtx = new OfflineAudioContext(1, outLen, 16000);

  // Create AudioBuffer at native rate
  const srcBuf = offCtx.createBuffer(1, nativeSlice.length, nativeSR);
  srcBuf.copyToChannel(nativeSlice, 0);

  const src = offCtx.createBufferSource();
  src.buffer = srcBuf;
  src.connect(offCtx.destination);
  src.start(0);

  const rendered = await offCtx.startRendering();
  const mono16k  = rendered.getChannelData(0).slice();

  return { mono16k, nativeMono: nativeSlice, nativeSR };
}

// ─── Draw waveform onto a canvas ───────────────────────────────────────────────
export function drawWaveform(canvas, samples) {
  const W = canvas.width  = canvas.offsetWidth  || canvas.clientWidth  || 600;
  const H = canvas.height = canvas.offsetHeight || canvas.clientHeight || 80;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, W, H);

  const step = Math.ceil(samples.length / W);
  const mid  = H / 2;

  ctx.strokeStyle = '#4cc9ff';
  ctx.lineWidth   = 1;
  ctx.beginPath();

  for (let x = 0; x < W; x++) {
    let min = 1, max = -1;
    const start = x * step;
    for (let j = start; j < start + step && j < samples.length; j++) {
      if (samples[j] < min) min = samples[j];
      if (samples[j] > max) max = samples[j];
    }
    const y1 = mid + min * mid * 0.95;
    const y2 = mid + max * mid * 0.95;
    ctx.moveTo(x, y1);
    ctx.lineTo(x, y2);
  }
  ctx.stroke();
}

// ─── Microphone recording ──────────────────────────────────────────────────────
export class MicRecorder {
  constructor({ onLevel, onTimer, onStopped }) {
    this._onLevel   = onLevel;
    this._onTimer   = onTimer;
    this._onStopped = onStopped;
    this._stream    = null;
    this._mediaRec  = null;
    this._chunks    = [];
    this._startTime = 0;
    this._timerID   = null;
    this._audioCtx  = null;
    this._analyser  = null;
    this._levelRAF  = null;
    this._mimeType  = '';
  }

  async start() {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl:  false,
          channelCount: 1,
        }
      });
    } catch (e) {
      const msg = e.name === 'NotAllowedError'
        ? 'Microphone permission denied. Please allow microphone access in your browser settings and try again.'
        : `Could not access microphone: ${e.message}`;
      throw new Error(msg);
    }

    this._stream = stream;
    this._chunks = [];

    // Choose MIME type
    const mimes = ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus','audio/ogg','audio/mp4'];
    this._mimeType = mimes.find(m => MediaRecorder.isTypeSupported(m)) || '';

    this._mediaRec = new MediaRecorder(stream, { mimeType: this._mimeType || undefined });
    this._mediaRec.ondataavailable = e => { if (e.data.size > 0) this._chunks.push(e.data); };

    // Live level meter via Web Audio
    this._audioCtx = new AudioContext();
    const src = this._audioCtx.createMediaStreamSource(stream);
    this._analyser = this._audioCtx.createAnalyser();
    this._analyser.fftSize = 256;
    src.connect(this._analyser);
    this._levelLoop();

    this._mediaRec.start(100); // collect chunks every 100ms
    this._startTime = Date.now();
    this._timerID = setInterval(() => {
      const elapsed = (Date.now() - this._startTime) / 1000;
      this._onTimer(elapsed);
      if (elapsed >= 60) this.stop();
    }, 500);
  }

  _levelLoop() {
    const data = new Uint8Array(this._analyser.frequencyBinCount);
    const tick = () => {
      this._analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const s = (data[i] - 128) / 128;
        sum += s * s;
      }
      const rms = Math.sqrt(sum / data.length);
      this._onLevel(Math.min(1, rms * 4));
      this._levelRAF = requestAnimationFrame(tick);
    };
    this._levelRAF = requestAnimationFrame(tick);
  }

  stop() {
    if (!this._mediaRec) return;
    clearInterval(this._timerID);
    cancelAnimationFrame(this._levelRAF);
    if (this._audioCtx) this._audioCtx.close();

    this._mediaRec.onstop = async () => {
      const blob = new Blob(this._chunks, { type: this._mimeType || 'audio/webm' });
      this._stream.getTracks().forEach(t => t.stop());
      this._onStopped(blob);
    };
    this._mediaRec.stop();
    this._mediaRec = null;
  }

  isRecording() { return this._mediaRec !== null; }
}
