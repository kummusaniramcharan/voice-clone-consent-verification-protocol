/**
 * js/model.js
 * Logistic-regression model: load, save, predict, explain.
 * No DOM access. Works in both main thread and worker.
 */

'use strict';

export const FEATURE_NAMES = [
  'noise_floor_dbfs','dyn_range_db','digital_silence_pct','bandwidth_hz',
  'spec_flatness','spec_centroid_hz','rolloff95_hz','hf_4_8k_ratio','spec_flux_cv',
  'mfcc_temporal_std','mfcc_delta_mean',
  'f0_mean_hz','f0_std_semitones','f0_range_semitones','voiced_pct','f0_flat_step_pct',
  'hnr_mean_db','hnr_std_db','amp_frame_shimmer_pct',
  'pause_per_10s','pause_mean_s','pause_cv',
  'mod_peak_hz','mod_peak_ratio',
];

export const FEATURE_PRESETS = {
  all:          null, // use all
  voice_timing: ['f0_mean_hz','f0_std_semitones','f0_range_semitones','voiced_pct',
                 'f0_flat_step_pct','hnr_mean_db','hnr_std_db','amp_frame_shimmer_pct',
                 'pause_per_10s','pause_mean_s','pause_cv','mod_peak_hz','mod_peak_ratio'],
  recording:    ['noise_floor_dbfs','dyn_range_db','digital_silence_pct','bandwidth_hz'],
};

// ─── Sigmoid ──────────────────────────────────────────────────────────────────
function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }

// ─── Model class ──────────────────────────────────────────────────────────────
export class VoiceModel {
  constructor(json) {
    this._m = json;
  }

  /** Returns { prob, verdict, scoreLabel, featureContributions, ood } */
  predict(featObj) {
    const m = this._m;
    if (!m || !m.weights) return null;

    const names = m.featureNames || FEATURE_NAMES;
    const z = names.map((name, i) => {
      const raw = featObj[name] ?? 0;
      return (raw - (m.mean[i] ?? 0)) / (m.std[i] ?? 1);
    });

    const dot = z.reduce((s, zi, i) => s + zi * (m.weights[i] ?? 0), m.bias ?? 0);
    const prob = sigmoid(dot);

    let verdict, verdictClass;
    const hi = m.threshold ?? 0.65, lo = 1 - hi;
    if (prob >= hi)      { verdict = 'Likely AI-generated';  verdictClass = 'ai'; }
    else if (prob <= lo) { verdict = 'Likely human voice';   verdictClass = 'human'; }
    else                 { verdict = 'Inconclusive';         verdictClass = 'inc'; }

    // Feature contributions (weight × z-score) for top-3 explanation
    const contribs = names.map((name, i) => ({
      name,
      contribution: (m.weights[i] ?? 0) * z[i],
      rawValue: featObj[name] ?? 0,
      zScore: z[i],
    })).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));

    // Out-of-distribution check: 3+ features with |z| > 4
    const oodCount = z.filter(zi => Math.abs(zi) > 4).length;
    const ood = oodCount >= 3;

    return { prob, verdict, verdictClass, scoreLabel: `AI-likelihood ${(prob * 100).toFixed(0)}%`, contribs, ood, oodCount };
  }

  get meta() { return this._m; }

  toJSON() { return this._m; }

  /** Create an empty placeholder model.json */
  static placeholder() {
    return {
      version: 1,
      trainedAt: null,
      featureNames: FEATURE_NAMES,
      mean:    new Array(FEATURE_NAMES.length).fill(0),
      std:     new Array(FEATURE_NAMES.length).fill(1),
      weights: new Array(FEATURE_NAMES.length).fill(0),
      bias:    0,
      threshold: 0.65,
      uncertainBand: [0.35, 0.65],
      ood: { mean: null, std: null },
      training: { nClips: 0, sources: { ai: [], human: [] }, cv: null },
    };
  }
}

// ─── Persistence ──────────────────────────────────────────────────────────────
const LS_KEY = 'voiceclone_model_v2';

export function saveModelToLocalStorage(modelJSON) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(modelJSON));
  } catch (e) {
    console.warn('Could not save model to localStorage:', e);
  }
}

export function loadModelFromLocalStorage() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

export function clearModelFromLocalStorage() {
  localStorage.removeItem(LS_KEY);
}

// ─── L2-regularised logistic regression trainer ───────────────────────────────
/**
 * @param {Array<{features: number[], label: number}>} data   label: 1=AI, 0=human
 * @param {Object} opts
 * @returns {{ weights, bias, mean, std }}
 */
export function trainLogistic(data, opts = {}) {
  const { lr = 0.1, lambda = 0.01, epochs = 500, featureNames = FEATURE_NAMES } = opts;
  const nFeatures = featureNames.length;
  const n = data.length;

  // z-score normalisation
  const mean = new Float64Array(nFeatures);
  const std  = new Float64Array(nFeatures);

  for (let f = 0; f < nFeatures; f++) {
    let s = 0;
    for (const d of data) s += d.features[f];
    mean[f] = s / n;
    let sq = 0;
    for (const d of data) sq += (d.features[f] - mean[f]) ** 2;
    std[f] = Math.sqrt(sq / n) || 1;
  }

  const Xn = data.map(d => d.features.map((v, f) => (v - mean[f]) / std[f]));

  // Class weights (balanced)
  const nAI    = data.filter(d => d.label === 1).length;
  const nHuman = n - nAI;
  const wAI    = n / (2 * nAI    + 1e-9);
  const wHuman = n / (2 * nHuman + 1e-9);
  const weights_cls = data.map(d => d.label === 1 ? wAI : wHuman);

  // Initialise
  let w = new Float64Array(nFeatures);
  let b = 0;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const dw = new Float64Array(nFeatures);
    let   db = 0;

    for (let i = 0; i < n; i++) {
      const pred = sigmoid(Xn[i].reduce((s, v, f) => s + v * w[f], b));
      const err  = (pred - data[i].label) * weights_cls[i];
      for (let f = 0; f < nFeatures; f++) dw[f] += err * Xn[i][f];
      db += err;
    }

    for (let f = 0; f < nFeatures; f++) {
      w[f] -= lr * (dw[f] / n + lambda * w[f]);
    }
    b -= lr * db / n;
  }

  return {
    weights: Array.from(w),
    bias: b,
    mean: Array.from(mean),
    std:  Array.from(std),
  };
}

// ─── Augmentation (in-browser, for training) ─────────────────────────────────
/**
 * Apply random augmentation to a Float32Array of audio at 16 kHz.
 * Returns a new Float32Array.
 */
export function augmentSamples(samples, opts = {}) {
  const {
    gainAugment    = true,
    noiseAugment   = true,
    lpfAugment     = true,
    reverbAugment  = true,
    bitcrushAugment = true,
  } = opts;

  let out = new Float32Array(samples);

  // Random gain ±6 dB
  if (gainAugment) {
    const gainDB = (Math.random() * 12) - 6;
    const gainLin = Math.pow(10, gainDB / 20);
    for (let i = 0; i < out.length; i++) out[i] *= gainLin;
  }

  // Pink noise at 10-30 dB SNR
  if (noiseAugment) {
    const snrDB  = 10 + Math.random() * 20;
    const sigPow = out.reduce((s, v) => s + v * v, 0) / out.length;
    const noisePow = sigPow / Math.pow(10, snrDB / 10);
    const noiseAmp = Math.sqrt(noisePow);
    // Approximate pink noise with 1/f^0.5 shaping (simple 1-pole IIR)
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < out.length; i++) {
      const white = (Math.random() * 2 - 1);
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      const pink = (b0 + b1 + b2 + white * 0.5362) / 3.5;
      out[i] += pink * noiseAmp;
    }
  }

  // Random low-pass at 4-8 kHz (simple 1-pole IIR)
  if (lpfAugment) {
    const fc = 4000 + Math.random() * 4000;
    const SR = 16000;
    const rc = 1 / (2 * Math.PI * fc);
    const dt = 1 / SR;
    const alpha = dt / (rc + dt);
    let prev = 0;
    for (let i = 0; i < out.length; i++) {
      out[i] = prev + alpha * (out[i] - prev);
      prev = out[i];
    }
  }

  // Synthetic room reverb (decaying-noise IR)
  if (reverbAugment && out.length > 100) {
    const rt60  = 0.1 + Math.random() * 0.4; // 0.1-0.5 s
    const SR    = 16000;
    const irLen = Math.ceil(rt60 * SR);
    const ir    = new Float32Array(irLen);
    const decay = Math.pow(0.001, 1 / irLen); // -60 dB at irLen
    let env = 1;
    for (let i = 0; i < irLen; i++) {
      ir[i] = (Math.random() * 2 - 1) * env;
      env *= decay;
    }
    // Convolve (naive – only first 4000 samples to keep it fast)
    const convLen = Math.min(out.length, 4000);
    const convOut = new Float32Array(convLen + irLen - 1);
    for (let i = 0; i < convLen; i++) {
      for (let j = 0; j < irLen; j++) {
        convOut[i + j] += out[i] * ir[j] * 0.25;
      }
    }
    for (let i = 0; i < out.length; i++) out[i] += convOut[i] ?? 0;
  }

  // 8-12 bit quantisation
  if (bitcrushAugment) {
    const bits = 8 + Math.floor(Math.random() * 5); // 8-12 bits
    const levels = Math.pow(2, bits);
    for (let i = 0; i < out.length; i++) {
      out[i] = Math.round(out[i] * levels / 2) / (levels / 2);
    }
  }

  // Clip to [-1, 1]
  for (let i = 0; i < out.length; i++) {
    out[i] = Math.max(-1, Math.min(1, out[i]));
  }

  return out;
}

// ─── Grouped k-fold cross-validation ─────────────────────────────────────────
/**
 * Groups: array of source strings (parallel to data).
 * Returns { accuracy, balancedAccuracy, auc, confusionMatrix, perSource }
 */
export function groupedKFold(data, groups, featureNames, k = 5) {
  // Get unique sources per class
  const aiSources    = [...new Set(groups.filter((_, i) => data[i].label === 1))];
  const humanSources = [...new Set(groups.filter((_, i) => data[i].label === 0))];

  const minSources = Math.min(aiSources.length, humanSources.length);
  if (minSources < 2) {
    // Not enough sources for real CV
    return { notEnoughSources: true, aiSources, humanSources };
  }

  // Build folds: leave one source out per fold (simplified)
  const allSources = [...new Set(groups)];
  const foldSize   = Math.max(1, Math.floor(allSources.length / Math.min(k, allSources.length)));
  const folds      = [];
  for (let i = 0; i < allSources.length; i += foldSize) {
    folds.push(allSources.slice(i, i + foldSize));
  }

  let tp = 0, fp = 0, tn = 0, fn = 0;
  const perSource = {};
  const allProbs  = [];
  const allLabels = [];

  for (const testSources of folds) {
    const testSet  = data.filter((_, i) => testSources.includes(groups[i]));
    const trainSet = data.filter((_, i) => !testSources.includes(groups[i]));
    if (trainSet.length < 4 || testSet.length === 0) continue;

    const { weights, bias, mean, std } = trainLogistic(trainSet, { featureNames });

    for (const d of testSet) {
      const z = featureNames.map((n, fi) => (d.features[fi] - mean[fi]) / std[fi]);
      const dot = z.reduce((s, v, fi) => s + v * weights[fi], bias);
      const prob = sigmoid(dot);
      allProbs.push(prob);
      allLabels.push(d.label);

      const pred = prob >= 0.5 ? 1 : 0;
      if (pred === 1 && d.label === 1) tp++;
      if (pred === 1 && d.label === 0) fp++;
      if (pred === 0 && d.label === 0) tn++;
      if (pred === 0 && d.label === 1) fn++;

      // Per-source stats
      const src = groups[data.indexOf(d)];
      if (!perSource[src]) perSource[src] = { label: d.label, correct: 0, total: 0 };
      if (pred === d.label) perSource[src].correct++;
      perSource[src].total++;
    }
  }

  const accuracy = (tp + tn) / (tp + tn + fp + fn + 1e-9);
  const sensitivity = tp / (tp + fn + 1e-9);
  const specificity  = tn / (tn + fp + 1e-9);
  const balancedAccuracy = (sensitivity + specificity) / 2;

  // AUC via trapezoidal rule
  const auc = computeAUC(allProbs, allLabels);

  return {
    accuracy,
    balancedAccuracy,
    auc,
    confusionMatrix: { tp, fp, tn, fn },
    perSource,
    notEnoughSources: false,
  };
}

function computeAUC(probs, labels) {
  const pairs = probs.map((p, i) => ({ p, l: labels[i] })).sort((a, b) => b.p - a.p);
  let tp = 0, fp = 0;
  let auc = 0;
  let prevFP = 0;
  const posN = labels.filter(l => l === 1).length;
  const negN = labels.length - posN;
  if (posN === 0 || negN === 0) return 0.5;

  for (const { p, l } of pairs) {
    if (l === 1) tp++;
    else {
      fp++;
      auc += tp * (1 / negN);
    }
  }
  return Math.min(1, auc / posN);
}
