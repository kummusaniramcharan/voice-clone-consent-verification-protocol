/**
 * js/train.js
 * Training Lab page controller.
 * Dataset management, augmentation, feature extraction via worker,
 * logistic regression training, k-fold CV, model save/load.
 */

'use strict';

import { decodeAudioFile, resampleToMono16k } from './audio.js';
import { FEATURE_NAMES, FEATURE_PRESETS, VoiceModel,
         saveModelToLocalStorage, loadModelFromLocalStorage,
         trainLogistic, groupedKFold } from './model.js';
import { dbSaveClip, dbGetAllClips, dbUpdateClip, dbDeleteClip, dbClear } from './db.js';

// ── State ──────────────────────────────────────────────────────────────────────
let clips      = []; // { id, name, label, source, durationS, status, feats, samples16k }
let trainModel = null;
let worker     = null;
const workerCallbacks = {};

// ── Init ───────────────────────────────────────────────────────────────────────
export async function initTrain() {
  setupNav();
  worker = new Worker('./js/worker.js', { type: 'module' });
  worker.onmessage = handleWorkerMsg;

  // Load existing dataset from IndexedDB
  const stored = await dbGetAllClips();
  clips = stored;
  renderDatasetTable();

  setupDropZone();
  setupButtons();
  setupThresholdSlider();

  // Load existing model
  const json = loadModelFromLocalStorage();
  if (json && json.weights && (json.training?.nClips ?? 0) > 0) {
    trainModel = new VoiceModel(json);
    renderModelInfo(json);
  }
}

function setupNav() {
  const btn = document.getElementById('mobile-menu-btn');
  const nav = document.getElementById('nav-links');
  if (btn && nav) {
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
    });
  }
}

// ── Drop zone ──────────────────────────────────────────────────────────────────
function setupDropZone() {
  const zone  = document.getElementById('train-drop-zone');
  const input = document.getElementById('train-file-input');
  if (!zone || !input) return;

  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave',  () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.classList.remove('drag-over');
    addFiles([...e.dataTransfer.files]);
  });
  input.addEventListener('change', () => addFiles([...input.files]));
}

async function addFiles(files) {
  for (const file of files) {
    const name = file.name;

    // Auto-detect label from prefix
    let label = '';
    if (/^(human|real|hu)_/i.test(name)) label = 'human';
    if (/^(ai|fake|synth|tts|gen)_/i.test(name)) label = 'ai';

    // Decode to get duration
    let durationS = 0;
    let samples16k = null;
    let nativeMono = null;
    let nativeSR   = null;
    let status = 'pending';
    let error  = null;

    try {
      const audioBuf = await decodeAudioFile(file);
      durationS = audioBuf.duration;
      const res = await resampleToMono16k(audioBuf);
      samples16k = res.mono16k;
      nativeMono = res.nativeMono;
      nativeSR   = res.nativeSR;
      status = 'decoded';
    } catch (e) {
      status = 'error';
      error  = e.message;
    }

    const clip = { name, label, source: '', durationS, status, error, feats: null };
    const id = await dbSaveClip({ ...clip, samples16k: null }); // don't store large typed arrays in IDB
    clip.id = id;
    // Keep samples in memory only
    clip._samples16k = samples16k;
    clip._nativeMono = nativeMono;
    clip._nativeSR   = nativeSR;
    clips.push(clip);
  }
  renderDatasetTable();
}

// ── Dataset table ──────────────────────────────────────────────────────────────
function renderDatasetTable() {
  const tbody = document.getElementById('dataset-tbody');
  const count = document.getElementById('dataset-count');
  if (!tbody) return;

  if (count) count.textContent = `${clips.length} clip${clips.length !== 1 ? 's' : ''}`;

  if (clips.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:2rem;">
      No clips yet. Drag audio files here to start building your dataset.
    </td></tr>`;
    return;
  }

  tbody.innerHTML = clips.map((clip, idx) => `
    <tr data-idx="${idx}">
      <td>${escHtml(clip.name)}</td>
      <td>
        <select data-field="label" data-idx="${idx}" style="width:90px;">
          <option value="" ${!clip.label ? 'selected' : ''}>-- label --</option>
          <option value="human" ${clip.label === 'human' ? 'selected' : ''}>Human</option>
          <option value="ai"    ${clip.label === 'ai'    ? 'selected' : ''}>AI</option>
        </select>
      </td>
      <td>
        <input type="text" data-field="source" data-idx="${idx}"
               value="${escHtml(clip.source || '')}"
               placeholder="e.g. ElevenLabs"
               style="min-width:110px;" />
      </td>
      <td>${clip.durationS ? clip.durationS.toFixed(1) + 's' : '–'}</td>
      <td>
        <span class="status-badge status-${statusClass(clip.status)}">${clip.status}</span>
        ${clip.error ? `<div style="color:var(--accent-red);font-size:0.7rem;">${escHtml(clip.error)}</div>` : ''}
        ${clip.feats ? '<div style="color:var(--accent-green);font-size:0.7rem;">✓ features extracted</div>' : ''}
      </td>
      <td>
        <button class="btn-secondary btn-danger" data-action="delete" data-idx="${idx}"
                style="padding:2px 8px;font-size:0.75rem;">✕</button>
      </td>
    </tr>
  `).join('');

  // Event delegation
  tbody.querySelectorAll('select[data-field], input[data-field]').forEach(el => {
    el.addEventListener('change', e => {
      const { field, idx } = e.target.dataset;
      clips[idx][field] = e.target.value;
      dbUpdateClip(clips[idx].id, { [field]: e.target.value });
    });
    el.addEventListener('input', e => {
      const { field, idx } = e.target.dataset;
      clips[idx][field] = e.target.value;
    });
    el.addEventListener('blur', e => {
      const { field, idx } = e.target.dataset;
      dbUpdateClip(clips[idx].id, { [field]: e.target.value });
    });
  });

  tbody.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', async e => {
      const idx = parseInt(e.target.dataset.idx);
      await dbDeleteClip(clips[idx].id);
      clips.splice(idx, 1);
      renderDatasetTable();
    });
  });
}

function statusClass(s) {
  return ({ pending: 'pending', decoded: 'pending', 'features extracted': 'ready',
            error: 'error', training: 'pending' })[s] || 'pending';
}

function escHtml(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Buttons ────────────────────────────────────────────────────────────────────
function setupButtons() {
  document.getElementById('btn-extract-features')?.addEventListener('click', extractAllFeatures);
  document.getElementById('btn-train')?.addEventListener('click', trainModel_);
  document.getElementById('btn-download-model')?.addEventListener('click', downloadModel);
  document.getElementById('btn-load-model')?.addEventListener('click', () => document.getElementById('model-file-input')?.click());
  document.getElementById('model-file-input')?.addEventListener('change', loadModelFile);
  document.getElementById('btn-use-model')?.addEventListener('click', useModelNow);
  document.getElementById('btn-reset-model')?.addEventListener('click', resetModel);
  document.getElementById('btn-export-csv')?.addEventListener('click', exportCSV);
  document.getElementById('btn-import-csv')?.addEventListener('click', () => document.getElementById('csv-file-input')?.click());
  document.getElementById('csv-file-input')?.addEventListener('change', importCSV);
  document.getElementById('btn-clear-dataset')?.addEventListener('click', clearDataset);
  document.getElementById('btn-batch-score')?.addEventListener('click', runBatchScore);
}

// ── Feature extraction ─────────────────────────────────────────────────────────
async function extractAllFeatures() {
  const btn = document.getElementById('btn-extract-features');
  if (btn) btn.disabled = true;

  setProgress(0, 'Extracting features…');

  const toProcess = clips.filter(c => c.status === 'decoded' && c._samples16k && !c.feats);

  for (let i = 0; i < toProcess.length; i++) {
    const clip = toProcess[i];
    setProgress(i / toProcess.length, `Extracting features: ${clip.name}`);
    try {
      const feats = await workerExtract(clip._samples16k, clip._nativeMono, clip._nativeSR, clip.id);
      clip.feats  = feats;
      clip.status = 'features extracted';
      await dbUpdateClip(clip.id, { feats, status: 'features extracted' });
    } catch (e) {
      clip.status = 'error';
      clip.error  = e.message;
    }
  }

  // Also process already-stored clips that have feats in IDB but not in memory
  const stored = await dbGetAllClips();
  for (const clip of clips) {
    if (!clip.feats) {
      const s = stored.find(c => c.id === clip.id);
      if (s?.feats) { clip.feats = s.feats; clip.status = 'features extracted'; }
    }
  }

  setProgress(1, 'Feature extraction complete.');
  renderDatasetTable();
  if (btn) btn.disabled = false;
}

function workerExtract(samples16k, nativeMono, nativeSR, id) {
  return new Promise((resolve, reject) => {
    const msgId = `${id}_${Date.now()}`;
    workerCallbacks[msgId] = { resolve, reject };
    worker.postMessage({
      type: 'EXTRACT_FEATURES',
      id: msgId,
      samples16k: samples16k.buffer,
      nativeSamples: nativeMono ? nativeMono.buffer : null,
      nativeSR,
    }, [samples16k.buffer]);
  });
}

function handleWorkerMsg(e) {
  const msg = e.data;
  if (msg.type === 'FEATURES_DONE') {
    const cb = workerCallbacks[msg.id];
    if (cb) { delete workerCallbacks[msg.id]; cb.resolve(msg.feats); }
  }
  else if (msg.type === 'FEATURES_ERROR') {
    const cb = workerCallbacks[msg.id];
    if (cb) { delete workerCallbacks[msg.id]; cb.reject(new Error(msg.error)); }
  }
  else if (msg.type === 'TRAIN_PROGRESS') {
    setProgress(msg.progress, msg.status);
  }
  else if (msg.type === 'TRAIN_DONE') {
    onTrainDone(msg.result, msg.cv);
  }
  else if (msg.type === 'TRAIN_ERROR') {
    setStatus('Training error: ' + msg.error, true);
  }
  else if (msg.type === 'BATCH_SCORE_DONE') {
    renderBatchResults(msg.results);
  }
}

// ── Training ───────────────────────────────────────────────────────────────────
async function trainModel_() {
  // Validate
  const missing = clips.filter(c => !c.label || !c.source);
  if (missing.length > 0) {
    return setStatus(`${missing.length} clip(s) are missing a label or source. Fill them in first.`, true);
  }

  const withFeats = clips.filter(c => c.feats && c.label);
  if (withFeats.length < 4) {
    return setStatus('Need at least 4 clips with features extracted and labeled. Run "Extract Features" first.', true);
  }

  // Feature preset
  const presetEl = document.getElementById('feature-preset');
  const preset   = presetEl?.value || 'all';
  const selectedFeatures = FEATURE_PRESETS[preset] || FEATURE_NAMES;

  // Augmentation options
  const augment = document.getElementById('aug-enable')?.checked ?? true;
  const augOpts = {
    gainAugment:     document.getElementById('aug-gain')?.checked ?? true,
    noiseAugment:    document.getElementById('aug-noise')?.checked ?? true,
    lpfAugment:      document.getElementById('aug-lpf')?.checked ?? true,
    reverbAugment:   document.getElementById('aug-reverb')?.checked ?? true,
    bitcrushAugment: document.getElementById('aug-bitcrush')?.checked ?? true,
  };

  // Windowing option: split into 4s windows with 50% overlap
  const windowing = document.getElementById('aug-windowing')?.checked ?? false;
  const WIN_LEN = 4 * 16000, WIN_HOP = 2 * 16000;

  const data   = [];
  const groups = [];

  for (const clip of withFeats) {
    const label = clip.label === 'ai' ? 1 : 0;

    if (windowing && clip._samples16k) {
      const s = clip._samples16k;
      let count = 0;
      for (let start = 0; start + WIN_LEN <= s.length; start += WIN_HOP) {
        const window = s.subarray(start, start + WIN_LEN);
        // Extract features inline (no worker for windowing simplicity)
        try {
          const { extractFeatures } = await import('./features.js');
          const feats = extractFeatures(window, null, null);
          const fArr = selectedFeatures.map(n => feats[n] ?? 0);
          data.push({ features: fArr, label });
          groups.push(clip.source);
          count++;
        } catch(_) { /* skip */ }
      }
      if (count === 0) {
        // Fallback: use stored features
        const fArr = selectedFeatures.map(n => clip.feats[n] ?? 0);
        data.push({ features: fArr, label });
        groups.push(clip.source);
      }
    } else {
      const fArr = selectedFeatures.map(n => clip.feats[n] ?? 0);
      data.push({ features: fArr, label });
      groups.push(clip.source);

      // Augmentation: add 2 augmented copies
      if (augment && clip._samples16k) {
        for (let a = 0; a < 2; a++) {
          try {
            const { augmentSamples } = await import('./model.js');
            const { extractFeatures } = await import('./features.js');
            const augSamples = augmentSamples(clip._samples16k, augOpts);
            const feats = extractFeatures(augSamples, null, null);
            const fArr2 = selectedFeatures.map(n => feats[n] ?? 0);
            data.push({ features: fArr2, label });
            groups.push(clip.source);
          } catch(_) { /* skip */ }
        }
      }
    }
  }

  setProgress(0.05, 'Training logistic regression…');
  document.getElementById('btn-train')?.setAttribute('disabled', '');

  // Run training synchronously (small dataset) rather than via worker
  try {
    const { weights, bias, mean, std } = trainLogistic(data, {
      lr: 0.1, lambda: 0.01, epochs: 500, featureNames: selectedFeatures
    });

    setProgress(0.7, 'Running grouped k-fold cross-validation…');
    const cv = groupedKFold(data, groups, selectedFeatures);

    const aiSources    = [...new Set(clips.filter(c => c.label === 'ai').map(c => c.source))];
    const humanSources = [...new Set(clips.filter(c => c.label === 'human').map(c => c.source))];

    const modelJSON = {
      version: 2,
      trainedAt: new Date().toISOString(),
      featureNames: selectedFeatures,
      mean: Array.from(mean),
      std:  Array.from(std),
      weights: Array.from(weights),
      bias,
      threshold: 0.65,
      uncertainBand: [0.35, 0.65],
      ood: { mean: null, std: null },
      training: {
        nClips: withFeats.length,
        sources: { ai: aiSources, human: humanSources },
        cv: cv.notEnoughSources ? null : {
          accuracy:         cv.accuracy,
          balancedAccuracy: cv.balancedAccuracy,
          auc:              cv.auc,
        },
      },
    };

    trainModel = new VoiceModel(modelJSON);
    setProgress(1, 'Training complete!');
    renderTrainResults(modelJSON, cv, weights, selectedFeatures);
    renderModelInfo(modelJSON);
  } catch(e) {
    setStatus('Training error: ' + e.message, true);
  }

  document.getElementById('btn-train')?.removeAttribute('disabled');
}

function onTrainDone(result, cv) {
  // Called from worker (future use)
  console.log('Train done from worker', result, cv);
}

// ── Results rendering ──────────────────────────────────────────────────────────
function renderTrainResults(modelJSON, cv, weights, featureNames) {
  const el = document.getElementById('train-results');
  if (!el) return;
  el.removeAttribute('hidden');

  const acc  = cv.notEnoughSources ? null : cv.accuracy;
  const bacc = cv.notEnoughSources ? null : cv.balancedAccuracy;
  const auc  = cv.notEnoughSources ? null : cv.auc;
  const cm   = cv.confusionMatrix;

  const notEnoughWarning = cv.notEnoughSources ? `
    <div class="error-banner">
      ⚠️ Fewer than 2 sources per class — validation is not trustworthy.
      Any accuracy shown is training accuracy, not generalisation accuracy.
    </div>` : '';

  // Metrics
  const metricsHTML = acc !== null ? `
    <div class="metrics-grid">
      <div class="metric-card"><div class="metric-value">${(acc*100).toFixed(0)}%</div><div class="metric-label">CV Accuracy</div></div>
      <div class="metric-card"><div class="metric-value">${(bacc*100).toFixed(0)}%</div><div class="metric-label">Balanced Acc.</div></div>
      <div class="metric-card"><div class="metric-value">${(auc ?? 0).toFixed(2)}</div><div class="metric-label">ROC AUC</div></div>
    </div>` : '<p class="text-muted">Not enough sources for reliable CV metrics.</p>';

  // Confusion matrix
  const cmHTML = cm ? `
    <h4 style="font-size:0.9rem;margin:1.5rem 0 0.5rem;">Confusion Matrix (CV)</h4>
    <div class="confusion-matrix">
      <div class="cm-header"></div>
      <div class="cm-header">Pred AI</div>
      <div class="cm-header">Pred Human</div>
      <div class="cm-header" style="writing-mode:vertical-rl;transform:rotate(180deg);">True AI</div>
      <div class="cm-cell cm-tp">${cm.tp ?? 0}</div>
      <div class="cm-cell cm-fn">${cm.fn ?? 0}</div>
      <div class="cm-header" style="writing-mode:vertical-rl;transform:rotate(180deg);">True Human</div>
      <div class="cm-cell cm-fp">${cm.fp ?? 0}</div>
      <div class="cm-cell cm-tn">${cm.tn ?? 0}</div>
    </div>` : '';

  // Weight bar chart (top 10)
  const sortedW = featureNames
    .map((n, i) => ({ name: n, w: weights[i] }))
    .sort((a, b) => Math.abs(b.w) - Math.abs(a.w))
    .slice(0, 10);

  const maxAbs = Math.max(...sortedW.map(w => Math.abs(w.w)), 1e-9);
  const barHTML = sortedW.map(({ name, w }) => {
    const pct = Math.abs(w) / maxAbs * 100;
    const cls = w > 0 ? 'bar-fill-pos' : 'bar-fill-neg';
    const dir = w > 0 ? '→AI' : '→Human';
    return `<div class="bar-row">
      <div class="bar-label">${name}</div>
      <div class="bar-track"><div class="${cls}" style="width:${pct}%"></div></div>
      <div class="bar-val">${w.toFixed(3)} <small>${dir}</small></div>
    </div>`;
  }).join('');

  // Per-source table
  const perSourceHTML = cv.perSource ? `
    <h4 style="font-size:0.9rem;margin:1.5rem 0 0.5rem;">Per-Source Accuracy (CV)</h4>
    <table class="score-table">
      <thead><tr><th>Source</th><th>Class</th><th>Accuracy</th></tr></thead>
      <tbody>${Object.entries(cv.perSource).map(([src, s]) =>
        `<tr><td>${escHtml(src)}</td>
          <td>${s.label === 1 ? 'AI' : 'Human'}</td>
          <td class="${s.correct/s.total >= 0.5 ? 'badge-correct' : 'badge-wrong'}">
            ${(s.correct/s.total*100).toFixed(0)}% (${s.correct}/${s.total})
          </td></tr>`
      ).join('')}</tbody>
    </table>` : '';

  el.innerHTML = `
    <h3 style="font-size:1.1rem;margin-bottom:1rem;">Training Results</h3>
    ${notEnoughWarning}
    ${metricsHTML}
    ${cmHTML}
    <h4 style="font-size:0.9rem;margin:1.5rem 0 0.5rem;">Feature Weights (Top 10)</h4>
    <div class="bar-chart">${barHTML}</div>
    ${perSourceHTML}
  `;
}

function renderModelInfo(json) {
  const el = document.getElementById('current-model-info');
  if (!el) return;
  const m = json.training;
  el.innerHTML = `
    <div class="success-banner">
      ✓ Model trained at ${new Date(json.trainedAt).toLocaleString()} ·
      ${m.nClips} clips · ${json.featureNames.length} features
      ${m.cv ? `· CV accuracy ${(m.cv.accuracy*100).toFixed(0)}%` : ''}
    </div>`;
}

// ── Threshold slider ──────────────────────────────────────────────────────────
function setupThresholdSlider() {
  const slider  = document.getElementById('threshold-slider');
  const valEl   = document.getElementById('threshold-value');
  const precEl  = document.getElementById('threshold-precision');
  const recallEl = document.getElementById('threshold-recall');
  if (!slider) return;

  slider.addEventListener('input', () => {
    const t = parseFloat(slider.value);
    if (valEl) valEl.textContent = t.toFixed(2);
    updatePrecisionRecall(t);
  });
}

function updatePrecisionRecall(threshold) {
  if (!trainModel) return;
  const withFeats = clips.filter(c => c.feats && c.label);
  if (!withFeats.length) return;

  let tp = 0, fp = 0, fn = 0;
  for (const clip of withFeats) {
    const res = trainModel.predict(clip.feats);
    if (!res) continue;
    const pred  = res.prob >= threshold ? 1 : 0;
    const label = clip.label === 'ai' ? 1 : 0;
    if (pred === 1 && label === 1) tp++;
    if (pred === 1 && label === 0) fp++;
    if (pred === 0 && label === 1) fn++;
  }
  const precision = tp / (tp + fp + 1e-9);
  const recall    = tp / (tp + fn + 1e-9);
  const precEl    = document.getElementById('threshold-precision');
  const recallEl  = document.getElementById('threshold-recall');
  if (precEl)   precEl.textContent  = (precision * 100).toFixed(0) + '%';
  if (recallEl) recallEl.textContent = (recall * 100).toFixed(0) + '%';
}

// ── Save / load / use model ────────────────────────────────────────────────────
function downloadModel() {
  if (!trainModel) return alert('No trained model yet.');
  const json = JSON.stringify(trainModel.toJSON(), null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'model.json'; a.click();
  URL.revokeObjectURL(url);
}

async function loadModelFile() {
  const input = document.getElementById('model-file-input');
  const file  = input?.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const json = JSON.parse(text);
    trainModel = new VoiceModel(json);
    renderModelInfo(json);
    setStatus('Model loaded from file.');
  } catch (e) {
    setStatus('Could not load model: ' + e.message, true);
  }
}

function useModelNow() {
  if (!trainModel) return alert('No trained model. Train one first.');
  saveModelToLocalStorage(trainModel.toJSON());
  setStatus('✓ Model saved to browser. Switch to the Detector page to use it.');
}

function resetModel() {
  if (!confirm('Reset the model? This clears it from localStorage.')) return;
  localStorage.removeItem('voiceclone_model_v2');
  trainModel = null;
  const el = document.getElementById('current-model-info');
  if (el) el.innerHTML = '';
  const resultsEl = document.getElementById('train-results');
  if (resultsEl) resultsEl.setAttribute('hidden', '');
  setStatus('Model reset.');
}

// ── CSV export / import ────────────────────────────────────────────────────────
function exportCSV() {
  const withFeats = clips.filter(c => c.feats);
  if (!withFeats.length) return alert('No clips with extracted features to export.');

  const header = ['name','label','source','durationS', ...FEATURE_NAMES].join(',');
  const rows = withFeats.map(c => [
    `"${(c.name||'').replace(/"/g,'""')}"`,
    c.label || '',
    `"${(c.source||'').replace(/"/g,'""')}"`,
    c.durationS?.toFixed(2) || '',
    ...FEATURE_NAMES.map(n => (c.feats[n] ?? 0).toFixed(6)),
  ].join(','));

  const csv  = [header, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = 'voiceclone_dataset.csv'; a.click();
  URL.revokeObjectURL(url);
}

async function importCSV() {
  const input = document.getElementById('csv-file-input');
  const file  = input?.files[0];
  if (!file) return;

  const text = await file.text();
  const lines = text.trim().split('\n');
  const header = lines[0].split(',');
  const nameIdx   = header.indexOf('name');
  const labelIdx  = header.indexOf('label');
  const sourceIdx = header.indexOf('source');
  const durIdx    = header.indexOf('durationS');

  let imported = 0;
  for (let i = 1; i < lines.length; i++) {
    const cols  = lines[i].split(',');
    const name  = cols[nameIdx]?.replace(/"/g, '') || `clip_${i}`;
    const label = cols[labelIdx] || '';
    const source= cols[sourceIdx]?.replace(/"/g, '') || '';
    const durationS = parseFloat(cols[durIdx]) || 0;
    const feats = {};
    FEATURE_NAMES.forEach(n => {
      const idx = header.indexOf(n);
      feats[n] = idx >= 0 ? parseFloat(cols[idx]) || 0 : 0;
    });
    const id = await dbSaveClip({ name, label, source, durationS, status: 'features extracted', feats });
    clips.push({ id, name, label, source, durationS, status: 'features extracted', feats });
    imported++;
  }

  renderDatasetTable();
  setStatus(`Imported ${imported} clips from CSV.`);
}

// ── Batch scoring ─────────────────────────────────────────────────────────────
function runBatchScore() {
  if (!trainModel) return setStatus('No model loaded. Train one first.', true);
  const withFeats = clips.filter(c => c.feats && c.label);
  if (!withFeats.length) return setStatus('No clips with features to score.', true);

  const results = withFeats.map(clip => {
    const res = trainModel.predict(clip.feats);
    return {
      name:    clip.name,
      label:   clip.label,
      source:  clip.source,
      prob:    res?.prob ?? 0,
      correct: res ? (clip.label === 'ai' ? res.verdictClass === 'ai' : res.verdictClass === 'human') : false,
    };
  });

  const el = document.getElementById('batch-results');
  if (!el) return;
  el.removeAttribute('hidden');

  const correct = results.filter(r => r.correct).length;
  const accuracy = correct / results.length;

  // Per-source accuracy
  const bySource = {};
  for (const r of results) {
    if (!bySource[r.source]) bySource[r.source] = { correct: 0, total: 0 };
    if (r.correct) bySource[r.source].correct++;
    bySource[r.source].total++;
  }

  el.innerHTML = `
    <h4 style="font-size:1rem;margin-bottom:0.75rem;">Batch Score Results</h4>
    <p>Overall accuracy on training set: <strong>${(accuracy*100).toFixed(0)}%</strong> (${correct}/${results.length})</p>
    <table class="score-table" style="margin-top:1rem;">
      <thead><tr><th>Source</th><th>Accuracy</th></tr></thead>
      <tbody>${Object.entries(bySource).map(([src, s]) =>
        `<tr><td>${escHtml(src)}</td>
         <td class="${s.correct/s.total >= 0.5 ? 'badge-correct':'badge-wrong'}">
           ${(s.correct/s.total*100).toFixed(0)}% (${s.correct}/${s.total})
         </td></tr>`
      ).join('')}</tbody>
    </table>
    <p style="font-size:0.75rem;color:var(--text-muted);margin-top:0.75rem;">
      Note: This is in-sample accuracy. Use cross-validation results for true generalisation estimates.
    </p>
  `;

  renderBatchTable(results);
}

function renderBatchResults(results) {
  // Called from worker (future use)
  renderBatchTable(results);
}

function renderBatchTable(results) {
  const el = document.getElementById('batch-clip-table');
  if (!el) return;
  el.innerHTML = `
    <table class="score-table" style="margin-top:1rem;">
      <thead><tr><th>Clip</th><th>Label</th><th>Source</th><th>AI-prob</th><th>Result</th></tr></thead>
      <tbody>${results.map(r => `
        <tr>
          <td>${escHtml(r.name)}</td>
          <td>${r.label}</td>
          <td>${escHtml(r.source)}</td>
          <td>${(r.prob*100).toFixed(0)}%</td>
          <td class="${r.correct ? 'badge-correct':'badge-wrong'}">${r.correct ? '✓':'✗'}</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
}

// ── Clear dataset ─────────────────────────────────────────────────────────────
async function clearDataset() {
  if (!confirm('Clear the entire dataset from IndexedDB?')) return;
  await dbClear();
  clips = [];
  renderDatasetTable();
  setStatus('Dataset cleared.');
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function setProgress(pct, label) {
  const bar  = document.getElementById('train-progress-fill');
  const text = document.getElementById('train-progress-text');
  const box  = document.getElementById('train-progress-box');
  if (box)  box.removeAttribute('hidden');
  if (bar)  bar.style.width = `${(pct * 100).toFixed(0)}%`;
  if (text) text.textContent = label;
}

function setStatus(msg, isError = false) {
  const el = document.getElementById('train-status');
  if (!el) return;
  el.textContent = msg;
  el.style.color = isError ? 'var(--accent-red)' : 'var(--accent-green)';
}
