/**
 * VoiceClone v2 Service Worker
 * Cache-first for static assets, network-first for HTML.
 * Audio files are never cached or uploaded.
 */

const CACHE_NAME = 'voiceclone-v2-cache-v1';

const APP_SHELL = [
  '/',
  '/index.html',
  '/train.html',
  '/how-it-works.html',
  '/scam-safety.html',
  '/about.html',
  '/selftest.html',
  '/css/styles.css',
  '/js/audio.js',
  '/js/features.js',
  '/js/model.js',
  '/js/ui.js',
  '/js/train.js',
  '/js/worker.js',
  '/js/db.js',
  '/model.json',
  '/samples/human_AUD-20261030-WA0013.mp3',
  '/samples/ai_voice_01_low.mp3',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(APP_SHELL).catch(err => {
        console.warn('SW: Some shell files could not be pre-cached:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(key => key !== CACHE_NAME ? caches.delete(key) : null))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Never intercept cross-origin requests except CDNs we explicitly cache
  if (url.hostname !== self.location.hostname &&
      !url.hostname.includes('fonts.googleapis.com') &&
      !url.hostname.includes('fonts.gstatic.com')) {
    return; // let browser handle it
  }

  // Cache-first for JS, CSS, audio samples, fonts
  if (
    url.pathname.endsWith('.js')  ||
    url.pathname.endsWith('.css') ||
    url.pathname.endsWith('.mp3') ||
    url.pathname.endsWith('.wav') ||
    url.pathname.endsWith('.json') ||
    url.hostname.includes('fonts')
  ) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(resp => {
          if (resp && resp.status === 200) {
            caches.open(CACHE_NAME).then(c => c.put(event.request, resp.clone()));
          }
          return resp;
        });
      })
    );
    return;
  }

  // Network-first for HTML pages
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
