/**
 * js/features.js
 * Pure feature-extraction module. No DOM, no globals.
 * Runs both on the main thread and inside the web worker.
 *
 * extractFeatures(samples16k, nativeSamples, nativeSR)
 *   → returns a flat object with the 26 feature keys listed below.
 *
 * Feature keys (exact):
 *   noise_floor_dbfs, dyn_range_db, digital_silence_pct, bandwidth_hz
 *   spec_flatness, spec_centroid_hz, rolloff95_hz, hf_4_8k_ratio, spec_flux_cv
 *   mfcc_temporal_std, mfcc_delta_mean
 *   f0_mean_hz, f0_std_semitones, f0_range_semitones, voiced_pct, f0_flat_step_pct
 *   hnr_mean_db, hnr_std_db
 *   amp_frame_shimmer_pct
 *   pause_per_10s, pause_mean_s, pause_cv
 *   mod_peak_hz, mod_peak_ratio
 */

'use strict';

// ─── Radix-2 FFT ─────────────────────────────────────────────────────────────
// In-place Cooley-Tukey. re/im are Float32Array of length N (power of 2).
function fft(re, im) {
  const N = re.length;
  // Bit-reversal permutation
  for (let i = 1, j = 0; i < N; i++) {
    let bit = N >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j], re[i]];
      [im[i], im[j]] = [im[j], im[i]];
    }
  }
  // Butterfly passes
  for (let len = 2; len <= N; len <<= 1) {
    const half = len >> 1;
    const ang = -2 * Math.PI / len;
    const wRe = Math.cos(ang), wIm = Math.sin(ang);
    for (let i = 0; i < N; i += len) {
      let curRe = 1, curIm = 0;
      for (let j = 0; j < half; j++) {
        const u = i + j, v = i + j + half;
        const tRe = curRe * re[v] - curIm * im[v];
        const tIm = curRe * im[v] + curIm * re[v];
        re[v] = re[u] - tRe; im[v] = im[u] - tIm;
        re[u] += tRe;        im[u] += tIm;
        const nRe = curRe * wRe - curIm * wIm;
        curIm    = curRe * wIm + curIm * wRe;
        curRe    = nRe;
      }
    }
  }
}

// Next power-of-2 ≥ n
function nextPow2(n) {
  let p = 1; while (p < n) p <<= 1; return p;
}

// Hann window
function hannWindow(N) {
  const w = new Float32Array(N);
  for (let i = 0; i < N; i++) w[i] = 0.5 * (1 - Math.cos(2 * Math.PI * i / (N - 1)));
  return w;
}

// Frame a signal into overlapping windows → array of Float32Array
function makeFrames(sig, frameLen, hopLen) {
  const frames = [];
  for (let start = 0; start + frameLen <= sig.length; start += hopLen) {
    frames.push(sig.subarray(start, start + frameLen));
  }
  return frames;
}

// RMS of a frame
function rms(frame) {
  let s = 0;
  for (let i = 0; i < frame.length; i++) s += frame[i] * frame[i];
  return Math.sqrt(s / frame.length);
}

const LOG10_20 = 20 / Math.LN10;
const LOG10_10 = 10 / Math.LN10;
const EPS = 1e-12;

function toDBFS(amplitude) {
  return LOG10_20 * Math.log(Math.max(amplitude, EPS));
}

// Percentile over a sorted array
function pct(sorted, p) {
  const i = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(i), hi = Math.ceil(i);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (i - lo);
}

// Mel filterbank (26 filters, 16 kHz, 0–8000 Hz)
function buildMelFilterbank(nFilters, nFft, sr) {
  const fMin = 0, fMax = sr / 2;
  function hzToMel(f) { return 2595 * Math.log10(1 + f / 700); }
  function melToHz(m) { return 700 * (Math.pow(10, m / 2595) - 1); }
  const melMin = hzToMel(fMin), melMax = hzToMel(fMax);
  const melPoints = [];
  for (let i = 0; i <= nFilters + 1; i++) {
    melPoints.push(melToHz(melMin + (melMax - melMin) * i / (nFilters + 1)));
  }
  const bins = melPoints.map(f => Math.round(f / sr * nFft));
  const filters = [];
  for (let m = 1; m <= nFilters; m++) {
    const filt = new Float32Array(nFft / 2 + 1);
    for (let k = bins[m - 1]; k <= bins[m]; k++) {
      filt[k] = (k - bins[m - 1]) / (bins[m] - bins[m - 1] + EPS);
    }
    for (let k = bins[m]; k <= bins[m + 1]; k++) {
      filt[k] = (bins[m + 1] - k) / (bins[m + 1] - bins[m] + EPS);
    }
    filters.push(filt);
  }
  return filters;
}

// DCT-II for MFCC
function dct2(x, n) {
  const out = new Float32Array(n);
  const N = x.length;
  for (let k = 0; k < n; k++) {
    let s = 0;
    for (let i = 0; i < N; i++) s += x[i] * Math.cos(Math.PI * k * (2 * i + 1) / (2 * N));
    out[k] = s;
  }
  return out;
}

// ─── Main extraction function ─────────────────────────────────────────────────
export function extractFeatures(samples16k, nativeSamples, nativeSR) {
  const SR = 16000;
  const N = samples16k.length;
  if (N < SR * 0.5) throw new Error('Audio too short for feature extraction');

  // ── Frame parameters ───────────────────────────────────────────────────────
  const FRAME_25ms   = Math.round(0.025 * SR); // 400 samples  (level)
  const HOP_10ms     = Math.round(0.010 * SR); // 160 samples
  const FFT_SIZE     = 512;                     // spectral frames
  const FRAME_40ms   = Math.round(0.040 * SR); // 640 samples (pitch)
  const HOP_PITCH    = Math.round(0.010 * SR); // 160 samples

  const hann25  = hannWindow(FRAME_25ms);
  const hann512 = hannWindow(FFT_SIZE);
  const hann40  = hannWindow(FRAME_40ms);

  // ─── Level frames (25 ms / 10 ms hop) ─────────────────────────────────────
  const levelFrames = makeFrames(samples16k, FRAME_25ms, HOP_10ms);
  const frameRMSlog = levelFrames.map(f => toDBFS(rms(f)));
  const maxDB = Math.max(...frameRMSlog);

  const sortedRMS = [...frameRMSlog].sort((a, b) => a - b);
  const noise_floor_dbfs = Math.max(pct(sortedRMS, 10), -120);
  const dyn_range_db     = pct(sortedRMS, 95) - pct(sortedRMS, 10);
  const digital_silence_pct = 100 * frameRMSlog.filter(v => Math.pow(10, v / 20) < 1e-5).length / frameRMSlog.length;

  // ─── Active frames: within 40 dB of peak ──────────────────────────────────
  const activeFrameMask = frameRMSlog.map(v => v >= maxDB - 40);
  const activeIdx = activeFrameMask.reduce((acc, v, i) => { if (v) acc.push(i); return acc; }, []);

  // ─── Bandwidth from native spectrum ───────────────────────────────────────
  let bandwidth_hz = 0;
  if (nativeSamples && nativeSR && nativeSamples.length > 0) {
    const chunk = nativeSamples.subarray(0, Math.min(nativeSamples.length, nextPow2(nativeSamples.length)));
    const N2 = nextPow2(chunk.length);
    const re = new Float32Array(N2), im = new Float32Array(N2);
    const w = hannWindow(chunk.length);
    for (let i = 0; i < chunk.length; i++) { re[i] = chunk[i] * w[i]; }
    fft(re, im);
    const magN = N2 / 2;
    const mag = new Float32Array(magN);
    for (let i = 0; i < magN; i++) mag[i] = re[i] * re[i] + im[i] * im[i];
    const peakMag = Math.max(...mag);
    const thresh  = peakMag / Math.pow(10, 6); // 60 dB below peak
    for (let i = magN - 1; i >= 0; i--) {
      if (mag[i] >= thresh) {
        bandwidth_hz = i / N2 * nativeSR;
        break;
      }
    }
  } else {
    // fallback: use 16k spectrum
    const magN = FFT_SIZE / 2;
    const re16 = new Float32Array(FFT_SIZE), im16 = new Float32Array(FFT_SIZE);
    for (let i = 0; i < Math.min(FFT_SIZE, N); i++) re16[i] = samples16k[i] * hann512[i];
    fft(re16, im16);
    const mag = new Float32Array(magN);
    for (let i = 0; i < magN; i++) mag[i] = re16[i] * re16[i] + im16[i] * im16[i];
    const peakMag = Math.max(...mag);
    const thresh  = peakMag / Math.pow(10, 6);
    for (let i = magN - 1; i >= 0; i--) {
      if (mag[i] >= thresh) { bandwidth_hz = i / FFT_SIZE * SR; break; }
    }
  }

  // ─── Spectral frames (FFT_SIZE=512, hop=160) ──────────────────────────────
  const spectralHop = HOP_10ms;
  const specFrames  = makeFrames(samples16k, FFT_SIZE, spectralHop);
  const nBins = FFT_SIZE / 2 + 1;

  const specMags = []; // magnitude spectra for active frames only
  const allEnergy = [];
  const fluxArr  = [];
  let prevMag = null;

  for (let fi = 0; fi < specFrames.length; fi++) {
    const frame = specFrames[fi];
    const re = new Float32Array(FFT_SIZE), im = new Float32Array(FFT_SIZE);
    for (let i = 0; i < Math.min(frame.length, FFT_SIZE); i++) {
      re[i] = frame[i] * hann512[i];
    }
    fft(re, im);
    const mag = new Float32Array(nBins);
    let energy = 0;
    for (let k = 0; k < nBins; k++) {
      mag[k] = Math.sqrt(re[k] * re[k] + im[k] * im[k]);
      energy += mag[k] * mag[k];
    }
    allEnergy.push(energy);

    if (prevMag) {
      let flux = 0;
      for (let k = 0; k < nBins; k++) {
        const d = mag[k] - prevMag[k];
        flux += d > 0 ? d : 0;
      }
      fluxArr.push(flux);
    }
    prevMag = mag;

    // Active frame: within 40 dB of loudest
    const frameDB = 10 * Math.log10(energy + EPS);
    const maxEnDB  = 10 * Math.log10(Math.max(...allEnergy) + EPS);
    if (frameDB >= maxEnDB - 40) {
      specMags.push(mag);
    }
  }

  // Spectral features averaged over active spec frames
  let spec_flatness = 0, spec_centroid_hz = 0, rolloff95_hz = 0, hf_4_8k_ratio = 0;

  if (specMags.length > 0) {
    const avgMag = new Float32Array(nBins);
    for (const m of specMags) for (let k = 0; k < nBins; k++) avgMag[k] += m[k];
    for (let k = 0; k < nBins; k++) avgMag[k] /= specMags.length;

    // Flatness = geometric mean / arithmetic mean of power spectrum
    let logSum = 0, linSum = 0;
    for (let k = 1; k < nBins; k++) {
      const p = avgMag[k] * avgMag[k] + EPS;
      logSum += Math.log(p);
      linSum += p;
    }
    const geoMean = Math.exp(logSum / (nBins - 1));
    const ariMean = linSum / (nBins - 1);
    spec_flatness = geoMean / ariMean;

    // Centroid
    let num = 0, den = 0;
    for (let k = 0; k < nBins; k++) {
      const freq = k / FFT_SIZE * SR;
      num += freq * avgMag[k];
      den += avgMag[k];
    }
    spec_centroid_hz = num / (den + EPS);

    // Rolloff 95%
    const totalE = avgMag.reduce((s, v) => s + v * v, 0);
    let cumE = 0;
    for (let k = 0; k < nBins; k++) {
      cumE += avgMag[k] * avgMag[k];
      if (cumE >= 0.95 * totalE) {
        rolloff95_hz = k / FFT_SIZE * SR;
        break;
      }
    }

    // HF ratio (>4 kHz)
    const bin4k = Math.round(4000 / SR * FFT_SIZE);
    let hfE = 0;
    for (let k = bin4k; k < nBins; k++) hfE += avgMag[k] * avgMag[k];
    hf_4_8k_ratio = hfE / (totalE + EPS);
  }

  // Spectral flux CV
  const fluxMean = fluxArr.reduce((s, v) => s + v, 0) / (fluxArr.length + EPS);
  const fluxStd  = Math.sqrt(fluxArr.reduce((s, v) => s + (v - fluxMean) ** 2, 0) / (fluxArr.length + EPS));
  const spec_flux_cv = fluxStd / (fluxMean + EPS);

  // ─── MFCC ─────────────────────────────────────────────────────────────────
  const N_MFCC  = 13;
  const N_MEL   = 26;
  const melBank = buildMelFilterbank(N_MEL, FFT_SIZE, SR);

  const mfccMatrix = []; // nFrames × N_MFCC

  for (let fi = 0; fi < specFrames.length; fi++) {
    const frame = specFrames[fi];
    const re = new Float32Array(FFT_SIZE), im = new Float32Array(FFT_SIZE);
    for (let i = 0; i < Math.min(frame.length, FFT_SIZE); i++) re[i] = frame[i] * hann512[i];
    fft(re, im);
    const power = new Float32Array(nBins);
    for (let k = 0; k < nBins; k++) power[k] = re[k] * re[k] + im[k] * im[k];

    const melE = melBank.map(filt => {
      let s = 0;
      for (let k = 0; k < nBins; k++) s += power[k] * filt[k];
      return Math.log(s + EPS);
    });
    const mfcc = dct2(melE, N_MFCC);
    mfccMatrix.push(mfcc);
  }

  // mfcc_temporal_std = mean over coeffs 1-12 of their std across time
  let mfcc_temporal_std = 0;
  if (mfccMatrix.length > 1) {
    for (let c = 1; c < N_MFCC; c++) {
      const vals = mfccMatrix.map(v => v[c]);
      const m = vals.reduce((s, v) => s + v, 0) / vals.length;
      const std = Math.sqrt(vals.reduce((s, v) => s + (v - m) ** 2, 0) / vals.length);
      mfcc_temporal_std += std;
    }
    mfcc_temporal_std /= (N_MFCC - 1);
  }

  // mfcc_delta_mean = mean norm of frame-to-frame change
  let mfcc_delta_mean = 0;
  if (mfccMatrix.length > 1) {
    let totalNorm = 0;
    for (let fi = 1; fi < mfccMatrix.length; fi++) {
      let norm = 0;
      for (let c = 0; c < N_MFCC; c++) {
        const d = mfccMatrix[fi][c] - mfccMatrix[fi - 1][c];
        norm += d * d;
      }
      totalNorm += Math.sqrt(norm);
    }
    mfcc_delta_mean = totalNorm / (mfccMatrix.length - 1);
  }

  // ─── Pitch (F0) via normalised autocorrelation ─────────────────────────────
  const pitchFrames = makeFrames(samples16k, FRAME_40ms, HOP_PITCH);
  const F0_MIN = 70, F0_MAX = 400;
  const lagMin = Math.floor(SR / F0_MAX);
  const lagMax = Math.ceil(SR / F0_MIN);

  const f0List     = [];
  const hnrList    = [];
  const rmsVoiced  = [];
  const pitchFrameRMS = [];

  for (const frame of pitchFrames) {
    const n = frame.length;
    const frameR = rms(frame);
    pitchFrameRMS.push(frameR);

    // Normalised autocorrelation
    const r = new Float32Array(lagMax + 1);
    let r0 = 0;
    for (let i = 0; i < n; i++) r0 += frame[i] * frame[i];
    if (r0 < EPS) { f0List.push(0); hnrList.push(null); continue; }

    for (let lag = lagMin; lag <= lagMax; lag++) {
      let s = 0;
      for (let i = 0; i + lag < n; i++) s += frame[i] * frame[i + lag];
      r[lag] = s / (r0 + EPS);
    }

    // Find peak
    let peakLag = lagMin, peakVal = r[lagMin];
    for (let lag = lagMin + 1; lag <= lagMax; lag++) {
      if (r[lag] > peakVal) { peakVal = r[lag]; peakLag = lag; }
    }

    // Parabolic interpolation
    let refinedLag = peakLag;
    if (peakLag > lagMin && peakLag < lagMax) {
      const alpha = r[peakLag - 1], beta = r[peakLag], gamma = r[peakLag + 1];
      const shift = 0.5 * (alpha - gamma) / (alpha - 2 * beta + gamma + EPS);
      refinedLag = peakLag + shift;
    }

    const voiced = peakVal > 0.45;
    const f0 = voiced ? SR / refinedLag : 0;

    // Remove octave outliers later; mark voiced frames
    f0List.push(f0);

    // HNR
    if (voiced && peakVal < 1) {
      hnrList.push(LOG10_10 * Math.log(peakVal / (1 - peakVal + EPS)));
      rmsVoiced.push(frameR);
    } else {
      hnrList.push(null);
    }
  }

  // Octave outlier removal: if adjacent frames differ by >5 semitones
  const voicedF0 = f0List.filter(v => v > 0);
  const voicedRMS = f0List.map((v, i) => ({ f0: v, rms: pitchFrameRMS[i] })).filter(v => v.f0 > 0);
  const maxPitchRMS = voicedRMS.length ? Math.max(...voicedRMS.map(v => v.rms)) : 0;

  // Remove frames > 40 dB below peak RMS
  const cleanF0 = f0List.map((f0, i) => {
    if (f0 === 0) return 0;
    if (maxPitchRMS > 0 && toDBFS(pitchFrameRMS[i]) < toDBFS(maxPitchRMS) - 40) return 0;
    return f0;
  });

  // Remove octave jumps
  for (let i = 1; i < cleanF0.length; i++) {
    if (cleanF0[i] > 0 && cleanF0[i - 1] > 0) {
      const ratio = cleanF0[i] / cleanF0[i - 1];
      if (ratio > 1.9 || ratio < 0.53) cleanF0[i] = 0; // octave error
    }
  }

  const validF0 = cleanF0.filter(v => v > 0);
  const voiced_pct = 100 * validF0.length / (cleanF0.length + EPS);

  const f0_mean_hz = validF0.length ? validF0.reduce((s, v) => s + v, 0) / validF0.length : 0;

  // Semitones: 12 * log2(f0 / f0_mean)
  const f0_semitones = validF0.map(f => 12 * Math.log2(f / (f0_mean_hz + EPS)));
  const sortedF0Semi = [...f0_semitones].sort((a, b) => a - b);
  const f0_range_semitones = validF0.length > 1 ? pct(sortedF0Semi, 95) - pct(sortedF0Semi, 5) : 0;

  const f0_std_semitones = validF0.length > 1 ?
    Math.sqrt(f0_semitones.reduce((s, v) => s + v * v, 0) / f0_semitones.length) : 0;

  // f0_flat_step_pct
  let flatSteps = 0, totalConsec = 0;
  for (let i = 1; i < cleanF0.length; i++) {
    if (cleanF0[i] > 0 && cleanF0[i - 1] > 0) {
      totalConsec++;
      if (Math.abs(cleanF0[i] - cleanF0[i - 1]) < 0.5) flatSteps++;
    }
  }
  const f0_flat_step_pct = totalConsec > 0 ? 100 * flatSteps / totalConsec : 0;

  // HNR stats
  const validHNR = hnrList.filter(v => v !== null);
  const hnr_mean_db = validHNR.length ? validHNR.reduce((s, v) => s + v, 0) / validHNR.length : 0;
  const hnrMeanLocal = hnr_mean_db;
  const hnr_std_db   = validHNR.length > 1 ?
    Math.sqrt(validHNR.reduce((s, v) => s + (v - hnrMeanLocal) ** 2, 0) / validHNR.length) : 0;

  // Shimmer (amplitude variation between consecutive voiced frames)
  let amp_frame_shimmer_pct = 0;
  if (rmsVoiced.length > 1) {
    let sumDiff = 0;
    for (let i = 1; i < rmsVoiced.length; i++) sumDiff += Math.abs(rmsVoiced[i] - rmsVoiced[i - 1]);
    const meanRMSV = rmsVoiced.reduce((s, v) => s + v, 0) / rmsVoiced.length;
    amp_frame_shimmer_pct = 100 * (sumDiff / (rmsVoiced.length - 1)) / (meanRMSV + EPS);
  }

  // ─── Pauses ────────────────────────────────────────────────────────────────
  // A pause is a run of frames > 35 dB below the loudest frame lasting ≥ 150 ms
  const PAUSE_DB_THRESH = maxDB - 35;
  const PAUSE_MIN_FRAMES = Math.ceil(0.150 / 0.010); // 15 frames at 10 ms hop

  const pauses = [];
  let pauseStart = -1;

  for (let i = 0; i <= frameRMSlog.length; i++) {
    const inPause = i < frameRMSlog.length && frameRMSlog[i] < PAUSE_DB_THRESH;
    if (inPause && pauseStart === -1) pauseStart = i;
    if (!inPause && pauseStart !== -1) {
      const dur = (i - pauseStart) * 0.010;
      if (i - pauseStart >= PAUSE_MIN_FRAMES) pauses.push(dur);
      pauseStart = -1;
    }
  }

  const totalDurS = N / SR;
  const pause_per_10s = pauses.length / (totalDurS / 10);
  const pause_mean_s  = pauses.length ? pauses.reduce((s, v) => s + v, 0) / pauses.length : 0;
  const pauseMeanL = pause_mean_s;
  const pause_std_s   = pauses.length > 1 ?
    Math.sqrt(pauses.reduce((s, v) => s + (v - pauseMeanL) ** 2, 0) / pauses.length) : 0;
  const pause_cv      = pause_mean_s > EPS ? pause_std_s / pause_mean_s : 0;

  // ─── Modulation (energy envelope 2-8 Hz) ──────────────────────────────────
  // RMS envelope at hop rate (100 Hz), then FFT it
  const envHop   = HOP_10ms; // 10ms → 100 Hz sample rate
  const envRMS   = levelFrames.map(f => rms(f));
  const envN     = nextPow2(envRMS.length);
  const envRe    = new Float32Array(envN);
  const envIm    = new Float32Array(envN);
  for (let i = 0; i < envRMS.length; i++) envRe[i] = envRMS[i];
  fft(envRe, envIm);

  const envSR  = SR / envHop; // ≈ 100 Hz
  const envMag = new Float32Array(envN / 2);
  for (let k = 0; k < envN / 2; k++) {
    envMag[k] = envRe[k] * envRe[k] + envIm[k] * envIm[k];
  }

  const binOf = f => Math.round(f / envSR * envN);
  const bin2   = binOf(2),  bin8   = binOf(8);
  const binHalf = binOf(0.5), bin20 = binOf(20);

  let mod_peak_hz = 0, modPeakVal = 0;
  for (let k = bin2; k <= Math.min(bin8, envN / 2 - 1); k++) {
    if (envMag[k] > modPeakVal) { modPeakVal = envMag[k]; mod_peak_hz = k / envN * envSR; }
  }

  let energy05_20 = 0;
  for (let k = binHalf; k <= Math.min(bin20, envN / 2 - 1); k++) energy05_20 += envMag[k];
  const mod_peak_ratio = energy05_20 > EPS ? modPeakVal / energy05_20 : 0;

  // ─── Return ────────────────────────────────────────────────────────────────
  return {
    noise_floor_dbfs,
    dyn_range_db,
    digital_silence_pct,
    bandwidth_hz,
    spec_flatness,
    spec_centroid_hz,
    rolloff95_hz,
    hf_4_8k_ratio,
    spec_flux_cv,
    mfcc_temporal_std,
    mfcc_delta_mean,
    f0_mean_hz,
    f0_std_semitones,
    f0_range_semitones,
    voiced_pct,
    f0_flat_step_pct,
    hnr_mean_db,
    hnr_std_db,
    amp_frame_shimmer_pct,
    pause_per_10s,
    pause_mean_s,
    pause_cv,
    mod_peak_hz,
    mod_peak_ratio,
  };
}

// ─── Unit tests (called from selftest page) ────────────────────────────────
export function runFeatureUnitTests() {
  const results = [];

  // Helper: generate sine at given freq
  function makeSine(freq, sr, dur) {
    const n = Math.floor(sr * dur);
    const sig = new Float32Array(n);
    for (let i = 0; i < n; i++) sig[i] = 0.5 * Math.sin(2 * Math.PI * freq / sr * i);
    return sig;
  }

  // Helper: white noise
  function makeNoise(sr, dur) {
    const n = Math.floor(sr * dur);
    const sig = new Float32Array(n);
    for (let i = 0; i < n; i++) sig[i] = (Math.random() * 2 - 1) * 0.5;
    return sig;
  }

  // Helper: silence
  function makeSilence(sr, dur) {
    return new Float32Array(Math.floor(sr * dur));
  }

  // Test 1: 200 Hz sine → f0 within 2%
  try {
    const sine200 = makeSine(200, 16000, 3);
    const feats = extractFeatures(sine200, null, null);
    const err = Math.abs(feats.f0_mean_hz - 200) / 200;
    results.push({
      name: 'Sine 200 Hz → F0 accuracy',
      pass: err < 0.02,
      detail: `f0_mean_hz = ${feats.f0_mean_hz.toFixed(1)} Hz (expected ~200, error=${(err*100).toFixed(1)}%)`
    });
  } catch (e) {
    results.push({ name: 'Sine 200 Hz → F0 accuracy', pass: false, detail: e.message });
  }

  // Test 2: White noise → flatness near 1
  try {
    const noise = makeNoise(16000, 3);
    const feats = extractFeatures(noise, null, null);
    results.push({
      name: 'White noise → spectral flatness ≈ 1',
      pass: feats.spec_flatness > 0.3,
      detail: `spec_flatness = ${feats.spec_flatness.toFixed(4)} (expected > 0.3 for noise)`
    });
  } catch (e) {
    results.push({ name: 'White noise → spectral flatness', pass: false, detail: e.message });
  }

  // Test 3: Silence → digital_silence_pct near 100
  try {
    const silence = makeSilence(16000, 3);
    const feats = extractFeatures(silence, null, null);
    results.push({
      name: 'Silence → digital_silence_pct ≈ 100',
      pass: feats.digital_silence_pct > 90,
      detail: `digital_silence_pct = ${feats.digital_silence_pct.toFixed(1)}%`
    });
  } catch (e) {
    results.push({ name: 'Silence → digital_silence_pct', pass: false, detail: e.message });
  }

  return results;
}
