/**
 * js/ui.js
 * Main detector page UI controller.
 * Imports audio.js, features.js, model.js.
 */

'use strict';

import { decodeAudioFile, resampleToMono16k, drawWaveform, MicRecorder, qualityGate } from './audio.js';
import { extractFeatures } from './features.js';
import { VoiceModel, FEATURE_NAMES, loadModelFromLocalStorage } from './model.js';

// ── State ─────────────────────────────────────────────────────────────────────
let currentModel   = null;
let currentFeats   = null;
let currentSamples = null;
let micRecorder    = null;

// ── Boot ──────────────────────────────────────────────────────────────────────
export async function initApp() {
  setupNav();
  await loadModel();
  setupUploadZone();
  setupMicButton();
  setupTestLab();
  setupAnalyzeBtn();
}

// ── Nav mobile toggle ──────────────────────────────────────────────────────────
function setupNav() {
  const btn  = document.getElementById('mobile-menu-btn');
  const nav  = document.getElementById('nav-links');
  if (btn && nav) {
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
    });
  }
}

// ── Model loading ─────────────────────────────────────────────────────────────
async function loadModel() {
  const noModelBanner = document.getElementById('no-model-banner');
  const modelInfo     = document.getElementById('model-info');

  // 1. Try localStorage
  let json = loadModelFromLocalStorage();

  // 2. Try fetching ./model.json
  if (!json || !json.weights || json.training?.nClips === 0) {
    try {
      const resp = await fetch('./model.json');
      if (resp.ok) {
        const fetched = await resp.json();
        if (fetched.weights && fetched.training?.nClips > 0) {
          json = fetched;
        }
      }
    } catch (_) { /* no file */ }
  }

  if (json && json.weights && (json.training?.nClips ?? 0) > 0) {
    currentModel = new VoiceModel(json);
    noModelBanner?.setAttribute('hidden', '');
    if (modelInfo) {
      const m = json.training;
      const ai = m?.sources?.ai?.length ?? 0;
      const hu = m?.sources?.human?.length ?? 0;
      modelInfo.innerHTML = `
        <span class="text-muted" style="font-size:0.8rem;">
          Model trained on <strong>${m?.nClips ?? 0} clips</strong>
          from <strong>${ai + hu} sources</strong>
          ${m?.cv ? `· CV accuracy <strong>${(m.cv.accuracy * 100).toFixed(0)}%</strong>` : ''}
        </span>`;
    }
  } else {
    currentModel = null;
    noModelBanner?.removeAttribute('hidden');
    if (modelInfo) modelInfo.innerHTML = '';
  }
}

// ── Upload zone ───────────────────────────────────────────────────────────────
function setupUploadZone() {
  const zone  = document.getElementById('upload-zone');
  const input = document.getElementById('file-input');
  if (!zone || !input) return;

  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave',  () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    const f = e.dataTransfer.files[0];
    if (f) loadAudioFile(f);
  });

  input.addEventListener('change', () => { if (input.files[0]) loadAudioFile(input.files[0]); });
}

// ── Central audio loader ──────────────────────────────────────────────────────
export async function loadAudioFile(file) {
  const statusEl    = document.getElementById('upload-status');
  const waveformEl  = document.getElementById('waveform-canvas');
  const analyzeBtn  = document.getElementById('analyze-btn');
  const resultArea  = document.getElementById('result-area');

  function setStatus(msg, isErr = false) {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.color = isErr ? 'var(--accent-red)' : 'var(--text-muted)';
  }

  setStatus('Decoding audio…');
  if (analyzeBtn) analyzeBtn.disabled = true;
  if (resultArea) resultArea.innerHTML = '';
  currentFeats = null; currentSamples = null;

  try {
    const audioBuf = await decodeAudioFile(file);
    setStatus('Resampling to 16 kHz…');
    const { mono16k, nativeMono, nativeSR } = await resampleToMono16k(audioBuf);

    // Quality gate
    const qg = qualityGate(mono16k);
    if (!qg.ok) {
      setStatus(qg.reason, true);
      return;
    }
    if (qg.ok === 'warn') setStatus(qg.reason);

    // Draw waveform
    if (waveformEl) drawWaveform(waveformEl, mono16k);

    setStatus(`Loaded: ${file.name} · ${audioBuf.duration.toFixed(1)} s · ${(file.size/1024).toFixed(0)} KB`);

    // Extract features
    setStatus('Extracting acoustic features…');
    const feats = extractFeatures(mono16k, nativeMono, nativeSR);
    currentFeats = feats;
    currentSamples = mono16k;

    renderFeaturesAccordion(feats);
    if (analyzeBtn) analyzeBtn.disabled = false;
    setStatus(`Ready to analyze: ${file.name}`);
  } catch (err) {
    setStatus(err.message, true);
  }
}

// ── Features accordion ─────────────────────────────────────────────────────────
function renderFeaturesAccordion(feats) {
  const el = document.getElementById('features-accordion');
  if (!el) return;
  el.removeAttribute('hidden');

  const grid = el.querySelector('.features-grid');
  if (!grid) return;

  grid.innerHTML = FEATURE_NAMES.map(name => {
    const val = feats[name];
    const fmt = typeof val === 'number' ? (Number.isInteger(val) ? val : val.toFixed(3)) : '–';
    return `<div class="feature-item">
      <div class="feature-name">${name}</div>
      <div class="feature-value">${fmt}</div>
    </div>`;
  }).join('');
}

// ── Microphone ────────────────────────────────────────────────────────────────
function setupMicButton() {
  const btn     = document.getElementById('mic-btn');
  const meter   = document.getElementById('level-meter-fill');
  const timerEl = document.getElementById('mic-timer');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    if (micRecorder && micRecorder.isRecording()) {
      micRecorder.stop();
      btn.textContent = '🎙 Record';
      btn.classList.remove('active');
      return;
    }

    micRecorder = new MicRecorder({
      onLevel:   level => { if (meter) meter.style.width = `${level * 100}%`; },
      onTimer:   sec   => { if (timerEl) timerEl.textContent = `${sec.toFixed(0)}s / 60s`; },
      onStopped: async blob => {
        const file = new File([blob], 'recording.webm', { type: blob.type });
        await loadAudioFile(file);
        if (timerEl) timerEl.textContent = '';
        if (meter)   meter.style.width   = '0%';
      },
    });

    try {
      await micRecorder.start();
      btn.textContent = '⏹ Stop Recording';
      btn.classList.add('active');
    } catch (err) {
      showError(err.message);
    }
  });
}

// ── Analyze button ────────────────────────────────────────────────────────────
function setupAnalyzeBtn() {
  const btn = document.getElementById('analyze-btn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    if (!currentFeats) return showError('Please load an audio file first.');
    if (!currentModel) return showError('No trained model found. Open the Train page to train a model first.');
    runDetection(currentFeats);
  });
}

function runDetection(feats) {
  const result = currentModel.predict(feats);
  if (!result) return;
  renderVerdict(result);
}

// ── Verdict rendering ─────────────────────────────────────────────────────────
function renderVerdict(result) {
  const area = document.getElementById('result-area');
  if (!area) return;

  const { prob, verdict, verdictClass, scoreLabel, contribs, ood } = result;
  const m = currentModel?.meta;
  const nClips   = m?.training?.nClips ?? 0;
  const nSources = (m?.training?.sources?.ai?.length ?? 0) + (m?.training?.sources?.human?.length ?? 0);
  const cvAcc    = m?.training?.cv?.accuracy;

  const pct = (prob * 100).toFixed(0);

  // Top 3 feature explanations
  const top3 = contribs.slice(0, 3);
  const explainHTML = top3.map(c => {
    const direction = c.contribution > 0 ? 'higher (AI-like)' : 'lower (human-like)';
    return `<li><strong>${c.name}</strong>: ${c.rawValue.toFixed(3)} — ${direction}</li>`;
  }).join('');

  const oodHTML = ood ? `
    <div class="ood-banner">
      ⚠️ This recording looks unlike the data I was trained on. Treat the result as unreliable.
    </div>` : '';

  area.innerHTML = `
    <div class="verdict-card verdict-${verdictClass}">
      <div class="verdict-headline">${verdict}</div>
      <div style="font-size:1.1rem; font-weight:600; margin-bottom:0.5rem;">${scoreLabel}</div>
      <div class="verdict-score-bar">
        <div class="verdict-score-fill" style="width:${pct}%"></div>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:var(--text-muted); margin-bottom:1rem;">
        <span>0% (Human)</span><span>50%</span><span>100% (AI)</span>
      </div>

      <h4 style="font-size:0.9rem; margin-bottom:0.5rem; color:var(--text-muted);">Top contributing signals:</h4>
      <ul style="padding-left:1.2rem; font-size:0.85rem; color:var(--text-primary); line-height:1.8; margin-bottom:1rem;">
        ${explainHTML}
      </ul>

      ${oodHTML}

      <div style="font-size:0.75rem; color:var(--text-muted); border-top:1px solid var(--border-subtle); padding-top:0.75rem; margin-top:0.75rem;">
        ${cvAcc ? `Cross-validated accuracy: <strong>${(cvAcc*100).toFixed(0)}%</strong> · ` : ''}
        Trained on <strong>${nClips} clips</strong> from <strong>${nSources} sources</strong><br>
        <em>This tool gives probabilistic estimates only. Never rely solely on automated analysis for financial, legal or safety decisions.</em>
      </div>
    </div>`;
}

// ── Test Lab ──────────────────────────────────────────────────────────────────
function setupTestLab() {
  const btnHuman = document.getElementById('load-sample-human');
  const btnAI    = document.getElementById('load-sample-ai');
  if (btnHuman) {
    btnHuman.addEventListener('click', async () => {
      const resp = await fetch('./samples/human_AUD-20261030-WA0013.mp3');
      const blob = await resp.blob();
      await loadAudioFile(new File([blob], 'sample_human.mp3', { type: 'audio/mpeg' }));
    });
  }
  if (btnAI) {
    btnAI.addEventListener('click', async () => {
      const resp = await fetch('./samples/ai_voice_01_low.mp3');
      const blob = await resp.blob();
      await loadAudioFile(new File([blob], 'sample_ai.mp3', { type: 'audio/mpeg' }));
    });
  }
}

// ── Error helper ──────────────────────────────────────────────────────────────
function showError(msg) {
  const el = document.getElementById('friendly-error-message');
  const modal = document.getElementById('friendly-error-modal');
  if (el)    el.textContent = msg;
  if (modal) { modal.removeAttribute('hidden'); modal.style.display = 'flex'; }

  const closeBtn = document.getElementById('friendly-error-close');
  if (closeBtn) {
    closeBtn.onclick = () => { modal.setAttribute('hidden', ''); modal.style.display = 'none'; };
  }
}
