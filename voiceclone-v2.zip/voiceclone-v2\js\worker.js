/**
 * js/worker.js
 * Web worker: decodes, resamples, extracts features, runs training.
 * Messages IN:  { type, ...payload }
 * Messages OUT: { type, ...payload }
 */

'use strict';

// Workers can import ES modules in modern browsers via importScripts or type=module.
// We use importScripts here for broadest compatibility.
// Actually for ES modules in workers we use type="module" in the registration.

import { extractFeatures } from './features.js';
import { trainLogistic, groupedKFold, augmentSamples, FEATURE_NAMES } from './model.js';

self.onmessage = async (e) => {
  const msg = e.data;

  if (msg.type === 'EXTRACT_FEATURES') {
    try {
      const { samples16k, nativeSamples, nativeSR, id } = msg;
      const s16k = new Float32Array(samples16k);
      const sNat = nativeSamples ? new Float32Array(nativeSamples) : null;
      const feats = extractFeatures(s16k, sNat, nativeSR);
      self.postMessage({ type: 'FEATURES_DONE', id, feats });
    } catch (err) {
      self.postMessage({ type: 'FEATURES_ERROR', id: msg.id, error: err.message });
    }
  }

  else if (msg.type === 'EXTRACT_FEATURES_AUGMENTED') {
    // Extract features from potentially augmented audio (for training)
    try {
      const { samples16k, nativeSamples, nativeSR, id, augment, augOpts } = msg;
      let s16k = new Float32Array(samples16k);
      if (augment) s16k = augmentSamples(s16k, augOpts);
      const sNat = nativeSamples ? new Float32Array(nativeSamples) : null;
      const feats = extractFeatures(s16k, sNat, nativeSR);
      self.postMessage({ type: 'FEATURES_DONE', id, feats });
    } catch (err) {
      self.postMessage({ type: 'FEATURES_ERROR', id: msg.id, error: err.message });
    }
  }

  else if (msg.type === 'TRAIN') {
    try {
      const { data, groups, featureNames, opts } = msg;
      self.postMessage({ type: 'TRAIN_PROGRESS', progress: 0.05, status: 'Starting training…' });

      // z-score + logistic regression on full dataset
      const result = trainLogistic(data, { ...opts, featureNames });
      self.postMessage({ type: 'TRAIN_PROGRESS', progress: 0.7, status: 'Running cross-validation…' });

      // Cross-validation
      const cv = groupedKFold(data, groups, featureNames);
      self.postMessage({ type: 'TRAIN_PROGRESS', progress: 1.0, status: 'Done' });
      self.postMessage({ type: 'TRAIN_DONE', result, cv });
    } catch (err) {
      self.postMessage({ type: 'TRAIN_ERROR', error: err.message });
    }
  }

  else if (msg.type === 'BATCH_SCORE') {
    try {
      const { items, modelJSON } = msg;
      const { sigmoid } = await import('./model.js');
      const results = items.map(item => {
        const { feats, label, source } = item;
        const names = modelJSON.featureNames;
        const z = names.map((n, i) => (feats[n] - modelJSON.mean[i]) / (modelJSON.std[i] || 1));
        const dot = z.reduce((s, v, i) => s + v * modelJSON.weights[i], modelJSON.bias);
        const prob = 1 / (1 + Math.exp(-dot));
        const pred = prob >= (modelJSON.threshold || 0.65) ? 1 : 0;
        return { prob, pred, label, source, correct: pred === label };
      });
      self.postMessage({ type: 'BATCH_SCORE_DONE', results });
    } catch (err) {
      self.postMessage({ type: 'BATCH_SCORE_ERROR', error: err.message });
    }
  }
};
